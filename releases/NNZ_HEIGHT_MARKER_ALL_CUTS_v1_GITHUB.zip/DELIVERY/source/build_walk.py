"""Original local 3D clothed pedestrian; no external model or paid generation.
Blender 4.3: blender -b -t 4 --python build_walk.py -- [still|all]
Depth Y=0 is the doorway. Z=0 floor; same camera as camera.json.
"""
import bpy, math, json, sys
from pathlib import Path
from mathutils import Vector, Matrix
ROOT=Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene
s.render.engine='CYCLES';s.cycles.samples=32;s.cycles.use_denoising=False
s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100
s.render.film_transparent=True;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA'
s.render.fps=30;s.frame_start=1;s.frame_end=150
s.world.color=(.45,.45,.45)
s.view_settings.view_transform='AgX'
def mat(name,color,rough=.6,noise=False):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True
 n=m.node_tree.nodes; p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough
 if noise:
  a=n.new('ShaderNodeTexNoise');a.inputs['Scale'].default_value=180
  b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.13;b.inputs['Distance'].default_value=.008
  m.node_tree.links.new(a.outputs['Fac'],b.inputs['Height']);m.node_tree.links.new(b.outputs['Normal'],p.inputs['Normal'])
 return m
skin=mat('skin warm',(.52,.31,.20),.5);jacket=mat('olive cotton overshirt',(.16,.21,.15),.83,True);trousers=mat('charcoal denim',(.055,.065,.078),.85,True);hair=mat('dark brown hair',(.045,.026,.019),.85);shoe=mat('suede shoes',(.07,.052,.035),.9);sole=mat('rubber soles',(.035,.03,.027),.7);button=mat('dark buttons',(.07,.075,.055),.3);eye=mat('eye',(.035,.024,.018),.35)
parts={}
def uv(name,loc,scale,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=20,location=loc)
 o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(m)
 for p in o.data.polygons:p.use_smooth=True
 parts[name]=o;return o
def limb(name,a,b,r1,r2,m):
 # continuous tapered mesh with softly rounded ends and clothing folds
 a,b=Vector(a),Vector(b);v=b-a; L=v.length
 rings=[(0,.7),(.045,.98),(.18,1.0),(.37,1.025),(.48,.99),(.54,1.035),(.68,1.0),(.9,.96),(1,.72)]
 vs=[];faces=[];N=24
 for t,q in rings:
  rad=((1-t)*r1+t*r2)*q
  for j in range(N):
   ang=2*math.pi*j/N;vs.append((rad*math.cos(ang),rad*.85*math.sin(ang),t*L))
 for k in range(len(rings)-1):
  for j in range(N):
   i=k*N+j;z=k*N+(j+1)%N;faces.append((i,z,z+N,i+N))
 faces.extend([tuple(range(N-1,-1,-1)),tuple((len(rings)-1)*N+j for j in range(N))])
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(vs,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);o.location=a;o.rotation_mode='QUATERNION';o.rotation_quaternion=v.to_track_quat('Z','Y');o.data.materials.append(m)
 for p in mesh.polygons:p.use_smooth=True
 parts[name]=o;return o
def torso():
 # anatomical tailored silhouette, not a geometric capsule
 rings=[(.83,.145,.09),(.9,.165,.11),(1.02,.16,.105),(1.18,.185,.115),(1.34,.215,.115),(1.40,.21,.10),(1.445,.13,.075)]
 vs=[];fs=[];N=40
 for z,w,d in rings:
  for i in range(N):
   a=math.tau*i/N;vs.append((w*math.cos(a),d*math.sin(a),z))
 for k in range(len(rings)-1):
  for i in range(N):a=k*N+i;b=k*N+(i+1)%N;fs.append((a,b,b+N,a+N))
 fs.extend([tuple(range(N-1,-1,-1)),tuple((len(rings)-1)*N+i for i in range(N))])
 me=bpy.data.meshes.new('tailored torso');me.from_pydata(vs,[],fs);o=bpy.data.objects.new('overshirt',me);bpy.context.collection.objects.link(o);o.data.materials.append(jacket)
 for f in me.polygons:f.use_smooth=True
 parts['overshirt']=o
 # collar, seam and pockets are independently editable meshes
 for x in [-.055,.055]:
  o=uv('collar'+str(x),(x,.074,1.425),(.053,.023,.047),jacket);o.rotation_euler.y=x*5
 for z in [1.,1.1,1.2,1.3,1.39]:uv('button'+str(z),(0,.117,z),(.009,.004,.009),button)
 for x in [-.102,.102]:
  uv('pocket'+str(x),(x,.108,1.268),(.058,.012,.057),jacket)
 uv('hips',(0,0,.84),(.16,.105,.14),trousers)
 limb('neck',(0,0,1.41),(0,0,1.54),.058,.057,skin)
 uv('head',(0,.004,1.61),(.084,.078,.118),skin)
 uv('jaw',(0,.025,1.56),(.063,.062,.051),skin)
 uv('hair crown',(0,-.008,1.676),(.087,.081,.059),hair)
 uv('hair back',(0,-.049,1.64),(.083,.035,.074),hair)
 for side in [-1,1]:
  uv('ear'+str(side),(side*.084,.005,1.613),(.014,.017,.026),skin)
  uv('eye'+str(side),(side*.031,.075,1.627),(.009,.004,.004),eye)
  uv('brow'+str(side),(side*.032,.073,1.645),(.018,.005,.004),hair)
 uv('nose',(0,.079,1.602),(.015,.022,.025),skin)
 uv('mouth',(0,.077,1.567),(.023,.003,.003),hair)
torso()
# Neutral arm and leg meshes, transformed analytically on every frame.
for side in [-1,1]:
 for suffix,a,b,r1,r2,m in [('thigh',(0,0,0),(0,0,.4),.092,.065,trousers),('calf',(0,0,0),(0,0,.4),.067,.045,trousers),('upperarm',(0,0,0),(0,0,.29),.069,.052,jacket),('forearm',(0,0,0),(0,0,.27),.053,.036,jacket)]:limb(str(side)+suffix,a,b,r1,r2,m)
 uv(str(side)+'shoe',(0,0,0),(.065,.132,.06),shoe);uv(str(side)+'sole',(0,0,0),(.067,.135,.018),sole)
 uv(str(side)+'hand',(0,0,0),(.037,.023,.076),skin)
 for k in range(4):uv(str(side)+'finger'+str(k),(0,0,0),(.007,.009,.035-k*.002),skin)
 uv(str(side)+'thumb',(0,0,0),(.014,.013,.035),skin)
base={k:o.location.copy() for k,o in parts.items() if not k.startswith(('-1','1'))}
# camera derived from entrance plane and marker correspondences
c=json.load(open(ROOT/'camera.json')); R=Matrix(c['R_cv']);T=Matrix(((1,0,0),(0,-1,0),(0,0,-1)))
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='matched entrance camera';cam.matrix_world=Matrix.Translation(Vector(c['camera_center'])) @ (T@R).transposed().to_4x4();cam.data.lens=c['focal_pixels']*36/941;cam.data.sensor_width=36;cam.data.sensor_fit='HORIZONTAL';s.camera=cam
for name,loc,energy,size in [('entrance softbox',(1,3,4),500,4),('interior ceiling',(-2,-1,3),350,3),('exterior fill',(-3,4,2),180,3)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=energy;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,1))-o.location).to_track_quat('-Z','Y').to_euler()
def setseg(o,a,b):
 a,b=Vector(a),Vector(b);o.location=a;o.rotation_quaternion=(b-a).to_track_quat('Z','Y');o.scale.z=(b-a).length/(.4 if 'thigh' in o.name or 'calf' in o.name else (.29 if 'upper' in o.name else .27))
def pose(scene):
 t=(scene.frame_current-1)/30;rootY=-1.1+.44*t;rootX=.04+max(0,t-2.5)*.07
 # ground-locked stance: foot remains stationary in world space during support phase
 for side in [-1,1]:
  phase=t/1.05+(0 if side==-1 else .5);cycle=math.floor(phase);u=phase-cycle;stride=.462
  if u<.62:
   fy=(cycle+.31)*stride-1.1;fz=.065
  else:
   q=(u-.62)/.38;fy=(cycle+.31+q*q*(3-2*q))*stride-1.1;fz=.065+.10*math.sin(math.pi*q)
  fx=rootX+side*.10
  foot=Vector((fx,fy,fz));hip=Vector((rootX+side*.09,rootY,.86+.012*math.cos(math.tau*t/1.05*2)))
  # two-link IK, knee forward in walking direction
  ankle=foot+Vector((0,-.035,.045));d=ankle-hip;L=d.length;mid=(hip+ankle)*.5
  bend=math.sqrt(max(0,.415**2-(L/2)**2));knee=mid+Vector((0,1,0))*bend
  setseg(parts[str(side)+'thigh'],hip,knee);setseg(parts[str(side)+'calf'],knee,ankle)
  parts[str(side)+'shoe'].location=foot;parts[str(side)+'sole'].location=foot-Vector((0,0,.043))
  swing=math.sin(math.tau*phase)*.17
  sh=Vector((rootX+side*.215,rootY,1.365));el=Vector((rootX+side*.245,rootY-swing,1.08));hand=Vector((rootX+side*.245,rootY-swing-.03,.84))
  setseg(parts[str(side)+'upperarm'],sh,el);setseg(parts[str(side)+'forearm'],el,hand+Vector((0,0,.035)))
  parts[str(side)+'hand'].location=hand
  for k in range(4):parts[str(side)+'finger'+str(k)].location=hand+Vector(((k-1.5)*.014,.008,-.065))
  parts[str(side)+'thumb'].location=hand+Vector((-side*.031,.01,-.015))
 for k,p in base.items():parts[k].location=p+Vector((rootX,rootY,.012*math.cos(math.tau*t/1.05*2)))
# Replace prototype capsules with CC0 anatomical topology; retain local walking IK.
import numpy as np
for o in list(parts.values()):bpy.data.objects.remove(o,do_unlink=True)
verts=[];faces=[];groups={};group=''
for ln in open(ROOT/'assets/makehuman-base-CC0.obj'):
 if ln.startswith('v '):verts.append(list(map(float,ln.split()[1:4])))
 elif ln.startswith('g '):group=ln.split()[1];groups[group]=[]
 elif ln.startswith('f '):
  ids=[int(x.split('/')[0])-1 for x in ln.split()[1:]];groups[group]+=ids
  if (group=='body' or group in ['helper-l-eye','helper-r-eye']) and not all(verts[i][1]<-7.2 for i in ids):faces.append(ids)
v=np.array(verts);zmin=min(v[i,1] for i in set(groups['body']));zmax=max(v[i,1] for i in set(groups['body']));sc=1.735/(zmax-zmin)
v=np.column_stack([v[:,0]*sc,v[:,2]*sc,(v[:,1]-zmin)*sc])
def joint(n):return v[list(set(groups['joint-'+n]))].mean(0)
# Garments follow the body rather than separate ball-and-cylinder joints.
vv=v.copy()
for i,p in enumerate(v):
 if .83<p[2]<1.43:
  vv[i,0]*=1.06;vv[i,1]=max(vv[i,1]*1.15,.115) if vv[i,1]>0 else min(vv[i,1]*1.15,-.09)
 if .12<p[2]<.88:vv[i,0]+=(.007 if p[0]>0 else -.007);vv[i,1]*=1.10
used=sorted(set(sum(faces,[])));remap={j:i for i,j in enumerate(used)};vrest=vv[used]
me=bpy.data.meshes.new('CC0 anatomical pedestrian dressed');me.from_pydata(vrest.tolist(),[],[[remap[i] for i in f] for f in faces]);me.update();human=bpy.data.objects.new('clothed pedestrian',me);bpy.context.collection.objects.link(human)
for m in [skin,jacket,trousers,shoe,hair,eye]:me.materials.append(m)
for f in me.polygons:
 f.use_smooth=True;p=np.mean(vrest[list(f.vertices)],0)
 if p[2]<.115:idx=3
 elif p[2]<.88:idx=2
 elif p[2]<1.43 and abs(p[0])<.32:idx=1
 elif abs(p[0])>.29 and p[2]>1.07:idx=1
 elif abs(p[0])>.23 and p[2]<1.07:idx=0
 elif p[2]>1.68 or (p[2]>1.57 and p[1]<-.01):idx=4
 else:idx=0
 f.material_index=idx
# Rig definitions in rest space and smoothly blended inverse-distance skin weights.
bones=[('torso',np.array([0,0,.90]),np.array([0,0,1.52]))]
for side,tag in [(-1,'r'),(1,'l')]:
 hip=np.array([side*.10,0,.88]);knee=joint(tag+'-knee');ankle=joint(tag+'-ankle');sh=joint(tag+'-shoulder');el=joint(tag+'-elbow');hand=joint(tag+'-hand')
 bones.extend([(str(side)+'thigh',hip,knee),(str(side)+'calf',knee,ankle),(str(side)+'foot',ankle,ankle+np.array([0,.15,0])),(str(side)+'upperarm',sh,el),(str(side)+'forearm',el,hand),(str(side)+'hand',hand,hand+np.array([0,0,-.10]))])
D=[]
for name,a,b in bones:
 ab=b-a;u=np.clip((vrest-a)@ab/(ab@ab),0,1);d=np.linalg.norm(vrest-(a+u[:,None]*ab),axis=1);D.append(d)
D=np.array(D).T;w=1/np.maximum(D,.018)**5
# Anatomical region boundaries prevent the torso pulling fingers or head.
for i,(name,a,b) in enumerate(bones):
 if name=='torso':w[(np.abs(vrest[:,0])>.28)&(vrest[:,2]<1.4),i]=0;w[vrest[:,2]<.83,i]*=.02
 else:
  side=-1 if name.startswith('-1') else 1
  w[vrest[:,0]*side<0,i]=0
  if any(q in name for q in ['thigh','calf','foot']):w[vrest[:,2]>1.00,i]=0
  else:w[(np.abs(vrest[:,0])<.17)|(vrest[:,2]>1.47),i]=0
w/=w.sum(1)[:,None]
for side in [-1,1]:
 uv(str(side)+'shoe',(0,0,0),(.065,.13,.056),shoe)
 uv(str(side)+'sole',(0,0,0),(.067,.133,.013),sole)
# Flat tailoring, jacket seam and small buttons are separate editable objects.
extras=[]
for z in [1.0,1.1,1.2,1.3,1.38]:
 ob=uv('shirt-button'+str(z),(0,.12,z),(.006,.003,.006),button);extras.append((ob,ob.location.copy()))
from mathutils import Quaternion
def pose(scene):
 t=(scene.frame_current-1)/30;ry=-1.1+.44*t;rx=.04+max(0,t-2.5)*.07;bob=.008*math.cos(math.tau*t/1.05*2);root=np.array([rx,ry,bob]);targets={'torso':(bones[0][1]+root,bones[0][2]+root)}
 for side,tag in [(-1,'r'),(1,'l')]:
  phase=t/1.05+(0 if side==-1 else .5);cy=math.floor(phase);u=phase-cy;stride=.462
  if u<.62:fy=(cy+.31)*stride-1.1;fz=.065
  else:q=(u-.62)/.38;fy=(cy+.31+q*q*(3-2*q))*stride-1.1;fz=.065+.08*math.sin(math.pi*q)
  hip=np.array([rx+side*.1,ry,.88+bob]);ank=np.array([rx+side*.15,fy-.035,fz+.035]);d=ank-hip;L=np.linalg.norm(d);knee=(hip+ank)*.5+np.array([0,math.sqrt(max(0,.425**2-(L/2)**2)),0])
  parts[str(side)+'shoe'].location=Vector((rx+side*.15,fy,.060+fz-.065));parts[str(side)+'sole'].location=Vector((rx+side*.15,fy,.016+fz-.065))
  targets[str(side)+'thigh']=(hip,knee);targets[str(side)+'calf']=(knee,ank);targets[str(side)+'foot']=(ank,ank+np.array([0,.15,0]))
  swing=math.sin(math.tau*phase)*.12;sh=joint(tag+'-shoulder')+root;el=np.array([rx+side*.24,ry-swing,1.10+bob]);hand=np.array([rx+side*.245,ry-swing+.035,.85+bob])
  targets[str(side)+'upperarm']=(sh,el);targets[str(side)+'forearm']=(el,hand);targets[str(side)+'hand']=(hand,hand+np.array([0,.01,-.1]))
 for ob,p in extras:ob.location=Vector(p)+Vector(root)
 out=np.zeros_like(vrest)
 for i,(name,a,b) in enumerate(bones):
  na,nb=targets[name];q=Vector(b-a).rotation_difference(Vector(nb-na));M=np.array(q.to_matrix());trans=(vrest-a)@M.T+na;out+=trans*w[:,i,None]
 me.vertices.foreach_set('co',out.astype(np.float32).ravel());me.update()
s.cycles.samples=24;s.view_settings.look='AgX - Medium High Contrast';s.view_settings.exposure=-.5

if 'bake' in sys.argv:
 human.shape_key_add(name='Basis')
 for f in range(1,151):
  s.frame_set(f);pose(s)
  k=human.shape_key_add(name=f'walk_{f:03d}',from_mix=False)
  for i,vert in enumerate(me.vertices):k.data[i].co=vert.co
  for ff,val in [(f-1,0),(f,1),(f+1,0)]:
   k.value=val;k.keyframe_insert('value',frame=ff)
  for ob in [parts[str(side)+name] for side in [-1,1] for name in ['shoe','sole']]+[o for o,p in extras]:ob.keyframe_insert('location',frame=f)
 s.frame_set(76);pose(s)
 bpy.app.handlers.frame_change_pre.clear()
 bpy.data.texts.load(__file__)
 bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'pedestrian-editable.blend'))
 sys.exit(0)
bpy.app.handlers.frame_change_pre.clear();bpy.app.handlers.frame_change_pre.append(pose)
s.frame_set(76);pose(s)
# Save mesh, camera, materials and an embedded rebuild script. The renderer script reconstructs poses.
bpy.data.texts.load(__file__)
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'pedestrian-editable.blend'))
frames=ROOT/'walk-rgba';frames.mkdir(exist_ok=True)
if 'all' in sys.argv:
 for i in range(1,151):
  s.frame_set(i);pose(s);s.render.filepath=str(frames/f'{i-1:04d}.png');bpy.ops.render.render(write_still=True)
else:
 s.render.filepath=str(ROOT/'test-person.png');bpy.ops.render.render(write_still=True)
