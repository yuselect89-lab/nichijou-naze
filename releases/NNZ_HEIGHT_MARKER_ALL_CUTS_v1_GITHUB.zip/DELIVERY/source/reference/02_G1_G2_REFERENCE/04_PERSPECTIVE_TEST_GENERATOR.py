#!/usr/bin/env python3
"""G2 design-only perspective/memory motion proof; no store footage/approved overlays."""
import os, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import cv2

W,H,FPS=720,1280,30
DURATION=12.0
DEST=os.path.join(os.path.dirname(__file__),'C03_C05_C06_C07_PERSPECTIVE_MEMORY_TEST.mp4')
FONT='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
BOLD='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
font=lambda n,b=False:ImageFont.truetype(BOLD if b else FONT,n)
FONT_SM=font(21); FONT_MD=font(31); FONT_BIG=font(40,True); FONT_TINY=font(19)
C=np.array([2.55,1.54,4.4],dtype=float)
T=np.array([0,1.15,0],dtype=float)
f=(T-C); f/=np.linalg.norm(f)
r=np.cross(f,[0,1,0]);r/=np.linalg.norm(r)
u=np.cross(r,f)
F=820.0
CX=360;CY=617

def P(x,y,z):
    point=np.array([x,y,z],float)-C
    depth=np.dot(point,f)
    return (CX + F*np.dot(point,r)/depth,CY-F*np.dot(point,u)/depth)

def coords(points):
    return [tuple(map(int,P(*p))) for p in points]

def rect3(draw,p,color,outline=None,width=1):
    c=coords(p)
    draw.polygon(c,fill=color)
    if outline: draw.line(c+[c[0]],fill=outline,width=width,joint='curve')

def ln3(draw,p,color,width=2):
    draw.line(coords(p),fill=color,width=width,joint='curve')

def ease(t): return t*t*(3-2*t)
def clip(v,a=0,b=1):return max(a,min(b,v))
def mix(a,b,t):return tuple(int(clip(t)*v+(1-clip(t))*u) for u,v in zip(a,b))
def message(draw,txt,y,mode='big'):
    ft=FONT_BIG if mode=='big' else FONT_MD
    box=draw.textbbox((0,0),txt,font=ft)
    tw=box[2]-box[0]
    draw.rounded_rectangle((max(25,360-tw/2-20),y-12,min(695,360+tw/2+20),y+(box[3]-box[1])+20),radius=16,fill=(10,22,35))
    draw.text((360,y),txt,font=ft,anchor='mt',fill=(255,255,255))

# Stage: person moves toward observer through plane z=0 at t=3.25 s.
def z_at(t):
    # Constant direction, a slower threshold crossing so the world-space
    # comparison appears long enough to inspect. Speed here is for QC only.
    if t<=2.5: return -1.20 + 1.06*ease(clip(t/2.5))
    if t<=3.72: return -.14 + .28*ease(clip((t-2.5)/1.22))
    return .14 + .91*ease(clip((t-3.72)/(5.55-3.72)))

def draw_frame(t):
    memory=clip((t-5.7)/1.15)*clip((9.35-t)/0.9)
    return_stage=clip((t-9.0)/0.8)
    is_mem=memory>0.01
    bg=(226,231,235)
    img=Image.new('RGB',(W,H),bg)
    d=ImageDraw.Draw(img)
    # 3D room behind doorway, vanishing floor lines and sidewalls, neutral no-brand store.
    rect3(d,[(-1.0,0,-3), (1.0,0,-3), (1.0,2.7,-3),(-1.0,2.7,-3)],(66,75,87))
    rect3(d,[(-2.2,0,0),(2.2,0,0),(2.2,2.6,0),(-2.2,2.6,0)],(221,226,230))
    # Dark opening
    rect3(d,[(-0.91,0,0),(0.91,0,0),(0.91,2.30,0),(-0.91,2.30,0)],(47,60,74))
    # Interior floor and lights as motion-depth hints
    rect3(d,[(-0.9,0,-3.0),(0.9,0,-3.0),(0.9,0,1.8),(-0.9,0,1.8)],(166,176,184))
    for z in np.arange(-3,1.95,.45):
        ln3(d,[(-.91,.005,z),(.91,.005,z)],(123,137,148),2)
    for x in [-.83,-.45,0,.45,.83]:
        ln3(d,[(x,.005,-3),(x,.005,1.8)],(126,138,147),2)
    for z in [-2.0,-1.3,-0.6]:
        ln3(d,[(-.65,2.15,z),(.65,2.15,z)],(142,159,173),5)
    # Ground threshold line at z0, visible in front
    ln3(d,[(-.90,.015,0),(.91,.015,0)],(251,184,68),8)
    ln3(d,[(-.90,.015,.045),(.91,.015,.045)],(251,219,137),3)
    # Door sections and glass suggests real door depth, without logos
    ln3(d,[(-.92,0,.045),(-.92,2.35,.045)],(34,51,65),13)
    ln3(d,[(.92,0,.045),(.92,2.35,.045)],(34,51,65),13)
    ln3(d,[(-.92,2.35,.045),(.92,2.35,.045)],(34,51,65),15)
    ln3(d,[(-.90,.06,.045),(.90,.06,.045)],(34,51,65),8)
    # side jamb as flat panel; marker is attached at doorway plane z~0.05
    rect3(d,[(.91,1.46,.076),(1.14,1.46,.076),(1.14,1.94,.076),(.91,1.94,.076)],(235,239,240),(255,255,255),2)
    mapping=[(1.5,1.6,(91,163,80),'150'),(1.6,1.7,(243,203,51),'160'),(1.7,1.8,(207,60,43),'170'),(1.8,1.9,(41,102,174),'180')]
    # Jamb bands and digits (text '170' small independent, based on reference example)
    for lo,hi,co,txt in mapping:
        col=mix(co,(169,176,180),memory*.88) if txt!='170' else mix(co,(215,51,42),memory)
        rect3(d,[(.936,lo,.092),(1.105,lo,.092),(1.105,hi,.092),(.936,hi,.092)],col)
        xx,yy=P(1.022,(lo+hi)/2,.1)
        if memory<.85:
            alpha=1.-memory*.95
            if alpha>.09:
                d.text((xx,yy),txt,font=FONT_TINY,anchor='mm',fill=mix((200,207,211),(255,255,255),alpha))
    # Ghost floor route to the threshold (movement in z)
    for iz in range(7):
        zz=-1.2+iz*.4
        cx,cy=P(-.20,.015,zz)
        rad=max(2,int(4+iz*.3))
        d.ellipse((cx-rad,cy-rad,cx+rad,cy+rad),fill=(248,204,108))
    z=z_at(t) if t<5.6 else (0 if t<9.3 else z_at((t-9.3)*1.6))
    x=-.21
    height=1.735
    # floor-shadow in projected plane
    px,py=P(x,0,z)
    lx,ly=P(x-.33,0,z)
    rx,ry=P(x+.33,0,z)
    d.ellipse((min(lx,rx),py-9,max(lx,rx),py+9),fill=(53,61,70))
    # person silhouette with actual 3D scale depending on z; shoulders 0.46 wide
    headx,heady=P(x,height,z)
    headrx=abs(P(x+.115,height-.13,z)[0]-P(x,height-.13,z)[0]);headry=abs(P(x,height-.23,z)[1]-P(x,height,z)[1])
    bodies=coords([(x-.28,1.39,z),(x+.28,1.39,z),(x+.24,.68,z),(x-.21,.68,z)])
    d.polygon(bodies,fill=(54,65,78))
    # leg divergence and arm swing
    hip=P(x,.76,z)
    footL=P(x-.13,0,z);footR=P(x+.15,0,z)
    d.line([hip,footL],fill=(44,52,63),width=max(9,int(headrx*.57)))
    d.line([hip,footR],fill=(44,52,63),width=max(9,int(headrx*.57)))
    armL=P(x-.29,.86,z);armR=P(x+.29,.85,z)
    leftSh=P(x-.25,1.35,z);rightSh=P(x+.25,1.35,z)
    d.line([leftSh,armL],fill=(67,74,83),width=max(9,int(headrx*.53)))
    d.line([rightSh,armR],fill=(67,74,83),width=max(9,int(headrx*.53)))
    headbox=(headx-headrx,heady,headx+headrx,heady+headry*1.9)
    d.ellipse(headbox,fill=(222,183,153),outline=(75,70,68),width=2)
    # dark hair top to ensure top-of-head location is precise
    d.arc((headx-headrx,heady,headx+headrx,heady+headry*1.7),180,355,fill=(42,40,45),width=max(5,int(headrx*.35)))
    # Foreground depth trace: door opening z=0, not screen horizontal measuring line
    in_zone=clip(1-abs(z)/.17)
    if t<5.65 and in_zone>0:
        # projection of a WORLD 3D line in the SAME depth plane as the marker and head
        ax,ay=P(x,height,0)
        bx,by=P(.94,height,0)
        ol=Image.new('RGBA',(W,H),(0,0,0,0)); od=ImageDraw.Draw(ol)
        od.line([(ax,ay),(bx,by)],fill=(255,220,131,int(255*in_zone)),width=5)
        for p in [(ax,ay),(bx,by)]:
            od.ellipse((p[0]-10,p[1]-10,p[0]+10,p[1]+10),fill=(255,243,197,int(255*in_zone)))
        img=Image.alpha_composite(img.convert('RGBA'),ol).convert('RGB'); d=ImageDraw.Draw(img)
    if t>=5.7 and t<9.4:
        # Memory representation is a distinct tinted overlay, NOT the real doorway losing digits.
        shade=Image.new('RGBA',(W,H),(48,65,78,int(155*memory)))
        img=Image.alpha_composite(img.convert('RGBA'),shade).convert('RGB'); d=ImageDraw.Draw(img)
        # Re-present remembered head spot and red field in a matching 3D view.
        ax,ay=P(-.21,height,0); bx,by=P(.94,height,0)
        redP=coords([(.935,1.7,.12),(1.106,1.7,.12),(1.106,1.8,.12),(.935,1.8,.12)])
        d.polygon(redP,fill=(244,62,50))
        d.ellipse((ax-15,ay-15,ax+15,ay+15),fill=(255,223,182))
        if t>=6.2:
            d.line([(ax,ay),(bx,by)],fill=(250,214,179),width=3)
    elif t>=9.5:
        # Recognition, not mere highlight: one moving echo of the earlier threshold-crossing
        echo=clip((t-9.8)/.85)*clip((11.7-t)/.75)
        if echo>0:
            lay=Image.new('RGBA',(W,H),(0,0,0,0));dd=ImageDraw.Draw(lay)
            ex,ey=P(-.21,1.73,0)
            # The past silhouette briefly reappears ON THE THRESHOLD PLANE,
            # making the entrance itself the thing the viewer reinterprets.
            sh=coords([(-.45,1.37,0),(.02,1.37,0),(.02,.77,0),(-.45,.77,0)])
            dd.polygon(sh,fill=(253,236,211,int(70*echo)))
            hrad=20
            dd.ellipse((ex-hrad,ey-hrad,ex+hrad,ey+hrad),fill=(253,236,211,int(90*echo)))
            bx,by=P(.94,1.73,0)
            dd.line([(ex,ey),(bx,by)],fill=(247,184,112,int(180*echo)),width=4)
            img=Image.alpha_composite(img.convert('RGBA'),lay).convert('RGB');d=ImageDraw.Draw(img)
    # Top and bottom UI panels deliberately not claimed approved/YouTube-safe
    d.rounded_rectangle((30,33,690,122),20,fill=(12,28,45))
    d.text((55,46),'G2 V2｜空間・記憶の動作検証',font=FONT_MD,fill=(255,255,255))
    d.text((56,90),'模式CG／実写・完成映像ではありません',font=FONT_SM,fill=(195,214,228))
    d.rounded_rectangle((30,1022,690,1178),20,fill=(11,24,38))
    if t<5.65:
        title='C03｜通過面で高さを比べる'
        detail='人物が入口の奥行き0mを通る瞬間だけ比較線を表示'
    elif t<9.4:
        title='C05–C06｜数字より色を手掛かりに'
        detail='記憶の再現：数値の印象が薄れ、赤い帯が残る'
    else:
        title='C07｜同じ入口が違って見える'
        detail='人物の通過位置と赤い帯が短く重なって思い出される'
    d.text((54,1039),title,font=FONT_MD,fill=(255,255,255))
    d.text((54,1102),detail,font=FONT_SM,fill=(212,225,233))
    # exact timestamp/geometry overlay
    state='記憶イメージ（現物は変化しない）' if is_mem else '固定カメラ・床を含む3D投影'
    d.text((34,1200),state,font=FONT_TINY,fill=(53,66,80))
    d.text((681,1200),f'{t:04.1f}s',font=FONT_TINY,fill=(53,66,80),anchor='ra')
    return np.asarray(img)

if __name__=='__main__':
    out=cv2.VideoWriter(DEST,cv2.VideoWriter_fourcc(*'mp4v'),FPS,(W,H))
    if not out.isOpened():raise RuntimeError('Cannot open output')
    for i in range(round(FPS*DURATION)):
        im=draw_frame(i/FPS)
        out.write(cv2.cvtColor(im,cv2.COLOR_RGB2BGR))
    out.release()
    print(DEST)
