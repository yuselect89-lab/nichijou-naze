# 再レンダーとレイヤー編集

必要: Blender 4.3（Cycles CPU）、Python 3・Pillow・numpy、FFmpeg。GitHub配布版ではPNG中間キャッシュを省略しています。最初にBlenderの all コマンドで再生成してください。

この source ディレクトリで実行:
```
python3 render_cuts.py          # 全7件。既存出力を上書きするため先に別フォルダへコピーすること
python3 render_cuts.py 2 4      # カットを選択
blender -b -t 4 --python build_walk.py -- all  # 歩行RGBA全150枚を再計算
blender -b -t 1 --python build_walk.py -- bake # .blendへ150形状キーと靴の位置キーを保存
```

`pedestrian-editable.blend` は人体・衣服マテリアル・靴・照明・カメラを編集可能。アニメーションは150フレームの形状キーで保持。入力人体形状はMakeHumanのCC0標準形状から作成し、衣服と歩行はローカル実装。元メッシュの再配布条件は assets/makehuman-CC0.md。

座標: X=画像の左向き、Y=奥行き（店外が正）、Z=高さ。引継ぎ設計書の z=Y、y=Z。敷居Y=0、床Z=0。人物はY=-1.1→+1.085m、2.5秒で敷居。カメラと原画像対応点はcamera.json。頭頂はおよそ1.735mで赤帯の例示範囲1.7〜1.8m。写真は生成画像で実測図面ではなく、投影の適合誤差がある。精密測定を主張しない。比較線は描かない。

assets/entrance-original.png は支給原本を無加工コピー。C01はこの画像のみの編集ズーム。開いたドア背景は内部ImageGenで画像編集したものを入口開口部にだけ合成し、右枠・目盛りと周囲は支給原本を維持。人物は別の3Dレンダーで、AI動画生成ではない。

レイヤー: 背景PNG / 再生成するwalk-rgba/*.png / presenter-*-upperbody.png を独立収録。回想のぼけ・色・記憶の赤帯・残像はrender_cuts.pyの memory_scene / ghost_layer で独立編集。女性キャラは承認版v03_expressions（point_right/thinkはv02から継承）を再利用。身体の歩行・キャラの顔・目盛りを後付け字幕で代用していない。

C01: ズーム1→1.8。C02: 指差し登場・引きへ戻る・退場。C03: ドア開放、接地影、3D歩行。C04: 1→2.3の寄り、思案で導入して退く。C05/06: 同一人物の敷居付近を回想し、数字/細部の解像感が下がり赤い範囲は残る。C07: 青灰色の3姿勢の短い時間残像を表示・消去し、女性キャラが締める。

映像素材には正式帯・字幕・音声・CTA・進行バーを含めない。WorkはG2 PASS後に本編へ1回だけ合成。表示字幕は読点「、」のみ削除し句点「。」保持。原台本・VOを変更しない。
