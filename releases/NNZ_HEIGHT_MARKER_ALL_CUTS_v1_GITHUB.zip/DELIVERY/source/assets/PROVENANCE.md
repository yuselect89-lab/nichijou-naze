# 出所・ライセンス

1. entrance-original.png: ユーザーの同梱画像。引継ぎでは、このチャット内のOpenAI ImageGenによる架空・無ブランド店舗と記載。第三者メーカー写真の転載ではない。実店舗・メーカー製品の正確な再現ではない。生成元アカウントの契約/規約証跡そのものはパックにないため、その独立した法的確認は未実施。
2. entrance-door-open-internal-imagegen.png: 同画像のドア開放だけを本作業内の内部ImageGenで編集（1回）。外部有料AI動画/生成サービス、外部クレジットは不使用。画像編集ツール内部の利用枠・費用は取得できない。合成で開口部以外、特に固定の右枠・目盛りを原本に保つ。
3. makehuman-base-CC0.obj: https://raw.githubusercontent.com/makehumancommunity/makehuman/master/makehuman/data/3dobjs/base.obj 。先頭に2020年9月CC0公開の明記。CC0全文は同リポジトリ LICENSE.ASSETS.md を取得して同梱。人体形状を衣服化・マテリアル化・変形して使用。メーカー素材は不使用。
4. presenter-* 原本: nichijou-naze 共通台帳 NNZ_CHAR_FEMALE_01 / v03_expressions。point_right/thinkはv02_highres継承。原本は改変せずコピー。上半身表示素材は別ファイル。権利記録と検証ハッシュはqc/library-check.json。新たな公式キャラ生成なし。
5. 他のモデル候補は権利/用途を調べただけで映像にも納品素材にも不使用。外部有料AI生成なし、BGM/SE/VOなし。
