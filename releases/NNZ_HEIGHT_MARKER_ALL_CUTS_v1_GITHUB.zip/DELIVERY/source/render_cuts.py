#!/usr/bin/env python3
"""Reproducible cut compositor: Python 3 + Pillow + numpy + FFmpeg.
Run after `blender -b -t 4 --python build_walk.py -- all`.
No AI API. No audio, burned captions or series branding in cut plates.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter,ImageEnhance,ImageChops
import numpy as np, math, subprocess, json,sys
from functools import lru_cache
ROOT=Path(__file__).resolve().parent;DEST=ROOT.parent;W,H=1080,1920;FPS=30
BASE=Image.open(ROOT/'assets/entrance-original.png').convert('RGB').resize((W,H),Image.Resampling.LANCZOS)
CUTS=[('C01_ENTRANCE_DISCOVERY',4),('C02_PURPOSE_REVEAL',5),('C03_THRESHOLD_WALK',5),('C04_COLOR_QUESTION_CLOSEUP',4.5),('C05_MEMORY_NUMBERS_FADE',4.5),('C06_MEMORY_RED_BAND',5.5),('C07_RECOGNITION_GHOST',5.5)]
def clip(t):return max(0,min(1,t))
def ease(t):t=clip(t);return t*t*(3-2*t)
def mix(a,b,t):return a+(b-a)*t
def reframe(im,z=1,cy=860):
 # Right jamb remains attached to its original image. Full image is unchanged.
 ww=W/z;hh=H/z;x0=W-ww;y0=max(0,min(H-hh,cy-hh/2))
 return im.transform((W,H),Image.Transform.EXTENT,(x0,y0,W,y0+hh),Image.Resampling.BICUBIC)
def alpha(im,a):
 im=im.copy();im.putalpha(im.getchannel('A').point(lambda x:int(x*clip(a))));return im
@lru_cache(maxsize=14)
def person(i):return Image.open(ROOT/'walk-rgba'/f'{max(0,min(149,int(i))):04d}.png').convert('RGBA')
# Separate reconstructed open-door plate. Never used by C01 or as the immutable source.
def open_plate():
 return Image.open(ROOT/'assets/entrance-open-reconstructed.png').convert('RGB').resize((W,H),Image.Resampling.LANCZOS)
OPEN=open_plate()
def doorway(t):
 a=ease(t/.95);im=Image.blend(BASE,OPEN,a)
 # Metal centre rails retract to the jambs, without moving the height marker.
 if a<1:
  rail=BASE.crop((546,565,578,1308));x=int(mix(546,249,a));im.paste(rail,(x,565))
 return im
# Soft contact shadows are an independent compositing layer driven by the 3D foot positions.
cam=json.load(open(ROOT/'camera.json'));R=np.array(cam['R_cv']);tr=np.array(cam['t_cv']);F=cam['focal_pixels']
def project(x,y,z):
 q=R@np.array([x,y,z])+tr;return ((470.5+F*q[0]/q[2])*W/941,(836+F*q[1]/q[2])*H/1672)
def contact_shadow(t):
 out=Image.new('RGBA',(W,H));d=ImageDraw.Draw(out)
 ry=-1.1+.44*t;rx=.04+max(0,t-2.5)*.07
 for side in [-1,1]:
  phase=t/1.05+(0 if side==-1 else .5);cy=math.floor(phase);u=phase-cy
  if u<.62:fy=(cy+.31)*.462-1.1;up=0
  else:q=(u-.62)/.38;fy=(cy+.31+q*q*(3-2*q))*.462-1.1;up=math.sin(math.pi*q)
  x,y=project(rx+side*.15,fy,0);rad=18+10*(fy+1.1);d.ellipse((x-rad,y-5,x+rad,y+7),fill=(20,19,17,int(95*(1-up*.8))))
 return out.filter(ImageFilter.GaussianBlur(6))
def walk_scene(i):
 t=i/30;im=doorway(t).convert('RGBA');im.alpha_composite(contact_shadow(t));im.alpha_composite(person(i));return im.convert('RGB')
# Presenter is an approved high-resolution asset, cropped to upper body.
PRESENTERS={}
for name in ['point_right','think','happy']:
 im=Image.open(ROOT/f'assets/presenter-{name}.png').convert('RGBA');bbox=im.getbbox();im=im.crop((bbox[0],bbox[1],bbox[2],min(bbox[3],int(im.height*.58))))
 # All expressions maintain a legible face ~220 px wide in the delivery frame.
 desired=680 if name=='point_right' else 520
 im.thumbnail((desired,760),Image.Resampling.LANCZOS)
 # Feather only bottom edge, keeping the face and gesture unmodified.
 a=np.array(im.getchannel('A'));fade=np.clip((im.height-np.arange(im.height))/50,0,1);a=(a*fade[:,None]).astype('uint8');im.putalpha(Image.fromarray(a));PRESENTERS[name]=im
 im.save(ROOT/f'assets/presenter-{name}-upperbody.png')
def presenter_layer(name,visible,dy=0):
 out=Image.new('RGBA',(W,H));im=alpha(PRESENTERS[name],visible);out.alpha_composite(im,(int(mix(-80,55,ease(visible))),int(850+dy)));return out
def add_presenter(im,name,a,dy=0):out=im.convert('RGBA');out.alpha_composite(presenter_layer(name,a,dy));return out.convert('RGB')
def memory_scene(elapsed):
 # A distinct cool, soft-edged recalled scene; real-world plate is preserved outside this layer.
 q=clip(elapsed/10);idx=int(mix(60,75,ease(elapsed/2)))
 sharp=walk_scene(idx);soft=ImageEnhance.Color(sharp).enhance(mix(.7,.13,q))
 soft=ImageEnhance.Contrast(soft).enhance(mix(.88,.62,q));soft=soft.filter(ImageFilter.GaussianBlur(mix(1.5,12,q)))
 # The source red patch returns, while remembered numerals dissolve. Coordinates remain fixed.
 marker=sharp.crop((976,694,1028,785));marker=ImageEnhance.Brightness(ImageEnhance.Color(marker).enhance(1.55)).enhance(1.35)
 digitfade=ease(elapsed/4.5)
 blurred=marker.filter(ImageFilter.GaussianBlur(8))
 marker=Image.blend(marker,blurred,digitfade)
 soft.paste(marker,(976,694))
 # Keep a soft head-top recollection at the exact same threshold position.
 if elapsed>3:
  mask=Image.new('L',(W,H));d=ImageDraw.Draw(mask);d.ellipse((560,710,650,785),fill=int(150*ease((elapsed-3)/2)));mask=mask.filter(ImageFilter.GaussianBlur(24));soft=Image.composite(sharp.filter(ImageFilter.GaussianBlur(2)),soft,mask)
 # Memory boundary vignette is visual, not explanatory text.
 rim=Image.new('RGBA',(W,H),(24,48,63,0));d=ImageDraw.Draw(rim);d.rounded_rectangle((40,300,1040,1490),radius=100,outline=(172,205,213,110),width=3)
 out=soft.convert('RGBA');out.alpha_composite(Image.new('RGBA',(W,H),(24,48,63,28)));out.alpha_composite(rim)
 return out.convert('RGB')
def ghost_layer(i,a):
 # Three time-offset poses in cyan-grey with actual limb motion; no normal opaque pedestrian.
 out=Image.new('RGBA',(W,H))
 for off,k in [(7,.15),(3,.24),(0,.58)]:
  p=person(i-off);mask=p.getchannel('A').point(lambda v:int(v*a*k));tint=Image.new('RGBA',(W,H),(178,211,214,0));tint.putalpha(mask);out.alpha_composite(tint)
 return out

def frame(c,t):
 if c==0:
  return reframe(BASE,mix(1,1.8,ease((t-.9)/2.6)),800)
 if c==1:
  z=mix(1.8,1,ease(t/1.1));im=reframe(BASE,z,800)
  vis=ease(t/.45)*(1-ease((t-4.1)/.7));return add_presenter(im,'point_right',vis,-520)
 if c==2:return walk_scene(round(t*30))
 if c==3:
  im=reframe(OPEN,mix(1,2.3,ease(t/3.5)),790)
  vis=ease(t/.35)*(1-ease((t-1.65)/.6));return add_presenter(im,'think',vis,10)
 if c in [4,5]:
  elapsed=t+(4.5 if c==5 else 0);im=memory_scene(elapsed)
  if c==4:
   # Match from color close-up into recall without changing the source marker.
   im=reframe(im,mix(2.3,1.15,ease(t/1.4)),790)
   if t<.4:im=Image.blend(reframe(OPEN,2.3,790),im,ease(t/.4))
  else:im=reframe(im,1.15,790)
  return im
 if c==6:
  im=BASE.convert('RGBA');vis=ease((t-.65)/.35)*(1-ease((t-2.8)/.55));i=int(mix(61,90,clip((t-.7)/2.1)))
  im.alpha_composite(ghost_layer(i,vis));im=im.convert('RGB')
  return add_presenter(im,'happy',ease((t-3.5)/.5),20)

def encode(c):
 name,dur=CUTS[c];out=DEST/'video'/f'{name}_v1.mp4';out.parent.mkdir(exist_ok=True)
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','30','-i','-','-an','-c:v','libx264','-threads','3','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(out)]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for j in range(round(dur*30)):
  im=frame(c,j/30);p.stdin.write(im.tobytes())
  if j in [0,round(dur*15),round(dur*30)-1] or (c==0 and j==90) or (c==6 and j in [30,60,90]):
   im.save(DEST/'review'/f'C{c+1:02d}_{j:03d}.jpg',quality=92)
 p.stdin.close();ret=p.wait()
 if ret:raise RuntimeError(f'ffmpeg exit {ret}')
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(out),'-an','-vf','scale=360:640','-c:v','libx264','-threads','2','-crf','20',str(DEST/'review'/f'C{c+1:02d}_360x640.mp4')],check=True)
 print(name,'DONE',flush=True)
if __name__=='__main__':
 for c in ([int(x)-1 for x in sys.argv[1:]] if len(sys.argv)>1 else range(7)):encode(c)
