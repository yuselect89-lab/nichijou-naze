from pathlib import Path
import subprocess,json,hashlib,sys
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parent;D=ROOT.parent
cuts=sorted((D/'video').glob('C*.mp4'));assert len(cuts)==7
info=[]
for f in cuts:
 p=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]))
 v=next(s for s in p['streams'] if s['codec_type']=='video');aud=[s for s in p['streams'] if s['codec_type']=='audio']
 c=int(f.name[1:3]);dur=[4,5,5,4.5,4.5,5.5,5.5][c-1]
 assert (v['width'],v['height'],v['r_frame_rate'],v['codec_name'],v['pix_fmt'])==(1080,1920,'30/1','h264','yuv420p')
 assert len(aud)==0 and int(v['nb_read_frames'])==round(dur*30)
 subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(f),'-f','null','-'],check=True)
 info.append({'cut':f'C{c:02d}','path':str(f.relative_to(D)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'duration_s':float(v['duration']),'fps':v['r_frame_rate'],'resolution':[v['width'],v['height']],'frames':v['nb_read_frames'],'codec':v['codec_name'],'pixel_format':v['pix_fmt'],'audio_streams':len(aud),'full_decode':'PASS'})
 # Sample complete timeline at .5sec for visual temporal QC, at BOTH source/360 scales.
 for j in range(round(dur*2)):
  t=j/2
  subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(f),'-frames:v','1','-update','1',str(D/'review'/f'C{c:02d}_timeline_{j:02d}.jpg')],check=True)
 fs=sorted((D/'review').glob(f'C{c:02d}_timeline_*.jpg'));o=Image.new('RGB',(360*5,680*((len(fs)+4)//5)),(20,26,31));dd=ImageDraw.Draw(o)
 for k,im in enumerate(fs):
  x=k%5*360;y=k//5*680;o.paste(Image.open(im).resize((360,640)),(x,y));dd.text((x+10,y+650),f'C{c:02d} | {k*.5:.1f}s',fill='white')
 o.save(D/'review'/f'C{c:02d}_MOTION_CONTACT.jpg',quality=90)
# Visual-only 34-second rough and its 360px counterpart. Same codec settings, no sound.
for sub,name,glob in [('video','ALL_CUTS_SILENT_QC_ROUGH.mp4','C*.mp4'),('review','ALL_CUTS_SILENT_QC_ROUGH_360.mp4','C??_360x640.mp4')]:
 fs=sorted((D/sub).glob(glob));li=D/'review'/f'concat-{sub}.txt';li.write_text(''.join("file '"+str(f.resolve())+"'\n" for f in fs))
 subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(li),'-c','copy','-movflags','+faststart',str(D/'review'/name)],check=True);li.unlink()
 rough=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-of','json',str(D/'review'/name)]));assert abs(float(rough['format']['duration'])-34)<.02
# asset file hashes and source provenance, including complete rerender inputs
hashes={str(f.relative_to(D)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(D.rglob('*')) if f.is_file() and f.name not in ['ALL_CUTS_MANIFEST.json','SHA256SUMS.txt']}
manifest={'version':'HEIGHT_MARKER_ALL_CUTS_v1','status':'7_RENDERED__QUALITY_LIMITATIONS__G2_NOT_PASS','script':'G1 V1.1 unchanged, not final LOCK','g2':'MINOR_FIX; external re-review not performed','repository_commit':'01730cb8b6be04f6ee9cf2f7e0d1f6134f322ead','video':info,'total_duration_s':34,'presenter':{'id':'NNZ_CHAR_FEMALE_01','version':'v03_expressions','inherited':'point_right/think v02_highres','cuts':['C02','C04','C07']},'red_reference':'supplied original 170 red; illustrative 1.7-1.8m model; not verified manufacturer replica','geometry':'source/camera.json and build_walk.py','source_provenance':'source/assets/PROVENANCE.md','production_preflight':'PASS (qc/production-preflight.log)','repository_tests':'7 test files PASS (qc/repository-tests.log)','library_preflight':'PASS reuse (qc/library-preflight.json and library-check.json)','external_paid_generation':False,'external_ai_video':False,'internal_image_edit_calls':1,'tool_cost':'external paid service/credits not used; internal tool billing not exposed','quality_limitations':['C03 skin/shirt realism and natural walk/scene blending do not meet photoreal production acceptance','C05/C06 inherit the same pedestrian quality limitation','Real-time perceptual playback by human/external QC not performed; full decode and sequential frame inspection performed','Generated photograph is not a measured plan; camera plane reprojection RMS about 10 source pixels','VO/subtitle sync, final CTA, G2/G3 approval outstanding'],'file_hashes':hashes}
(D/'qc/ALL_CUTS_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('ALL 7 TECHNICAL CHECKS PASS, 34s rough verified',flush=True)
