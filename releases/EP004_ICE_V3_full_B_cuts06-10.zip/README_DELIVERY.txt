EP004 白い氷 V3 全10カット。A・B・Cの3つのZIPを同じ場所に展開してください。
EP004_ICE_V3/index.html でプレビュー。編集仕様はEP004_ICE_V3/README.md。
A=Cut01–05 B=Cut06–10 C=ソースとプレビューと依存素材。全編MP4なし。
