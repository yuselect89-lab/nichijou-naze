"""Create an immutable delivery ZIP, reopen it, extract and fully decode 28 videos."""
from pathlib import Path
import json,hashlib,csv,zipfile,tempfile,subprocess,argparse
R=Path(__file__).resolve().parents[1]
NAME='NNZ_VENDING_HEATPUMP_ASSETS_V1_20261101'
def include(p):
 rel=p.relative_to(R)
 return p.is_file() and 'frames' not in rel.parts and '__pycache__' not in rel.parts and not p.name.endswith(('.blend1','.pyc')) and not p.name.startswith('INTERNAL_') and not (rel.parts[0]=='qc' and p.name.endswith(('_labels.png','_character.png')))
def files():return sorted(p for p in R.rglob('*') if include(p))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument('--out',required=True);args=a.parse_args();out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
 if out.exists():raise RuntimeError('Refusing to overwrite existing delivery ZIP')
 for name in ['technical-qc.json','scene-qc.json','playback-qc.json','visual-qc.json']:
  q=json.loads((R/'qc'/name).read_text())
  if q['status']!='PASS':raise RuntimeError('Unresolved required QC: '+name)
 playback=json.loads((R/'qc/playback-qc.json').read_text())
 if len(playback['results'])!=7:raise RuntimeError('All seven actual MP4s must be played')
 if len(json.loads((R/'qc/scene-qc.json').read_text())['edges'])!=7:raise RuntimeError('All seven delivered Blend files must be verified')
 for p,h in json.loads((R/'qc/scene-qc.json').read_text())['file_hashes'].items():
  if sha(R/p)!=h:raise RuntimeError('Stale Blend QC: '+p)
 for item in json.loads((R/'qc/technical-qc.json').read_text())['media']:
  if sha(R/item['file'])!=item['sha256']:raise RuntimeError('Stale technical QC: '+item['file'])
 for item in playback['results']:
  if sha(R/'cuts'/item['cut']/'asset.mp4')!=item['sha256']:raise RuntimeError('Stale playback QC: '+item['cut'])
 base=[p for p in files() if p.name not in ['asset-lock.json','SHA256SUMS.txt','FILELIST.csv']]
 with (R/'FILELIST.csv').open('w',newline='') as f:
  writer=csv.writer(f);writer.writerow(['path','bytes','sha256']);writer.writerows((p.relative_to(R).as_posix(),p.stat().st_size,sha(p)) for p in base)
 locked=base+[R/'FILELIST.csv'];lock={'schema_version':1,'project':'VENDING_HEATPUMP','version':'1.0.0','files':[{'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in locked]}
 (R/'asset-lock.json').write_text(json.dumps(lock,ensure_ascii=False,indent=2))
 (R/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(R).as_posix()+'\n' for p in files() if p.name!='SHA256SUMS.txt'))
 final=files()
 with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in final:z.write(p,NAME+'/'+p.relative_to(R).as_posix())
 checks=[]
 with zipfile.ZipFile(out) as z,tempfile.TemporaryDirectory(prefix='vending-zip-reopen-',dir='/tmp') as tmp:
  assert z.testzip() is None,'ZIP CRC error'
  for p in final:
   name=NAME+'/'+p.relative_to(R).as_posix();assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),'ZIP content mismatch: '+name
  for c in ['C01','C02','C03','C04','C05','C06','C07']:
   for n in ['asset.mp4','scene.mp4','labels.webm','character.webm']:
    name=NAME+'/cuts/'+c+'/'+n;assert name in z.namelist();target=Path(z.extract(name,tmp))
    cmd=['ffmpeg','-hide_banner','-v','error','-threads','2']
    if n.endswith('webm'):cmd+=['-c:v','libvpx-vp9']
    cmd+=['-i',str(target),'-an','-f','null','-'];subprocess.run(cmd,check=True,capture_output=True)
    checks.append({'file':'cuts/'+c+'/'+n,'extracted_from_zip':True,'full_decode':'PASS'})
 digest=sha(out);out.with_suffix(out.suffix+'.sha256').write_text(digest+'  '+out.name+'\n')
 report={'status':'PASS','zip':str(out),'sha256':digest,'bytes':out.stat().st_size,'entries':len(final),'crc':'PASS','all_entry_hashes':'PASS','reopened_zip_and_full_decoded_videos':checks}
 out.with_suffix('.verification.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='reopened_zip_and_full_decoded_videos'},indent=2))
if __name__=='__main__':main()
