from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,hashlib
R=Path(__file__).resolve().parents[1]
N={'C01':90,'C02':90,'C03':120,'C04':90,'C05':90,'C06':150,'C07':120}
A=['自販機の「つめた〜い」と「あったか〜い」。','どうやって同時に冷やして温めていると思いますか？','実は一部の自販機では、冷やすときに取り出した熱を、温めるために使っているんです。','飲み物を冷やすとは、熱を奪うこと。','その熱を外に捨てず、','ヒートポンプという仕組みで、温かい飲み物がある庫内へ運びます。','つまり、自販機の中では「冷やす」と「温める」がつながっていたんです。']
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
checks={n:json.loads((R/'qc'/n).read_text())['status'] for n in ['technical-qc.json','scene-qc.json','playback-qc.json','visual-qc.json']}
if any(s!='PASS' for s in checks.values()):raise RuntimeError('Required material QC incomplete')
cuts=[]
for (c,n),anchor in zip(N.items(),A):
 files={k:f'cuts/{c}/{v}' for k,v in {'composite':'asset.mp4','scene':'scene.mp4','labels_alpha':'labels.webm','character_alpha':'character.webm'}.items()}
 pose={'C02':'think','C03':'surprise','C07':'happy'}.get(c)
 cuts.append({'id':'NNZ_VENDING_HP_'+c,'cut':c,'version':'1.0.0','state':'QC_PASS_MATERIALS_ONLY','files':files,'file_hashes':{p:sha(p) for p in files.values()},'source_blend':f'source/blender/{c}.blend','source_code':['source/build_scene.py','source/compose.py'],'frames':n,'fps':30,'resolution':[1080,1920],'audio':False,'duration_is_measured_vo':False,'vo_anchor':anchor,'shared_assets':[{'asset_id':'NNZ_CHAR_FEMALE_01','version':'v03_expressions','pose':pose}] if pose else [],'depends_on':['NNZ_VENDING_HP_EXT_MASTER@1.0.0','NNZ_VENDING_HP_CUTAWAY_MASTER@1.0.0'] if c in ['C03','C07'] else ['NNZ_VENDING_HP_EXT_MASTER@1.0.0' if c in ['C01','C02'] else 'NNZ_VENDING_HP_CUTAWAY_MASTER@1.0.0']})
m={'schema_version':1,'project':'VENDING_HEATPUMP','version':'1.0.0','generated_at_jst':datetime.now(ZoneInfo('Asia/Tokyo')).isoformat(timespec='seconds'),'order_date':'2026-11-01','source_repository':'yuselect89-lab/nichijou-naze','source_commit':'2639ca42e5e37c8e70cbafd9f3abb13410c242cb','production_lock':{'path':'production-lock.json','sha256':sha('production-lock.json')},'g1_reference':'reference/G1_V2_LOCKED_EXTRACT.md','g2_reference':'reference/NNZ_VENDING_HEATPUMP_G2_VISUAL_DESIGN_V2_REFERENCE_20261101.md','assets':[{'asset_id':'NNZ_CHAR_FEMALE_01','version':'v03_expressions','pose':p} for p in ['think','surprise','happy']],'episode_assets':[{'asset_id':'NNZ_VENDING_HP_EXT_MASTER','version':'1.0.0','scope':'episode','state':'QC_PASS_MATERIALS_ONLY','entrypoint':'assets/EXT_MASTER_AI.png','source':'source/build_scene.py','provenance':'PROVENANCE.json'},{'asset_id':'NNZ_VENDING_HP_CUTAWAY_MASTER','version':'1.0.0','scope':'episode','state':'QC_PASS_MATERIALS_ONLY','entrypoint':'source/blender/C03.blend','source':'source/build_scene.py','components':['CH_COLD','CH_HOT','HX_COLD','COMP','HX_HOT','EXP'],'independent_tracks':['HEAT_ENERGY','REFRIGERANT','POWER']}],'cuts':cuts,'qc':checks,'handoff':'WORK_HANDOFF.md','not_performed':['actual VO synchronization','completed episode assembly','final G3','independent external material review'],'source_frame_cache_included':False,'playback':'Open cuts/Cxx/asset.mp4. Rebuild and layer instructions in WORK_HANDOFF.md.'}
for aid,col in [('NNZ_VENDING_HP_HEAT_PATH','HEAT_ENERGY'),('NNZ_VENDING_HP_REFRIGERANT_LOOP','REFRIGERANT'),('NNZ_VENDING_HP_ELECTRICAL_INPUT','POWER')]:
 m['episode_assets'].append({'asset_id':aid,'version':'1.0.0','scope':'episode','state':'QC_PASS_MATERIALS_ONLY','entrypoint':'source/blender/C06.blend','collection':col,'source':'source/build_scene.py','dependencies':['NNZ_VENDING_HP_CUTAWAY_MASTER@1.0.0']})
m['episode_assets'].append({'asset_id':'NNZ_VENDING_HP_LABELS','version':'1.0.0','scope':'episode','state':'QC_PASS_MATERIALS_ONLY','source':'source/compose.py','files':[f'cuts/{c}/labels.webm' for c in N],'dependencies':['assets/NotoSansCJKjp-Bold.otf','assets/NotoSansCJK-Regular.ttc']})
(R/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
print('Manifest saved for seven verified cuts')
