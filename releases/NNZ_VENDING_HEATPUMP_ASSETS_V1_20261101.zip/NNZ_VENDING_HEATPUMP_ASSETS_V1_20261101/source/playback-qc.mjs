// Run from the development repository (uses its pinned @remotion/renderer).
// Play every actual MP4 to ended in Chromium; frame callbacks prove time advances.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {openBrowser} from '@remotion/renderer';
import {createHash} from 'node:crypto';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const pageHtml='<html><body style="margin:0;background:#f4f6f7"><video id="v" muted playsinline style="display:block;width:360px;height:640px"></video><canvas id="c" width="360" height="640" style="display:none"></canvas></body></html>';
const server=http.createServer((req,res)=>{
 if(req.url==='/'){res.setHeader('Content-Type','text/html');res.end(pageHtml);return;}
 const name=req.url.replace(/^\//,'');
 if(!/^C0[1-7]\.mp4$/.test(name)){res.statusCode=404;res.end();return;}
 const f=path.join(root,'cuts',name.slice(0,3),'asset.mp4');const size=fs.statSync(f).size;
 res.setHeader('Content-Type','video/mp4');res.setHeader('Accept-Ranges','bytes');
 const range=req.headers.range?.match(/bytes=(\d+)-(\d*)/);
 if(range){const start=Number(range[1]),end=range[2]?Number(range[2]):size-1;res.writeHead(206,{'Content-Range':`bytes ${start}-${end}/${size}`,'Content-Length':end-start+1});fs.createReadStream(f,{start,end}).pipe(res);}
 else{res.setHeader('Content-Length',size);fs.createReadStream(f).pipe(res);}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'}});
const results=[];
try{
 const page=await browser.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
 await page.setViewport({width:360,height:640,deviceScaleFactor:1});
 await page.goto({url:`http://127.0.0.1:${server.address().port}/`,timeout:20000,options:{waitUntil:'load'}});
 const selected=process.argv.slice(2).length?process.argv.slice(2):['C01','C02','C03','C04','C05','C06','C07'];
 for(const cut of selected){
  const r=await page.evaluate(async(cut)=>{
   const v=document.getElementById('v'),canvas=document.getElementById('c'),ctx=canvas.getContext('2d',{willReadFrequently:true});
   v.src='/'+cut+'.mp4';v.muted=true;v.load();
   await new Promise((ok,no)=>{v.onloadedmetadata=ok;v.onerror=()=>no(Error(v.error?.message||'video error'));});
   const observed=[];let active=true;let callbacks=0;
   const frame=(now,m)=>{if(!active)return;callbacks++;if(observed.length===0||m.mediaTime-observed.at(-1).time>.15){ctx.drawImage(v,0,0,360,640);const pixels=ctx.getImageData(0,0,360,640).data;let signature=0;for(let i=0;i<pixels.length;i+=53)signature=(signature*31+pixels[i])>>>0;observed.push({time:m.mediaTime,signature});}v.requestVideoFrameCallback(frame);};
   v.requestVideoFrameCallback(frame);
   const end=new Promise((ok,no)=>{v.onended=ok;v.onerror=()=>no(Error(v.error?.message||'decode failure'));setTimeout(()=>no(Error('playback timeout')),20000);});
   await v.play();await end;active=false;
   const quality=v.getVideoPlaybackQuality();
   return {cut,ended:v.ended,duration:v.duration,currentTime:v.currentTime,width:v.videoWidth,height:v.videoHeight,callbacks,totalVideoFrames:quality.totalVideoFrames,droppedVideoFrames:quality.droppedVideoFrames,samples:observed,distinctSamples:new Set(observed.map(x=>x.signature)).size};
  },cut);
  r.status=r.ended&&r.width===1080&&r.height===1920&&r.callbacks>10&&r.distinctSamples>3?'PASS':'FAIL';r.sha256=createHash('sha256').update(fs.readFileSync(path.join(root,'cuts',cut,'asset.mp4'))).digest('hex');results.push(r);console.log(cut,r.status,r.callbacks,'frame callbacks');
 }
 const report={status:results.every(x=>x.status==='PASS')?'PASS':'FAIL',method:'Actual realtime HTMLVideoElement playback in Chromium at 360x640 until ended; requestVideoFrameCallback, decoded frame count and changing canvas samples recorded. This verifies playback and motion, not semantic approval.',results};
 fs.writeFileSync(path.join(root,'qc/playback-qc.json'),JSON.stringify(report,null,2));
 if(report.status!=='PASS')process.exitCode=1;
}finally{await browser.close({silent:true});await new Promise(r=>server.close(r));}
