from pathlib import Path
import subprocess,sys,time,json
R=Path(__file__).resolve().parents[1];repo=R.parents[3]
log=R/'qc/logs/compose-all.txt'
while not log.exists() or 'ALL_SEVEN_COMPOSED' not in log.read_text():time.sleep(2)
def run(cmd,name,cwd=None):
 with (R/'qc/logs'/name).open('w') as f:subprocess.run(cmd,cwd=cwd or repo,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('CHECK_COMPLETE',name,flush=True)
run(['node',str(R/'tools/verify-production.mjs')],'preflight-final.txt',R)
run([sys.executable,str(R/'source/verify_delivery.py')],'technical-final.txt')
run(['node',str(R/'source/playback-qc.mjs')],'playback-final.txt')
run([sys.executable,str(R/'source/build_qc_evidence.py')],'evidence-final.txt')
for c in ['C01','C02','C03','C04','C05','C06','C07']:
 dest=R/'qc/evidence'/c;cmd=['node',str(repo/'tools/media-evidence.mjs'),str(R/'cuts'/c),'--out',str(dest),'--limit','6']
 if (dest/'evidence.json').exists():cmd+=['--prior',str(dest/'evidence.json')]
 run(cmd,'evidence-'+c+'.txt')
print('ALL_FINAL_MACHINE_CHECKS_COMPLETE',flush=True)
