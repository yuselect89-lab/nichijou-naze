"""Package each completed cut once, preserving failure exit codes."""
from pathlib import Path
import subprocess,time,sys,json,argparse
from compose import ROOT,CUTS
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--start-cut',default='C01');a=ap.parse_args()
 selected=list(CUTS)[list(CUTS).index(a.start_cut):]
 for c in selected:
  n=CUTS[c]
  frames=ROOT/'source/frames'/c
  while len(list(frames.glob('*.png')))<n:time.sleep(2)
  # Last file appears while PNG is being saved; wait until its encoder completes.
  while True:
   try:
    from PIL import Image
    # Cached endpoints may already exist; verify every PNG, including the
    # currently written frame, instead of assuming the highest number is last.
    for i in range(n):
     with Image.open(frames/f'{i:04}.png') as im:im.load()
    break
   except (OSError,FileNotFoundError):time.sleep(1)
  subprocess.run([sys.executable,str(ROOT/'source/compose.py'),'--cut',c],check=True)
 print('ALL_SEVEN_COMPOSED',flush=True)
if __name__=='__main__':main()
