"""Evidence comes from actual encoded MP4 frames, not scene-design mockups."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json,tempfile
R=Path(__file__).resolve().parents[1];Q=R/'qc';T=Q/'temporal';T.mkdir(exist_ok=True)
N={'C01':90,'C02':90,'C03':120,'C04':90,'C05':90,'C06':150,'C07':120}
font=ImageFont.truetype(str(R/'assets/NotoSansCJKjp-Bold.otf'),22)
all_mid=[]
def frame(file,n,out,width=None):
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(file),'-vf',f'select=eq(n\\,{n})'+(f',scale={width}:-1' if width else ''),'-frames:v','1',str(out)];subprocess.run(cmd,check=True)
 return Image.open(out).convert('RGB')
for c,n in N.items():
 sheet=Image.new('RGB',(5*216,416),(235,239,242));d=ImageDraw.Draw(sheet)
 for i,u in enumerate([0,.25,.5,.75,1]):
  f=round((n-1)*u);p=T/f'{c}_{f:04}.jpg';im=frame(R/'cuts'/c/'asset.mp4',f,p,216);sheet.paste(im,(i*216,30));d.text((i*216+5,3),f'{c}  {f:03}f',font=font,fill='#203b49')
 sheet.save(Q/f'{c}_motion.jpg',quality=95)
 p=T/f'{c}_mid360.jpg';im=frame(R/'cuts'/c/'asset.mp4',round((n-1)*.5),p,360);all_mid.append(im)
gallery=Image.new('RGB',(4*360,2*640),'#e7edf0')
for i,im in enumerate(all_mid):gallery.paste(im,((i%4)*360,(i//4)*640))
gallery.save(Q/'all-cuts-360.jpg',quality=95);gallery.convert('L').save(Q/'all-cuts-360-grayscale.jpg',quality=95)
pair=Image.new('RGB',(720,640),'white')
for i,c in enumerate(['C01','C07']):
 im=frame(R/'cuts'/c/'scene.mp4',N[c]-1,T/f'{c}_identity.jpg',360);pair.paste(im,(i*360,0))
pair.save(Q/'C01-C07-identity.jpg',quality=95)
# Continuity preview is QC evidence only, not a completed voiced episode.
listing=Q/'continuity-inputs.txt';listing.write_text(''.join("file '../cuts/"+c+"/asset.mp4'\n" for c in ['C03','C04','C05','C06']))
subprocess.run(['ffmpeg','-hide_banner','-v','error','-y','-f','concat','-safe','0','-i',str(listing),'-an','-c','copy','-movflags','+faststart',str(Q/'C03-C06-continuity.mp4')],check=True)
safe=Image.new('RGB',(3*360,640),'#e7edf0')
for i,c in enumerate(['C01','C02','C06']):
 im=frame(R/'cuts'/c/'asset.mp4',0 if c=='C01' else N[c]-1,T/f'{c}_safety.png').convert('RGBA')
 if c=='C01':im.alpha_composite(Image.open(R/'public/series/approved/opening_banner.png').convert('RGBA').resize((920,920),Image.Resampling.LANCZOS),(80,88))
 mask=Image.new('RGBA',im.size);d=ImageDraw.Draw(mask);d.rectangle((96,1510,984,1790),fill=(20,40,55,190));d.rectangle((984,580,1080,1790),fill=(20,40,55,90));im.alpha_composite(mask);safe.paste(im.resize((360,640),Image.Resampling.LANCZOS).convert('RGB'),(i*360,0))
safe.save(Q/'protected-ui-test.jpg',quality=95)
(Q/'font-verification.json').write_text(json.dumps({'bold':ImageFont.truetype(str(R/'assets/NotoSansCJKjp-Bold.otf'),40).getname(),'regular':ImageFont.truetype(str(R/'assets/NotoSansCJK-Regular.ttc'),40).getname(),'substitution':False,'usage':'actual file paths in compose.py, no system fallback'},ensure_ascii=False,indent=2))
print('Actual video evidence generated')
