"""Editable 3D production scene. Run with Blender 4.3, no add-ons required.
All coordinates/IDs are shared across every cut. No voice timing is assumed.
"""
import bpy, math, json, sys, os, argparse
from pathlib import Path
from mathutils import Vector

ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--cut',default='C03');ap.add_argument('--still',type=int);ap.add_argument('--all',action='store_true');ap.add_argument('--samples',type=int,default=8);ap.add_argument('--save-only',action='store_true');ap.add_argument('--frames',default='');ap.add_argument('--engine',default='CYCLES');ap.add_argument('--scale',type=int,default=100)
args=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
S=bpy.context.scene;S.render.engine=args.engine
if args.engine=='CYCLES':
 S.cycles.samples=args.samples;S.cycles.use_denoising=False;S.cycles.max_bounces=3;S.cycles.transparent_max_bounces=6;S.cycles.use_adaptive_sampling=True;S.cycles.adaptive_threshold=.12
elif args.engine=='BLENDER_EEVEE_NEXT':
 S.eevee.taa_render_samples=args.samples
S.render.resolution_x=1080;S.render.resolution_y=1920;S.render.resolution_percentage=args.scale
S.render.fps=30;S.render.image_settings.file_format='PNG';S.render.image_settings.color_mode='RGB';S.render.image_settings.compression=15
S.render.threads_mode='FIXED';S.render.threads=4;S.render.film_transparent=False
S.world.color=(.8,.8,.8);S.world.use_nodes=True;wn=S.world.node_tree;bg=wn.nodes['Background'];bg.inputs[0].default_value=(.76,.80,.84,1);bg.inputs[1].default_value=.45
wb=wn.nodes.new('ShaderNodeBackground');wb.inputs[0].default_value=(.91,.93,.94,1);wb.inputs[1].default_value=1
lp=wn.nodes.new('ShaderNodeLightPath');wm=wn.nodes.new('ShaderNodeMixShader');wn.links.new(lp.outputs['Is Camera Ray'],wm.inputs[0]);wn.links.new(bg.outputs[0],wm.inputs[1]);wn.links.new(wb.outputs[0],wm.inputs[2]);wn.links.new(wm.outputs[0],wn.nodes['World Output'].inputs[0])
S.view_settings.view_transform='Standard';S.view_settings.look='Medium High Contrast' if False else 'None';S.view_settings.exposure=0;S.view_settings.gamma=1
S.render.use_file_extension=True
COL={}
for name in ['EXT_MASTER','CUTAWAY_MASTER','PRODUCTS','HEAT_ENERGY','REFRIGERANT','POWER','LIGHTS']:
 c=bpy.data.collections.new(name);S.collection.children.link(c);COL[name]=c
def move(o,col):
 for c in list(o.users_collection):c.objects.unlink(o)
 COL[col].objects.link(o);return o
def rgba(h):
 def lin(v):return v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4
 return tuple(lin(int(h[i:i+2],16)/255) for i in (0,2,4))+(1,)
def mat(name,color,metal=0,rough=.4,emission=0):
 m=bpy.data.materials.new(name);m.diffuse_color=rgba(color);m.use_nodes=True;m.surface_render_method='DITHERED';p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=rgba(color);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;p.inputs['Emission Color'].default_value=rgba(color);p.inputs['Emission Strength'].default_value=emission;return m
white=mat('Warm ceramic enamel','f0f2f0',.15,.3);silver=mat('Brushed aluminum','a8b2b8',.65,.25);dark=mat('Graphite mechanism','223b4a',.35,.32);cold=mat('Cold compartment','c4e3ed',.1,.45);hot=mat('Warm compartment','f4d7c0',.1,.45);copper=mat('Heat exchanger copper','c47d40',.65,.28);pipe=mat('REFRIGERANT conduit - physical closed loop','8b9aa4',.45,.3);heatmat=mat('ENERGY symbol amber - not matter','ffac26',.15,.25,1.2);refmat=mat('REFRIGERANT small cyan chevrons','169bb4',.2,.3,.4);power=mat('Electrical energy','445ec2',.2,.3,.4)
FADES=[]
def fadeable(m):
 nt=m.node_tree;out=nt.nodes.get('Material Output');old=out.inputs['Surface'].links[0].from_socket;mix=nt.nodes.new('ShaderNodeMixShader');tr=nt.nodes.new('ShaderNodeBsdfTransparent');nt.links.new(tr.outputs[0],mix.inputs[1]);nt.links.new(old,mix.inputs[2]);nt.links.new(mix.outputs[0],out.inputs['Surface']);mix.inputs[0].default_value=1;return mix.inputs[0]
def box(name,loc,dim,ma,col='CUTAWAY_MASTER',bevel=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma);move(o,col)
 if bevel:mod=o.modifiers.new('Soft physical edge','BEVEL');mod.width=bevel;mod.segments=2;o.modifiers.new('Normals','WEIGHTED_NORMAL')
 return o
def cyl(name,loc,r,depth,ma,col='CUTAWAY_MASTER',vertices=24):
 bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=depth,location=loc);o=bpy.context.object;o.name=name;o.data.materials.append(ma);move(o,col)
 for f in o.data.polygons:f.use_smooth=True
 b=o.modifiers.new('Rolled edge','BEVEL');b.width=.008;b.segments=2;return o
def curve(name,pts,r,ma,col='CUTAWAY_MASTER'):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=12;cu.bevel_depth=r;cu.bevel_resolution=3;sp=cu.splines.new('POLY');sp.points.add(len(pts)-1)
 for p,v in zip(sp.points,pts):p.co=(*v,1)
 o=bpy.data.objects.new(name,cu);COL[col].objects.link(o);o.data.materials.append(ma);return o
def sphere(name,loc,r,ma,col):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=6,radius=r,location=loc);o=bpy.context.object;o.name=name;o.data.materials.append(ma);move(o,col);return o
def aim(o,target):o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
def light(name,loc,energy,size):
 d=bpy.data.lights.new(name,'AREA');d.energy=energy;d.shape='DISK';d.size=size;d.use_shadow_jitter=False;o=bpy.data.objects.new(name,d);COL['LIGHTS'].objects.link(o);o.location=loc;aim(o,(0,0,3));return o
light('Soft daylight',(-3,-5,7),230,5);light('Cool fill',(4,-2,5),120,4);light('Rim',(1,3,6),160,3)
camdat=bpy.data.cameras.new('Camera');cam=bpy.data.objects.new('Camera',camdat);S.collection.objects.link(cam);S.camera=cam;camdat.type='ORTHO';camdat.ortho_scale=9

# Camera-projected AI photography on separate 3D body, shelf and cylindrical meshes.
# This is a multi-depth photographic reconstruction, never a single flat pan.
photo=bpy.data.images.load(str(ROOT/'assets/EXT_MASTER_AI.png'));photo.pack()
pm=bpy.data.materials.new('AI photo projection / immutable source');pm.use_nodes=True;pm.surface_render_method='BLENDED';nt=pm.node_tree;nt.nodes.clear();tex=nt.nodes.new('ShaderNodeTexImage');tex.image=photo;em=nt.nodes.new('ShaderNodeEmission');em.inputs[1].default_value=1;nt.links.new(tex.outputs['Color'],em.inputs[0]);out=nt.nodes.new('ShaderNodeOutputMaterial');nt.links.new(em.outputs[0],out.inputs[0]);FADES.append(fadeable(pm))
W,H=photo.size[:];K=6/H
def X(p):return (p-W/2)*K
def Z(p):return 6-p*K
def proj(o):
 bpy.context.view_layer.update()
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='AI projection')
 for poly in o.data.polygons:
  for li in poly.loop_indices:
   v=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=((v.x/K+W/2)/W,v.z/6)
 o.data.materials.clear();o.data.materials.append(pm)
def photoquad(name,pts,depth=0):
 me=bpy.data.meshes.new(name);verts=[(X(p[0]),depth if len(p)==2 else p[2],Z(p[1])) for p in pts];me.from_pydata(verts,[],[list(range(len(pts)))]);me.update();o=bpy.data.objects.new(name,me);COL['EXT_MASTER'].objects.link(o);proj(o);return o
def rect(name,l,t,r,b,depth=0):return photoquad(name,[(l,t),(r,t),(r,b),(l,b)],depth)
photoquad('EXT_top',[(89,269),(770,255),(770,310),(89,322)])
rect('EXT_left_metal',89,320,141,1390)
rect('EXT_right_payment',663,310,770,1400)
rect('EXT_base_dispensing',140,989,664,1395)
rect('EXT_center_mullion',403,310,434,990,-.025)
rect('EXT_window_cold',141,310,404,990,.15)
rect('EXT_window_hot',434,310,664,990,.15)
photoquad('EXT_side_depth',[(770,255,0),(872,322,.53),(872,1340,.53),(770,1400,0)])
for row,(top,bottom) in enumerate([(409,536),(615,736),(818,935)]):
 for bay,centers in [('COLD',[221,292,365]),('HOT',[487,556,625])]:
  for i,x in enumerate(centers):
   o=cyl(f'EXT_CAN_{bay}_{row}_{i}',(X(x),.04,(Z(top)+Z(bottom))/2),K*31,(bottom-top)*K,white,'EXT_MASTER',32);proj(o)
for row,(top,bottom) in enumerate([(532,566),(732,766),(933,969)]):
 for bay,l,r in [('COLD',174,403),('HOT',440,664)]:rect(f'EXT_SHELF_{bay}_{row}',l,top,r,bottom,-.09)
for x in [120,750]:rect('EXT_feet_'+str(x),x-15,1384,x+20,1420,.02)

# Permanent shared scientific model; explicit component IDs are actual object names.
box('CHASSIS_BACK',(-.15,.56,3),(2.5,.10,4.18),white)
for x in [-1.36,1.08]:box('CHASSIS_POST', (x,.23,3),(.08,.7,4.18),silver)
box('CHASSIS_BASE',(-.15,.24,.96),(2.5,.72,.16),white)
box('CHASSIS_TOP',(-.15,.24,5.05),(2.5,.72,.10),white)
box('CABINET_SEPARATOR',(-.15,.24,2.43),(2.5,.72,.08),white)
for bay,x,ma in [('COLD',-.69,cold),('HOT',.28,hot)]:
 box('CH_'+bay,(x,.38,3.70),(.93,.18,2.43),ma)
 for sx in [-.46,.46]:box('CH_'+bay+'_WALL',(x+sx,.12,3.7),(.035,.54,2.43),white)
 for row,(top,bottom) in enumerate([(409,536),(615,736),(818,935)]):
  zz=(Z(top)+Z(bottom))/2
  box(f'SHELF_{bay}_{row}',(x,.06,Z(bottom)-.03),(.89,.5,.04),silver)
  for i,xx in enumerate([x-.26,x,x+.26]):
   cyl(f'CAN_{bay}_{row}_{i}',(xx,-.025,zz),.105,(bottom-top)*K,mat(f'can_{bay}_{row}_{i}', 'a0c1cf' if bay=='COLD' else 'eacbaf',.7,.22),'PRODUCTS')
   cyl(f'CAN_LID_{bay}_{row}_{i}',(xx,-.025,Z(top)+.008),.102,.012,silver,'PRODUCTS')
   # Clean generic lower label bands, no synthetic lettering.
   cyl(f'CAN_BAND_{bay}_{row}_{i}',(xx,-.025,zz-.08),.106,.12,mat(f'band_{bay}_{row}_{i}','2f769c' if bay=='COLD' else 'ce654c',.15,.3),'PRODUCTS')
for id,x in [('HX_COLD',-.70),('HX_HOT',.29)]:
 box(id,(x,.08,2.24),(.61,.25,.30),dark)
 for i in range(12):box(id+'_FIN_'+str(i),(x-.27+i*.049,-.085,2.24),(.015,.035,.27),silver,bevel=.004)
 pts=[]
 for i in range(7):
  xx=x-.27+i*.09;pts.extend([(xx,-.13,2.12),(xx,-.13,2.36)] if i%2==0 else [(xx,-.13,2.36),(xx,-.13,2.12)])
 curve(id+'_COPPER',pts,.015,copper)
comp=cyl('COMP',(-.10,.06,1.60),.235,.48,dark)
box('COMP_FEET',(-.10,.06,1.32),(.59,.48,.08),silver)
exp=box('EXP',(.68,-.04,1.23),(.22,.19,.23),copper)
for i in range(5):cyl('EXP_FIN_'+str(i),(.68,-.04,1.15+i*.036),.14,.018,silver)

LOOP=[(-.70,-.20,2.24),(-.70,-.20,1.70),(-.35,-.20,1.70),(-.10,-.20,1.78),(.29,-.20,1.95),(.29,-.20,2.24),(.68,-.20,2.24),(.68,-.20,1.23),(-.96,-.20,1.23),(-.96,-.20,2.24),(-.70,-.20,2.24)]
curve('REFRIGERANT_CLOSED_LOOP',LOOP,.027,pipe,'REFRIGERANT')
# Warm energy paths live OUTSIDE the refrigerant pipe, and never complete a loop.
P1=[(-.69,-.30,3.85),(-.69,-.30,3.35),(-.69,-.30,2.75),(-.70,-.30,2.24)]
P2=[(-.70,-.36,2.24),(-.60,-.36,1.90),(-.25,-.36,1.90),(-.10,-.36,1.85),(.12,-.36,2.04),(.29,-.36,2.24)]
P3=[(.29,-.30,2.24),(.29,-.30,2.75),(.29,-.30,3.30),(.29,-.30,3.85)]
ENERGY=P1+P2[1:]+P3[1:]
curve('Energy_guide_not_refrigerant',ENERGY,.012,mat('Energy guide faint','e3b26d',0,.6),'HEAT_ENERGY')
def point_on(pts,t):
 ds=[(Vector(b)-Vector(a)).length for a,b in zip(pts,pts[1:])];dist=max(0,min(.999999,t))*sum(ds)
 for a,b,d in zip(pts,pts[1:],ds):
  if dist<=d:return Vector(a).lerp(Vector(b),dist/d)
  dist-=d
 return Vector(pts[-1])
heat=[sphere(f'ENERGY_PACKET_{i:02}',(0,0,0),.070,heatmat,'HEAT_ENERGY') for i in range(13)]
reservoir=[sphere(f'SOURCE_HEAT_{i}',(-.69,-.34,4.30-i*.42),.055,heatmat,'HEAT_ENERGY') for i in range(3)]
ref=[]
for i in range(17):
 # A thin arrowhead, deliberately different from the thick amber energy beads.
 o=curve(f'REFRIGERANT_ARROW_{i:02}',[(-.035,0,-.025),(0,0,.025),(.035,0,-.025)],.010,refmat,'REFRIGERANT');ref.append(o)
bolt=curve('POWER_INTO_COMP',[(-1.1,-.28,1.57),(-.85,-.28,1.57),(-.90,-.28,1.45),(-.52,-.28,1.63),(-.65,-.28,1.63),(-.38,-.28,1.65)],.028,power,'POWER')

# Shared camera/state anchors: neighboring boundaries use identical poses and phases.
# Media durations are reusable motion units, NOT a final VO timeline.
CUTS={'C01':90,'C02':90,'C03':120,'C04':90,'C05':90,'C06':150,'C07':120}
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def mix(a,b,t):return a+(b-a)*t
def camera(x,z,scale,y=-9,orbit=0):
 cam.location=(x+orbit,y,z);aim(cam,(x,0,z));cam.data.ortho_scale=scale
def state(c,t):
 ext=1;internal=0;phase=0
 if c=='C01':
  if t<.66:camera(mix(-.58,.36,ease(t/.66)),3.88,4.8,orbit=mix(-.18,.16,t))
  else:camera(mix(.36,-.5,ease((t-.66)/.34)),mix(3.88,3.30,ease((t-.66)/.34)),mix(4.8,9,ease((t-.66)/.34)),orbit=mix(.16,0,ease((t-.66)/.34)))
 elif c=='C02':camera(-.5,3.30,9,orbit=.035*math.sin(t*math.pi))
 elif c=='C03':
  u=ease(max(0,(t-.24)/.60));ext=1-u;internal=u;camera(mix(-.5,0,u),3.30,9,orbit=.65*u);phase=t*.4
 elif c=='C04':
  ext=0;internal=1;u=ease(t);camera(mix(0,-.48,u),mix(3.30,3.35,u),mix(9,6.6,u),orbit=.65);phase=.4+t*.38
 elif c=='C05':
  ext=0;internal=1;u=ease(t);camera(mix(-.48,-.12,u),mix(3.35,3.25,u),mix(6.6,7.9,u),orbit=.65);phase=.78+t*.38
 elif c=='C06':
  ext=0;internal=1;camera(-.12,3.25,7.9,orbit=.65);phase=1.16+t*.75
 elif c=='C07':
  u=ease(t/.62);ext=u;internal=1-u;camera(mix(-.12,-.5,u),mix(3.25,3.30,u),mix(7.9,9,u),orbit=.65*(1-u));phase=1.91+t*.4
 for f in FADES:f.default_value=ext
 for obj in COL['EXT_MASTER'].objects:obj.hide_render=ext<=.001
 for col in ['CUTAWAY_MASTER','PRODUCTS','HEAT_ENERGY','REFRIGERANT','POWER']:
  for o in COL[col].objects:o.hide_render=internal<=.001
 # Soft continuous replacement, retaining the exact same camera and shelf positions.
 for f in INTERNAL_FADES:f.default_value=1
 for i,o in enumerate(heat):
  # Persistent IDs and global phase across C03-C07; no cut-local reset.
  energy_phase={'C01':0,'C02':0,'C03':t*.108,'C04':.108+t*.292,'C05':.400+t*.230,'C06':.630+t*.370,'C07':1+t*.108}[c]
  u=(i/len(heat)+energy_phase)%1;o.location=point_on(ENERGY,u)
  o.scale=(1,)*3
 source_amp=(1-ease(t)) if c=='C04' else (1 if c in ['C01','C02','C03'] else 0)
 for o in reservoir:o.scale=(source_amp,)*3
 for i,o in enumerate(ref):
  u=(i/len(ref)+phase*.12)%1;p=point_on(LOOP,u);q=point_on(LOOP,(u+.005)%1);o.location=p;delta=q-p;o.rotation_euler[1]=math.atan2(delta.x,delta.z)
 bolt.hide_render=internal<=.001 or c not in ['C06','C07']
 bolt.scale=(ease(t/.20) if c=='C06' else 1,)*3

depth_root=bpy.data.objects.new('INTERNAL_DEPTH_ROOT',None);S.collection.objects.link(depth_root);depth_root.location=(0,.65,0)
for key in ['CUTAWAY_MASTER','PRODUCTS','HEAT_ENERGY','REFRIGERANT','POWER']:
 for obj in COL[key].objects:obj.parent=depth_root
INTERNAL_FADES=[]
for ma in list(bpy.data.materials):
 if ma!=pm and ma.name not in ['Pale gray studio'] and ma.use_nodes:INTERNAL_FADES.append(fadeable(ma))
# Store structured metadata on every scientific component and in the .blend.
for id in ['CH_COLD','CH_HOT','HX_COLD','COMP','HX_HOT','EXP']:
 bpy.data.objects[id]['component_id']=id;bpy.data.objects[id]['model_kind']='explanatory schematic; not real machine CAD'
S['production']='VENDING_HEATPUMP V1';S['source_image']='assets/EXT_MASTER_AI.png';S['audio']='NONE';S['heat']='amber symbols of energy, outside gray refrigerant conduit';S['refrigerant']='cyan chevrons within a closed physical loop';S['frame_units']='30fps reusable motion, not measured VO'

def animate(c):
 n=CUTS[c];S.frame_start=1;S.frame_end=n
 animated=[cam]+[o for k in ['EXT_MASTER','CUTAWAY_MASTER','PRODUCTS','HEAT_ENERGY','REFRIGERANT','POWER'] for o in COL[k].objects]
 for o in animated:o.animation_data_clear()
 cam.data.animation_data_clear()
 for f in FADES+INTERNAL_FADES:
  if f.id_data.animation_data:f.id_data.animation_data_clear()
 for i in range(n):
  t=i/(n-1);state(c,t);fr=i+1
  cam.keyframe_insert('location',frame=fr);cam.keyframe_insert('rotation_euler',frame=fr);cam.data.keyframe_insert('ortho_scale',frame=fr)
  for o in heat+ref+reservoir+[bolt]:o.keyframe_insert('location',frame=fr);o.keyframe_insert('rotation_euler',frame=fr);o.keyframe_insert('scale',frame=fr)
  for o in animated[1:]:o.keyframe_insert('hide_render',frame=fr)
  for f in FADES+INTERNAL_FADES:f.keyframe_insert('default_value',frame=fr)
 # Object visibility, camera, opacity and moving symbols are keyed in the Blend.
 # Explicit state calls also keep direct per-frame rendering deterministic.
 for o in heat+ref:
  if o.animation_data and o.animation_data.action:
   for fc in o.animation_data.action.fcurves:
    for p in fc.keyframe_points:p.interpolation='LINEAR'
 S.frame_set(1);state(c,0)

def render_cut(c):
 animate(c);outdir=ROOT/'source'/'blender';outdir.mkdir(exist_ok=True)
 bpy.ops.wm.save_as_mainfile(filepath=str(outdir/(c+'.blend')),compress=True)
 if args.save_only:return
 dest=ROOT/'source'/'frames'/c;dest.mkdir(parents=True,exist_ok=True)
 frames=[args.still] if args.still is not None else ([int(x) for x in args.frames.split(',')] if args.frames else range(CUTS[c]))
 for i in frames:
  target=dest/f'{i:04}.png'
  if target.exists() and not args.frames and args.still is None:continue
  S.frame_set(i+1);state(c,i/(CUTS[c]-1));S.render.filepath=str(target);bpy.ops.render.render(write_still=True)
 (ROOT/'source'/'scene-state.json').write_text(json.dumps({'fps':30,'resolution':[1080,1920],'cuts':CUTS,'coordinate_space':'component and path coordinates are local to INTERNAL_DEPTH_ROOT','internal_depth_root_translation':[0,.65,0],'components':{id:list(bpy.data.objects[id].location) for id in ['CH_COLD','CH_HOT','HX_COLD','COMP','HX_HOT','EXP']},'loop':LOOP,'energy':ENERGY},indent=2))

for c in CUTS if args.all else [args.cut]:render_cut(c)
