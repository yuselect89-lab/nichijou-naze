"""Decode every delivered video and verify expected format, alpha and LOCK."""
from pathlib import Path
import json,subprocess,hashlib,sys
R=Path(__file__).resolve().parents[1]
N={'C01':90,'C02':90,'C03':120,'C04':90,'C05':90,'C06':150,'C07':120}
checks=[];media=[]
def run(cmd):return subprocess.run(cmd,check=True,capture_output=True,text=True).stdout
for c,n in N.items():
 for name in ['asset.mp4','scene.mp4','labels.webm','character.webm']:
  p=R/'cuts'/c/name;data=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(p)]));vs=[s for s in data['streams'] if s['codec_type']=='video'];au=[s for s in data['streams'] if s['codec_type']=='audio'];v=vs[0]
  valid=len(vs)==1 and not au and v['width']==1080 and v['height']==1920 and v['r_frame_rate']=='30/1' and int(v.get('nb_read_frames',0))==n
  if name.endswith('webm'):valid=valid and v.get('tags',{}).get('alpha_mode')=='1'
  command=['ffmpeg','-hide_banner','-v','error','-threads','2']
  if name.endswith('webm'):command+=['-c:v','libvpx-vp9']
  command+=['-i',str(p),'-an','-f','null','-'];run(command)
  checks.append({'check':str(p.relative_to(R))+' format / full decode','status':'PASS' if valid else 'FAIL'})
  media.append({'file':str(p.relative_to(R)),'frames':int(v['nb_read_frames']),'fps':v['r_frame_rate'],'size':[v['width'],v['height']],'codec':v['codec_name'],'alpha':v.get('tags',{}).get('alpha_mode')=='1','audio_streams':len(au),'duration':data['format'].get('duration'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
lock=json.loads((R/'production-lock.json').read_text());banner=R/lock['banner']['path'];actual=hashlib.sha256(banner.read_bytes()).hexdigest()
checks.append({'check':'Unmodified approved banner original (not baked into cut assets)','status':'PASS' if actual==lock['banner']['sha256'] else 'FAIL','sha256':actual})
for p in ['assets/CHAR_think.png','assets/CHAR_surprise.png','assets/CHAR_happy.png','source/AI_PROMPT.txt','assets/EXT_MASTER_AI.png','WORK_HANDOFF.md']+[f'source/blender/{c}.blend' for c in N]:checks.append({'check':p+' exists','status':'PASS' if (R/p).is_file() and (R/p).stat().st_size>0 else 'FAIL'})
out={'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'media':media,'scope':'Technical readiness of silent cut assets; actual VO synchronization and final G3 are excluded.'}
(R/'qc/technical-qc.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('TECHNICAL_QC',out['status'],len(media),'full videos decoded')
if out['status']!='PASS':sys.exit(1)
