"""Blender-only validation of the delivered .blend files, without rendering."""
import bpy,json,math,sys,argparse,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
N={'C01':90,'C02':90,'C03':120,'C04':90,'C05':90,'C06':150,'C07':120}
ap=argparse.ArgumentParser();ap.add_argument('--until');args=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
if args.until:N=dict(list(N.items())[:list(N).index(args.until)+1])
def sample(frame):
 s=bpy.context.scene;s.frame_set(frame);bpy.context.view_layer.update()
 ids=['CH_COLD','CH_HOT','HX_COLD','COMP','HX_HOT','EXP']
 return {'camera':list(s.camera.location)+list(s.camera.rotation_euler)+[s.camera.data.ortho_scale],
 'components':{k:list(bpy.data.objects[k].matrix_world.translation) for k in ids},
 'products':{o.name:list(o.matrix_world.translation) for o in bpy.data.collections['PRODUCTS'].objects},
 'energy':{o.name:list(o.matrix_world.translation)+list(o.scale) for o in bpy.data.collections['HEAT_ENERGY'].objects if o.name.startswith(('ENERGY_PACKET','SOURCE_HEAT'))},
 'refrigerant':{o.name:list(o.matrix_world.translation)+list(o.rotation_euler) for o in bpy.data.collections['REFRIGERANT'].objects if o.name.startswith('REFRIGERANT_ARROW')}}
def error(a,b):
 if isinstance(a,dict):return max(error(a[k],b[k]) for k in a)
 if isinstance(a,list):return max(abs(x-y) for x,y in zip(a,b))
 return abs(a-b)
edges={};checks=[]
for c,n in N.items():
 bpy.ops.wm.open_mainfile(filepath=str(R/'source/blender'/f'{c}.blend'))
 s=bpy.context.scene;edges[c]={'start':sample(1),'end':sample(n)}
 checks.append({'check':c+' frame range','status':'PASS' if s.frame_start==1 and s.frame_end==n and s.render.fps==30 else 'FAIL'})
 checks.append({'check':c+' packed AI image','status':'PASS' if any(i.packed_file for i in bpy.data.images if i.name.startswith('EXT_MASTER_AI')) else 'FAIL'})
 lp=bpy.data.objects['REFRIGERANT_CLOSED_LOOP'].data.splines[0].points
 ep=bpy.data.objects['Energy_guide_not_refrigerant'].data.splines[0].points
 closed=all(abs(a-b)<1e-6 for a,b in zip(lp[0].co,lp[-1].co));oneway=any(abs(a-b)>.1 for a,b in zip(ep[0].co,ep[-1].co))
 checks.append({'check':c+' refrigerant loop closed / energy path one-way','status':'PASS' if closed and oneway else 'FAIL'})
 checks.append({'check':c+' cold/hot physical sides fixed','status':'PASS' if bpy.data.objects['CH_COLD'].location.x<bpy.data.objects['CH_HOT'].location.x else 'FAIL'})
 if c=='C04':
  checks.append({'check':'C04 source heat display decreases','status':'PASS' if edges[c]['start']['energy']['SOURCE_HEAT_0'][3]>.99 and edges[c]['end']['energy']['SOURCE_HEAT_0'][3]<.01 else 'FAIL'})
 if c=='C06':
  checks.append({'check':'C06 electrical input visible at end','status':'PASS' if not bpy.data.objects['POWER_INTO_COMP'].hide_render and bpy.data.objects['POWER_INTO_COMP'].scale.x>.99 else 'FAIL'})
for a,b in zip(list(N),list(N)[1:]):
 fields=['camera']+(['components','products','energy','refrigerant'] if a in ['C03','C04','C05','C06'] else [])
 for field in fields:
  e=error(edges[a]['end'][field],edges[b]['start'][field]);checks.append({'check':a+'→'+b+' '+field,'max_error':e,'status':'PASS' if e<.0001 else 'FAIL'})
for c in list(N)[1:]:
 e=error(edges['C01']['start']['components'],edges[c]['start']['components']);checks.append({'check':c+' fixed component coordinates','max_error':e,'status':'PASS' if e<.0001 else 'FAIL'})
 e=error(edges['C01']['start']['products'],edges[c]['start']['products']);checks.append({'check':c+' fixed shelf/product coordinates','max_error':e,'status':'PASS' if e<.0001 else 'FAIL'})
if 'C07' in edges:
 e=error(edges['C01']['end']['camera'],edges['C07']['end']['camera']);checks.append({'check':'C01↔C07 exterior camera identity','max_error':e,'status':'PASS' if e<.0001 else 'FAIL'})
out={'status':'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL','method':'Read actual delivered .blend files at their keyed first/last frames; compare world coordinates, camera and persistent energy/refrigerant IDs. No scene rebuild substituted.','checks':checks,'edges':edges}
out['file_hashes']={f'source/blender/{c}.blend':hashlib.sha256((R/f'source/blender/{c}.blend').read_bytes()).hexdigest() for c in N}
(R/'qc/scene-qc.json').write_text(json.dumps(out,indent=2));print('SCENE_QC',out['status'])
if out['status']!='PASS':raise RuntimeError('Scene continuity check failed')
