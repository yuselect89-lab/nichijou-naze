"""Editable label/character layers; original PNGs are only placed and clipped.
No narration, subtitles, banner, or progress bar is created by this script.
Python 3, Pillow and FFmpeg. Paths are relative to this portable delivery.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json,subprocess,argparse,html
ROOT=Path(__file__).resolve().parents[1]
CUTS={'C01':90,'C02':90,'C03':120,'C04':90,'C05':90,'C06':150,'C07':120}
P={'C01':'','C02':'同じ1台で？','C03':'熱を再利用','C04':'熱を奪う','C05':'熱を回収','C06':'温める側へ','C07':'冷やす → 温める'}
SUB={'C01':'','C02':'','C03':'一部の自販機では','C04':'冷却室 → 熱交換器','C05':'冷却時の熱','C06':'ヒートポンプ','C07':''}
FONT_B=ROOT/'assets/NotoSansCJKjp-Bold.otf';FONT_R=ROOT/'assets/NotoSansCJK-Regular.ttc'
NAVY='#1c3443';TEAL='#126e87';WARM='#b7472d';AMBER='#c9800c'
cache={}
def font(s,b=True):
 k=(s,b)
 if k not in cache:cache[k]=ImageFont.truetype(str(FONT_B if b else FONT_R),s)
 return cache[k]
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def mix(a,b,t):return a+(b-a)*t
def camera(c,t):
 if c=='C01':
  if t<.66:return mix(-.58,.36,ease(t/.66)),3.88,4.8,mix(-.18,.16,t)
  u=ease((t-.66)/.34);return mix(.36,-.5,u),mix(3.88,3.30,u),mix(4.8,9,u),mix(.16,0,u)
 if c=='C02':return -.5,3.30,9,.035*math.sin(t*math.pi)
 if c=='C03':
  u=ease(max(0,(t-.24)/.60));return mix(-.5,0,u),3.30,9,.65*u
 if c=='C04':
  u=ease(t);return mix(0,-.48,u),mix(3.30,3.35,u),mix(9,6.6,u),.65
 if c=='C05':
  u=ease(t);return mix(-.48,-.12,u),mix(3.35,3.25,u),mix(6.6,7.9,u),.65
 if c=='C06':return -.12,3.25,7.9,.65
 u=ease(t/.62);return mix(-.12,-.5,u),mix(3.25,3.30,u),mix(7.9,9,u),.65*(1-u)
def xy(c,t,p):
 x,z,s,o=camera(c,t);rx=9/math.sqrt(81+o*o);ry=o/math.sqrt(81+o*o)
 return 540+((p[0]-x)*rx+p[1]*ry)*1920/s,960-(p[2]-z)*1920/s
def X(p):return (p-941/2)*6/1672
def Z(p):return 6-p*6/1672
def text(d,pos,s,size=40,bold=True,fill=NAVY,anchor='mm'):
 d.text(pos,s,font=font(size,bold),fill=fill,anchor=anchor,stroke_width=0)
def pill(d,pos,s,size=36,color=NAVY,outline='#d8e0e4',bold=True,pad=18):
 f=font(size,bold);w=d.textlength(s,font=f)+2*pad;h=size+20;x,y=pos
 d.rounded_rectangle((x-w/2,y-h/2,x+w/2,y+h/2),radius=14,fill=(255,255,255,245),outline=outline,width=2)
 text(d,pos,s,size,bold,color)
def labels(c,t):
 im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im)
 if P[c]:
  # After opening cut the official banner is absent; do not overlap the opening band.
  text(d,(540,245),P[c],72 if c!='C07' else 66)
  if SUB[c]:pill(d,(540,350),SUB[c],42,bold=False)
 exterior=c in ['C01','C02'] or c=='C03' and t<.70 or c=='C07' and t>.40
 if exterior:
  a=1
  if c=='C03':a=1-ease((t-.24)/.60)
  if c=='C07':a=ease(t/.62)
  tmp=Image.new('RGBA',im.size);q=ImageDraw.Draw(tmp)
  for label,px,col,show in [('つめた〜い',289,TEAL,True),('あったか〜い',550,WARM,True)]:
   cx,cy=xy(c,t,(X(px),-.10,Z(550)))
   size=round(max(35,min(54,260/camera(c,t)[2])))
   cx+=-14 if px==289 else 14
   width=q.textlength(label,font=font(size))+20
   if c=='C01' and (cx-width/2<96 or cx+width/2>984):continue
   pill(q,(cx,cy),label,size,col,outline=col,pad=10)
   if c=='C02':
    u=ease((t-(.12 if px==289 else .48))/.14)*(1-ease((t-(.44 if px==289 else .88))/.10))
    if u>0:
     w=q.textlength(label,font=font(size))+26;hh=size+34
     q.rounded_rectangle((cx-w/2,cy-hh/2,cx+w/2,cy+hh/2),radius=16,outline=col,width=round(2+4*u))
  tmp.putalpha(tmp.getchannel('A').point(lambda v:int(v*a)));im.alpha_composite(tmp)
 if c in ['C03','C04','C05','C06','C07']:
  a=ease((t-.22)/.30) if c=='C03' else (1-ease(t/.62) if c=='C07' else 1)
  tmp=Image.new('RGBA',im.size);q=ImageDraw.Draw(tmp)
  pill(q,(845,490),'模式図',34,bold=False)
  # The symbols explicitly distinguish energy transfer from a circulating material.
  q.ellipse((144,424,166,446),fill='#e7a11d');text(q,(185,435),'熱の移動',38,False,AMBER,'lm')
  text(q,(570,435),'›',48,True,TEAL,'mm');text(q,(600,435),'冷媒の循環',38,False,TEAL,'lm')
  text(q,(370,494),'光点＝エネルギーの記号',30,False,'#526572')
  for name,point,col in [('冷却室',(-.69,0,4.64),TEAL),('加温室',(.28,0,4.64),WARM)]:pill(q,xy(c,t,point),name,36,col,pad=12)
  # Thick amber arrows follow the energy path; thin cyan arrows stay in the
  # physical refrigerant conduit in the 3D scene. The two tracks never swap roles.
  def energy_arrow(p0,p1):
   a0=xy(c,t,p0);b0=xy(c,t,p1);dx=b0[0]-a0[0];dy=b0[1]-a0[1];ln=math.hypot(dx,dy);ux=dx/ln;uy=dy/ln
   q.line((*a0,*b0),fill='#cb8d16',width=7)
   q.polygon([b0,(b0[0]-ux*22-uy*12,b0[1]-uy*22+ux*12),(b0[0]-ux*22+uy*12,b0[1]-uy*22-ux*12)],fill='#cb8d16')
  if c in ['C03','C04']:energy_arrow((-.69,.35,3.25),(-.69,.35,2.78))
  if c in ['C03','C06']:energy_arrow((.29,.35,2.82),(.29,.35,3.30))
  if c=='C05':energy_arrow((-.43,.29,1.90),(-.02,.29,1.94))
  if c in ['C04','C05','C06']:
   p=xy(c,t,(-.70,-.2,2.24));pill(q,(p[0]-80,p[1]+62),'吸熱',36,TEAL)
  if c in ['C05','C06']:
   p=xy(c,t,(-.10,0,1.6));pill(q,(p[0]-170,p[1]),'圧縮機',34)
  if c=='C06':
   p=xy(c,t,(.29,-.2,2.24));pill(q,(p[0]+90,p[1]+60),'放熱',36,WARM)
   p=xy(c,t,(-.10,0,1.6));pill(q,(p[0]+35,p[1]+45),'電力を使用',35,'#40519c',bold=False)
   p=xy(c,t,(.68,0,1.23));pill(q,(p[0]+115,p[1]-16),'膨張装置',32)
  tmp.putalpha(tmp.getchannel('A').point(lambda v:int(v*a)));im.alpha_composite(tmp)
 if c=='C07' and .73<t<.98:
  q=ImageDraw.Draw(im);a=xy(c,t,(X(289),-.10,Z(550)));b=xy(c,t,(X(550),-.10,Z(550)));progress=ease((t-.73)/.15);y=a[1]+56;xx=mix(a[0],b[0],progress)
  q.line((a[0],y,xx,y),fill='#d2962a',width=7)
  if progress>.05:q.polygon([(xx,y),(xx-16,y-10),(xx-16,y+10)],fill='#d2962a')
 return im
SPRITES={p:Image.open(ROOT/f'assets/CHAR_{p}.png').convert('RGBA').crop((260,0,1280,1300)).resize((440,561),Image.Resampling.LANCZOS) for p in ['think','surprise','happy']}
def character(c,t):
 im=Image.new('RGBA',(1080,1920));pose=None;a=0
 if c=='C02':pose='think';a=ease(t/.15)
 if c=='C03':pose='surprise';a=1-ease((t-.10)/.12)
 if c=='C07':pose='happy';a=ease((t-.64)/.16)
 if pose and a>0:
  layer=SPRITES[pose].copy();layer.putalpha(layer.getchannel('A').point(lambda v:int(v*a)))
  im.alpha_composite(layer,(int(20-(1-a)*30),910))
 return im
def layer_video(c,kind):
 d=ROOT/'cuts'/c;d.mkdir(parents=True,exist_ok=True);out=d/(kind+'.webm')
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgba','-s','1080x1920','-r','30','-i','-','-an','-c:v','libvpx-vp9','-pix_fmt','yuva420p','-b:v','0','-crf','24','-deadline','good','-cpu-used','5','-auto-alt-ref','0',str(out)]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 try:
  for i in range(CUTS[c]):proc.stdin.write((labels(c,i/(CUTS[c]-1)) if kind=='labels' else character(c,i/(CUTS[c]-1))).tobytes())
 finally:proc.stdin.close()
 if proc.wait():raise RuntimeError('alpha encoding failed')
def finish_cut(c):
 d=ROOT/'cuts'/c;d.mkdir(parents=True,exist_ok=True)
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate','30','-i',str(ROOT/'source/frames'/c/'%04d.png'),'-frames:v',str(CUTS[c]),'-an','-c:v','libx264','-crf','17','-preset','fast','-pix_fmt','yuv420p','-movflags','+faststart',str(d/'scene.mp4')],check=True)
 for kind in ['labels','character']:layer_video(c,kind)
 # Force libvpx decoder to preserve VP9 alpha on recomposition.
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(d/'scene.mp4'),'-c:v','libvpx-vp9','-i',str(d/'labels.webm'),'-c:v','libvpx-vp9','-i',str(d/'character.webm'),'-filter_complex','[0:v][1:v]overlay=format=auto[a];[a][2:v]overlay=format=auto,format=yuv420p[v]','-map','[v]','-an','-r','30','-frames:v',str(CUTS[c]),'-c:v','libx264','-preset','fast','-crf','17','-movflags','+faststart',str(d/'asset.mp4')],check=True)
 for t in [0,.5,1]:
  i=round(t*(CUTS[c]-1));base=Image.open(ROOT/'source/frames'/c/f'{i:04}.png').convert('RGBA');base.alpha_composite(labels(c,t));base.alpha_composite(character(c,t));base.convert('RGB').save(ROOT/'qc'/f'{c}_{i:04}.jpg',quality=95)
  if t==.5:base.resize((360,640),Image.Resampling.LANCZOS).convert('RGB').save(ROOT/'qc'/f'{c}_360.jpg',quality=95)
 # Editable SVG text fallback; precise animation lives in this Python source.
 parts=[]
 for title,y,size in [(P[c],245,72),(SUB[c],350,42)]:
  if title:parts.append(f'<text x="540" y="{y}" text-anchor="middle" font-size="{size}" fill="{NAVY}">{html.escape(title)}</text>')
 (d/'headings.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920" viewBox="0 0 1080 1920"><style>text{font-family:"Noto Sans CJK JP";font-weight:700}</style>'+''.join(parts)+'</svg>')
 labels(c,.5).save(d/'labels_reference.png');character(c,{'C03':.05,'C07':.9}.get(c,.5)).save(d/'character_reference.png')
 print('COMPOSED',c,flush=True)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--cut');ap.add_argument('--preview',action='store_true');a=ap.parse_args()
 cs=[a.cut] if a.cut else list(CUTS)
 if a.preview:
  for c in cs:
   (ROOT/'qc').mkdir(exist_ok=True);labels(c,.5).save(ROOT/'qc'/f'{c}_labels.png');character(c,.5).save(ROOT/'qc'/f'{c}_character.png')
 else:
  for c in cs:finish_cut(c)
 (ROOT/'source'/'typography.json').write_text(json.dumps({c:{'primary_text':P[c] or 'N/A: visual-first','secondary_text':SUB[c],'size_hierarchy':'Primary 66–72px; supporting 42px; part labels 32–36px','weight_strategy':'Real Noto CJK Bold 700 / Regular 400; no synthetic bold','luminance_strategy':'Navy on near-white; amber energy dots; teal closed-loop arrows; labels on white backing','typeface_reason':'Japanese gothic for fast short scientific labels; Mincho not used for this concise explanatory footage','character_role':{'C02':'question','C03':'reveal_intro','C07':'payoff'}.get(c,'focus_only'),'character_crop':[260,0,1280,1300],'character_destination':[20,910,440,561],'font_files':['assets/NotoSansCJKjp-Bold.otf','assets/NotoSansCJK-Regular.ttc']} for c in CUTS},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
