# 「日常のなぜ？」自販機ヒートポンプ｜映像素材 V1

**編集入口：`WORK_HANDOFF.md`**。全7カットの無音素材、分離レイヤー、Blenderソース、AI生成原画像、プロンプト、出所・ライセンス、QC証拠を収録する。

- `cuts/C01/asset.mp4` ～ `cuts/C07/asset.mp4`：そのまま組立に使用する素材。
- `cuts/Cxx/scene.mp4` ＋ `labels.webm` ＋ `character.webm`：文字・キャラを再編集するための分離版。
- `source/blender/`：7カットの編集可能な3Dシーン。熱と冷媒は別コレクション。
- `source/build_scene.py` / `compose.py`：同一機体・同一部品IDの立体アニメーションとレイヤーを再構築するソース。
- `assets/` / `PROVENANCE.json`：生成原画像、承認済みキャラ、使用フォント、権利・出所。
- `reference/`：G2 V2設計、書面QC PASS、発注書、変更していないG1抜粋。
- `qc/`：実画・360px・連続性・再生・技術検証結果。`QC_REPORT.md` から参照。
- `manifest.json` / `asset-lock.json` / `SHA256SUMS.txt`：ID・版・依存・状態と納品ファイルのハッシュ。

帯・字幕・進行バー・音声は素材に焼き込んでいない。承認済み帯の原本は別ファイルとして同梱。Workが本編でそれぞれ一度だけ合成する。G1台本と制作LOCKは維持する。

素材の秒数は可動素材の単位であり、実VO尺や最終カット割ではない。実VO同期と最終G3はWorkで実施する。
