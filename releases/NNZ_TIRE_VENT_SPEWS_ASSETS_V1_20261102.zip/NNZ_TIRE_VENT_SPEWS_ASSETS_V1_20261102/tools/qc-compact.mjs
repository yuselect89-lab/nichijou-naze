#!/usr/bin/env node
// Save the ENTIRE QC transcript locally. Give the AI bounded output; never equate exit 0 with QC PASS.
import {spawn} from 'node:child_process';
import {appendFileSync, createWriteStream, mkdirSync} from 'node:fs';
import path from 'node:path';
const argv=process.argv.slice(2), marker=argv.indexOf('--');
if(marker<0||marker===argv.length-1){console.error('Usage: node qc-compact.mjs [--out log-file] [--tail 20] [--metrics ledger.jsonl --phase name --kind initial|repair|verification --reason text] -- command [args...]');process.exit(2)}
const opts=argv.slice(0,marker),cmd=argv.slice(marker+1);
let logPath=null,tailCount=20,metricsPath=null,phase=null,kind='initial',reason=null;
for(let i=0;i<opts.length;i++){
 if(opts[i]==='--out'&&opts[i+1])logPath=opts[++i];
 else if(opts[i]==='--tail'&&opts[i+1])tailCount=Number(opts[++i]);
 else if(opts[i]==='--metrics'&&opts[i+1])metricsPath=opts[++i];
 else if(opts[i]==='--phase'&&opts[i+1])phase=opts[++i];
 else if(opts[i]==='--kind'&&opts[i+1])kind=opts[++i];
 else if(opts[i]==='--reason'&&opts[i+1])reason=opts[++i];
 else{console.error('Unknown option '+opts[i]);process.exit(2)}
}
if(!Number.isInteger(tailCount)||tailCount<1||tailCount>100)process.exit(2);
if(!['initial','repair','verification'].includes(kind)||metricsPath&&(!phase||kind==='repair'&&!reason)){
 console.error('Measurements require --phase; repair requires --reason; kind must be initial, repair or verification.');process.exit(2);
}
if(metricsPath)mkdirSync(path.dirname(path.resolve(metricsPath)),{recursive:true});
if(!logPath)logPath=`out/qc/${path.basename(cmd[0]).replace(/[^\w.-]/g,'_')}-${Date.now()}-${process.pid}.log`;
mkdirSync(path.dirname(path.resolve(logPath)),{recursive:true});
const startedAt=new Date().toISOString(),started=performance.now();
const stream=createWriteStream(logPath,{flags:'wx'}),child=spawn(cmd[0],cmd.slice(1),{stdio:['inherit','pipe','pipe'],shell:process.platform==='win32'});
let lines=0,tail=[],issues=[],issueCount=0,bytes=0;
const buffers={stdout:'',stderr:''};
const important=/(?:\b(?:ERROR|WARN|FAIL|BLOCK|HOLD|MISSING|PASS)\b|警告|未確認|不一致|エラー|失敗|異常|不足|指摘|要修正|要判断|★)/i;
function line(s){
 lines++;
 if(important.test(s)){issueCount++;if(issues.length<50)issues.push(s.slice(0,450))}
 tail.push(s.slice(0,450));if(tail.length>tailCount)tail.shift();
}
for(const pipe of [child.stdout,child.stderr]){
 pipe.on('data',b=>{
  bytes+=b.length;stream.write(b);
  const key=pipe===child.stdout?'stdout':'stderr';buffers[key]+=b.toString('utf8');let idx;
  while((idx=buffers[key].indexOf('\n'))>=0){line(buffers[key].slice(0,idx).replace(/\r$/,''));buffers[key]=buffers[key].slice(idx+1)}
  if(buffers[key].length>65536){line(buffers[key].slice(0,500));buffers[key]=''}
 });
}
child.on('error',e=>{stream.write('\n[SPAWN ERROR] '+e.message+'\n');console.error('Cannot execute command: '+e.message);process.exitCode=127});
child.on('close',async(code,signal)=>{
 const elapsedMs=Math.round((performance.now()-started)*1000)/1000,finishedAt=new Date().toISOString();
 for(const v of Object.values(buffers))if(v)line(v);
 stream.end();await new Promise(resolve=>stream.once('finish',resolve));
 const result={status:code===0?'EXECUTED_ZERO_EXIT_NOT_QC_PASS':'COMMAND_FAILED',exitCode:code,signal,startedAt,finishedAt,elapsedMs,log:path.resolve(logPath),bytes,lines,matchingLines:issueCount,interesting:issues.slice(0,25),additionalInteresting:Math.max(0,issueCount-25),tail,summaryBytes:0};
 if(metricsPath)result.metrics=path.resolve(metricsPath);
 // Include the summary's own byte count; this is bytes, never an estimated token count.
 for(let i=0;i<5;i++){
  const size=Buffer.byteLength(JSON.stringify(result,null,2)+'\n');
  if(size===result.summaryBytes)break;result.summaryBytes=size;
 }
 if(metricsPath){
  try{
   // Command arguments are deliberately omitted: they may contain credentials.
   appendFileSync(metricsPath,JSON.stringify({schemaVersion:1,phase,kind,reason,command:path.basename(cmd[0]),startedAt,finishedAt,elapsedMs,exitCode:code,signal,log:result.log,logBytes:bytes,logLines:lines,summaryBytes:result.summaryBytes,llmTokens:null,billedCost:null})+'\n');
  }catch(e){
   result.measurementError=e.message;process.exitCode=1;
   for(let i=0;i<5;i++)result.summaryBytes=Buffer.byteLength(JSON.stringify(result,null,2)+'\n');
  }
 }
 console.log(JSON.stringify(result,null,2));
 if(code!==0)process.exitCode=code||1;
});
