# タイヤのヒゲ編・素材V1

全8カットの使用用無音動画は`cuts/C01/asset.mp4`〜`C08/asset.mp4`。合成済み8本＋元シーン8本の計16動画、静止透過ラベルと編集用時間・位置情報、2つの共通Blenderマスター、生成ソース、QC記録を同梱。

音声原本は`audio/VO_original.mp3`。素材動画には音声を焼き込んでいない。組立担当は`WORK_ASSEMBLY.md`、同期は`WORK_ANCHORS.csv`と`VOICE_PARAGRAPHS.csv`を参照する。

生成元と権利は`PROVENANCE.md`。実画セルフレビュー・幾何検査・実再生結果は`qc/`。G2書面PASSと完成本編G3を区別し、G3はWork組立後に実施。

`FILELIST.csv`／`asset-lock.json`／`SHA256SUMS.txt`で実ファイルを照合。完全なフォント原本は可逆圧縮で保存し、再編集時に自動復元する。再生成できるキャッシュは除外した。
