import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];CFG=json.loads((R/'source/macro-master.json').read_text());rows={x['cut_id']:x for x in json.loads((R/'source/timing.json').read_text())};bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);s=bpy.context.scene;s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100;s.render.fps=30;s.display.shading.light='FLAT';s.display.shading.color_type='TEXTURE';s.display.shading.show_shadows=False;s.display.shading.show_cavity=False;s.view_settings.view_transform='Standard'
c=bpy.data.collections.new('TIRE_MACRO_MASTER');s.collection.children.link(c);bpy.ops.mesh.primitive_plane_add(size=1);plane=bpy.context.object;plane.name='TIRE_MACRO_MASTER';plane.scale=(1080,1920,1)
for col in list(plane.users_collection):col.objects.unlink(plane)
c.objects.link(plane);m=bpy.data.materials.new('One generated photographic tire macro');m.use_nodes=True;tx=m.node_tree.nodes.new('ShaderNodeTexImage');tx.image=bpy.data.images.load(str(R/'assets/TIRE_MACRO.png'));m.node_tree.links.new(tx.outputs['Color'],m.node_tree.nodes['Principled BSDF'].inputs['Base Color']);plane.data.materials.append(m);plane['featured_hair']='SPEW_001';plane['photographic_not_live_3d_tire']='Camera-only motion is intentional for macro shots; formation uses true deforming3D core.'
cd=bpy.data.cameras.new('MACRO_CAMERA');cam=bpy.data.objects.new('MACRO_CAMERA',cd);s.collection.objects.link(cam);cam.location=(0,0,2000);cd.type='ORTHO';cd.clip_end=5000;s.camera=cam
offset=1;spans={}
for cut in ['C01','C02','C03','C08']:
 n=rows[cut]['frames'];spans[cut]={'first':offset,'last':offset+n-1}
 for i in range(n):
  t=i/(n-1);t=t*t*(3-2*t);a,b=CFG['crops'][cut];cd.ortho_scale=1920*(a+(b-a)*t);cd.keyframe_insert('ortho_scale',frame=offset+i);p,q=CFG['centers'][cut];cx=p[0]+(q[0]-p[0])*t;cy=p[1]+(q[1]-p[1])*t;cam.location=(1080*(cx-.5),1920*(.5-cy),2000);cam.keyframe_insert('location',frame=offset+i)
 offset+=n
s.frame_start=1;s.frame_end=offset-1;s.frame_set(1)
for im in bpy.data.images:
 if im.source=='FILE':im.filepath='//../../assets/'+Path(im.filepath).name
(R/'source/macro-ranges.json').write_text(json.dumps(spans,indent=2));bpy.ops.wm.save_as_mainfile(filepath=str(R/'source/blender/TIRE_MACRO_MASTER.blend'),compress=True);print('MACRO_MASTER_SAVED')
