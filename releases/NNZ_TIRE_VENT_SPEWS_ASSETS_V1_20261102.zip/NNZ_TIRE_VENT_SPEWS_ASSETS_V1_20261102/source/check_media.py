from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json,hashlib
from font_loader import fonts
R=Path(__file__).resolve().parents[1];rows=json.loads((R/'source/timing.json').read_text());Q=R/'qc';frames=Q/'frames';frames.mkdir(exist_ok=True);font=ImageFont.truetype(str(fonts()/'Bold.otf'),22);gallery=Image.new('RGB',(1440,1280),'#17242b');videos=[]
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True).stdout
def extract(c,frame,width,out,kind='asset'):
 run(['ffmpeg','-v','error','-y','-i',str(R/'cuts'/c/(kind+'.mp4')),'-vf',f'select=eq(n\\,{frame}),scale={width}:-2','-frames:v','1',str(out)]);return Image.open(out).convert('RGB')
for idx,row in enumerate(rows):
 c=row['cut_id'];n=row['frames']
 for name in ['scene.mp4','asset.mp4']:
  p=R/'cuts'/c/name;j=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-of','json',str(p)]));v=next(v for v in j['streams'] if v['codec_type']=='video');assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']))==(1080,1920,'30/1',n);assert not any(v['codec_type']=='audio' for v in j['streams'])
  run(['ffmpeg','-v','error','-threads','2','-i',str(p),'-an','-f','null','-']);videos.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frames':n,'fps':30,'audio':False,'full_decode':'PASS'})
 sheet=Image.new('RGB',(1080,414),'#edf1f3');d=ImageDraw.Draw(sheet)
 for k,t in enumerate([0,.25,.5,.75,1]):
  i=round((n-1)*t);p=frames/f'{c}-{i:04}.jpg';im=extract(c,i,216,p);sheet.paste(im,(216*k,30));d.text((216*k+3,3),f'{c} {i:03}f',font=font,fill='#243d48')
 sheet.save(Q/(c+'-motion.jpg'),quality=95);im=extract(c,round((n-1)*.5),360,frames/(c+'-360.jpg'));gallery.paste(im,((idx%4)*360,(idx//4)*640))
gallery.save(Q/'contact-360.jpg',quality=95);gallery.convert('L').save(Q/'contact-gray.jpg',quality=95)
for p in (R/'layers').rglob('*.png'):
 with Image.open(p) as im:assert im.size==(1080,1920) and im.mode=='RGBA'
(Q/'media.json').write_text(json.dumps({'status':'PASS','videos':videos,'editable_layers':'PNG labels and animation/anchor metadata; empty layers omitted','voice':'Original MP3 provided separately; all material MP4s silent; measured sentence-level sync in WORK_ANCHORS.csv'},indent=2))
ui=Image.new('RGB',(1440,640),'white')
for k,c in enumerate(['C01','C02','C06','C07']):
 n=next(r['frames'] for r in rows if r['cut_id']==c);i=0 if c=='C01' else n-1;im=extract(c,i,1080,frames/(c+'-ui.jpg')).convert('RGBA')
 if c=='C01':im.alpha_composite(Image.open(R/'public/series/approved/opening_banner.png').convert('RGBA').resize((920,920),Image.Resampling.LANCZOS),(80,88))
 mask=Image.new('RGBA',im.size);d=ImageDraw.Draw(mask);d.rectangle((96,1510,984,1790),fill=(30,45,60,190));d.rectangle((984,580,1080,1790),fill=(30,45,60,120));im.alpha_composite(mask);ui.paste(im.resize((360,640),Image.Resampling.LANCZOS).convert('RGB'),(360*k,0))
ui.save(Q/'protected-ui.jpg',quality=95)
pair=Image.new('RGB',(720,640),'white')
for k,c in enumerate(['C01','C08']):
 n=next(r['frames'] for r in rows if r['cut_id']==c);im=extract(c,n-1,360,frames/(c+'-same-hair.jpg'),'scene');pair.paste(im,(360*k,0))
pair.save(Q/'C01-C08-same-hair.jpg',quality=95)
concat=Q/'core-continuity.txt';concat.write_text("file '../cuts/C06/asset.mp4'\nfile '../cuts/C07/asset.mp4'\n")
run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(concat),'-vf','scale=720:1280','-c:v','libx264','-crf','20','-preset','fast','-threads','2','-an',str(Q/'C06-C07-continuity.mp4')])
print('MEDIA_PASS',len(videos),'videos; PNG layers, actual UI and continuity evidence produced')
