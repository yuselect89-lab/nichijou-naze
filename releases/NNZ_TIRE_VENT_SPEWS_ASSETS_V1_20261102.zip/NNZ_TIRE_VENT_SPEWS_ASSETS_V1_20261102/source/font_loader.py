"""Restore byte-identical full original fonts; no glyphs are removed."""
from pathlib import Path
import tarfile,json,hashlib
R=Path(__file__).resolve().parents[1]
def fonts():
 cache=R/'.cache/fonts';meta=json.loads((R/'assets/font-manifest.json').read_text())
 if not all((cache/n).exists() for n in meta):
  cache.mkdir(parents=True,exist_ok=True)
  with tarfile.open(R/'assets/FONTS.tar.xz') as t:t.extractall(cache,filter='data')
 for n,j in meta.items():
  assert hashlib.sha256((cache/n).read_bytes()).hexdigest()==j['sha256'],n
 return cache
