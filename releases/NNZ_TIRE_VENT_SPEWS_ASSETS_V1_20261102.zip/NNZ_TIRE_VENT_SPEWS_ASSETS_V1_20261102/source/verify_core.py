import bpy,json,sys,math,hashlib
import numpy as np
from pathlib import Path
from collections import Counter,defaultdict
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'source'))
from geometry import *
bpy.ops.wm.open_mainfile(filepath=str(R/'source/blender/MOLD_VENT_CUTAWAY.blend'));s=bpy.context.scene;tire=bpy.data.objects['TIRE_RUBBER'];mold=bpy.data.objects['MOLD_SURFACE'];hole=bpy.data.objects['VENT_HOLE'];ranges=json.loads((R/'source/core-ranges.json').read_text());checks=[]
def ck(name,ok,**kw):checks.append(dict(check=name,status='PASS' if ok else 'FAIL',**kw))
edges=Counter()
for p in tire.data.polygons:
 for a,b in p.edge_keys:edges[tuple(sorted((a,b)))]+=1
ck('Tire including spew is one closed manifold surface',all(n==2 for n in edges.values()),edge_counts=dict(Counter(edges.values())))
adj=defaultdict(set)
for a,b in edges:adj[a].add(b);adj[b].add(a)
seen={0};todo=[0]
while todo:
 v=todo.pop()
 for q in adj[v]-seen:seen.add(q);todo.append(q)
ck('Spew is connected rubber, not an attached independent cylinder',len(seen)==len(tire.data.vertices),vertices=len(seen))
ck('Hole fixed to metal master with one immutable ID',hole.parent.name=='MOLD_TRANSLATION' and hole['hole_id']=='VENT_001' and tuple(hole.location)==(0,0,0))
ck('Solid enters only partly into the same metal vent',SPEW_RADIUS<HOLE_RADIUS and 0<SPEW_LENGTH<MOLD_HEIGHT,radial_clearance=HOLE_RADIUS-SPEW_RADIUS,unfilled_outlet=MOLD_HEIGHT-SPEW_LENGTH)
ck('Released mold clears the full remaining rubber stem',MOLD_LIFT>SPEW_LENGTH,clearance=MOLD_LIFT-SPEW_LENGTH)
keys=tire.data.shape_keys.key_blocks
base=np.array([tuple(v.co) for v in keys['Basis'].data]);deltas={k:np.array([tuple(v.co) for v in keys[k].data])-base for k in ['PRESSED','AIR_POCKET','CONTINUOUS_SPEW']}
edgepairs=np.array(list(edges));bad=0
for i in range(0,ranges['C07']['last']-ranges['C07']['first']+1,3):
 s.frame_set(ranges['C07']['first']+i);bpy.context.view_layer.update();v=base.copy()
 for k,d in deltas.items():v+=keys[k].value*d
 for u in [.2,.4,.6,.8]:
  p=v[edgepairs[:,0]]*(1-u)+v[edgepairs[:,1]]*u;r=np.hypot(p[:,0],p[:,1]);z=p[:,2];lift=bpy.data.objects['MOLD_TRANSLATION'].location.z
  bad+=int(np.count_nonzero((r<.12)&(r>HOLE_RADIUS+.002)&(z>lift+.002)&(z<MOLD_HEIGHT+lift-.002)))
ck('Actual solid stem edges do not penetrate metal around bore entrance',bad==0,invalid_edge_samples=bad,tolerance=.002)
keys=tire.data.shape_keys.key_blocks;cap_positions={};max_pen=0;invalid_flow=0;initial=tuple(hole.location)
for c in ['C04','C05','C06','C07']:
 A=json.loads((R/'source'/f'{c}_anchors.json').read_text());frames=ranges[c];ck(c+' same vent ID throughout',all(a['hole_id']=='VENT_001' for a in A))
 for i in range(len(A)):
  f=frames['first']+i;s.frame_set(f);bpy.context.view_layer.update();d=A[i]['state'];z=keys['Basis'].data[0].co.z+keys['PRESSED'].value*.24-keys['AIR_POCKET'].value*POCKET+keys['CONTINUOUS_SPEW'].value*SPEW_LENGTH
  ckpose=abs(z-(-.24+.24*d['press']-d['gap']+d['spew']*SPEW_LENGTH))<1e-5 and tuple(hole.location)==initial
  assert ckpose,(c,i,z,d)
  if c in ['C06','C07'] and d['spew']>0:assert d['gap']==0 and d['air']==1
  if c=='C07' and d['lift']>0:assert d['cure']==1 and d['spew']==1
  if c=='C06':
   for n in ['AIR_ARROW_0','AIR_ARROW_1','AIR_ARROW_2']:
    ob=bpy.data.objects[n]
    if not ob.hide_render:
     v=ob.rotation_euler.to_matrix()@__import__('mathutils').Vector((0,0,1))
     if v.z<-.001:invalid_flow+=1
  if i in [0,len(A)-1]:cap_positions[(c,i)]={'tip_z':z,'root_z':-d['gap'],'lift':d['lift'],'state':d}
 ck(c+' keyframed state and stationary hole-local coordinates verified all frames',True,frames=len(A))
ck('Air guides travel toward mold exterior, never inward',invalid_flow==0,invalid_samples=invalid_flow)
ck('C06 last state equals C07 first state',cap_positions[('C06',len(json.loads((R/'source/C06_anchors.json').read_text()))-1)]['state']==cap_positions[('C07',0)]['state'])
A=json.loads((R/'source/C07_anchors.json').read_text());ck('C07 insertion then cure then mold lift then persistent stem',A[0]['state']['spew']==0 and A[-1]['state']['spew']==1 and A[-1]['state']['cure']==1 and A[-1]['state']['lift']==MOLD_LIFT)
for a,b in [('C04','C05'),('C05','C06'),('C06','C07')]:
 def camera(f):s.frame_set(f);bpy.context.view_layer.update();return [v for row in s.camera.matrix_world for v in row]+[s.camera.data.ortho_scale]
 err=max(abs(x-y) for x,y in zip(camera(ranges[a]['last']),camera(ranges[b]['first'])));ck(a+' to '+b+' continuous camera',err<1e-5,error=err)
result={'status':'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL','checks':checks,'source_sha256':hashlib.sha256((R/'source/blender/MOLD_VENT_CUTAWAY.blend').read_bytes()).hexdigest(),'limitations':'Representative half-section mold; dimensions exaggerated. Chemical cross-linking illustrated as a timed heat/cure stage, not a material simulation. Air guides are annotations in the actual exterior-facing cavity.'}
(R/'qc/core-geometry.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'checks':len(checks),'failed':[c for c in checks if c['status']=='FAIL']}));assert result['status']=='PASS'
