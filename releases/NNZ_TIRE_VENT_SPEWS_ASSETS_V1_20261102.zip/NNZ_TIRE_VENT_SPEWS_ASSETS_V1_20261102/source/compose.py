"""No blank video layers: editable PNGs, poses and animation metadata."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageChops
import subprocess,json,math,argparse,sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'source'))
from font_loader import fonts
from geometry import ease
F=fonts();T=json.loads((R/'source/timing.json').read_text());ROWS={r['cut_id']:r for r in T};FC={};SPR={}
TEXT={'C01':('',''),'C02':('何のため？',''),'C03':('滑り止めじゃない',''),'C04':('熱＋圧力','模式図'),'C05':('空気が残る','金型とゴムの間'),'C06':('空気の出口','金型の穴'),'C07':('ゴムが穴へ','模式的に拡大'),'C08':('製造するときの跡','')}
def font(size,bold=True):
 key=(size,bold)
 if key not in FC:FC[key]=ImageFont.truetype(str(F/('Bold.otf' if bold else 'Regular.ttc')),size)
 return FC[key]
def word(d,xy,text,size=60,bold=True):
 f=font(size,bold);w=d.textlength(text,font=f);x,y=xy;d.rounded_rectangle((x-w/2-18,y-size*.67-12,x+w/2+18,y+size*.67+12),radius=12,fill=(250,252,253,245));d.text(xy,text,font=f,anchor='mm',fill='#1d333f')
def label(c,stage=None):
 im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im);p,q=TEXT[c]
 if c=='C07':p={'entry':'ゴムが穴へ','cure':'熱で形が定まる','release':'金型が離れる','spew':'ヒゲが残る'}[stage or 'entry']
 if p:word(d,(540,220),p)
 if q:word(d,(540,325),q,34,False)
 if c in ['C05','C06','C07']:word(d,(540,1465),'模式的に拡大',30,False)
 if c=='C06':word(d,(540,435),'金型の外へ',36,False)
 return im
def character(pose):
 if pose not in SPR:
  pic=Image.open(R/'assets'/('CHAR_'+pose+'.png')).convert('RGBA').crop((260,0,1280,960)).resize((500,470),Image.Resampling.LANCZOS)
  mask=Image.new('L',pic.size,255)
  for y in range(395,470):
   ImageDraw.Draw(mask).line((0,y,500,y),fill=int(255*(469-y)/74))
  pic.putalpha(ImageChops.multiply(pic.getchannel('A'),mask));SPR[pose]=pic
 return SPR[pose]
def active_stage(t):return 'entry' if t<.30 else 'cure' if t<.51 else 'release' if t<.69 else 'spew'
def overlay(c,i,A,layers):
 n=ROWS[c]['frames'];t=i/(n-1);sec=i/30
 base=layers[active_stage(t) if c=='C07' else 'static'].copy();d=ImageDraw.Draw(base)
 if c in ['C02','C03','C08']:
  x,y=A[i]['root'];r=58 if c=='C02' else 44;alpha=(1-ease((t-.70)/.25)) if c=='C02' else .65 if c=='C03' else ease((t-.15)/.18)*(1-ease((t-.65)/.2));d.ellipse((x-r,y-r,x+r,y+r),outline=(235,197,110,int(210*alpha)),width=4)
 if c=='C06':
  x,y=A[i]['hole'];alpha=1-ease((t-.20)/.20);d.ellipse((x-48,y-70,x+48,y+70),outline=(232,195,109,int(230*alpha)),width=4)
 pose=None;opacity=0
 if c=='C02':pose='think';opacity=ease(sec/.20)
 elif c=='C03':pose='surprise';opacity=1-ease((sec-.30)/.45)
 elif c=='C04':pose='think';opacity=1-ease((sec-.18)/.32)
 elif c=='C08':pose='happy';opacity=ease((t-.50)/.15)
 if pose and opacity>0:
  p=character(pose).copy();p.putalpha(p.getchannel('A').point(lambda x:int(x*opacity)));base.alpha_composite(p,(25,1010))
 return base
def compose(c):
 dest=R/'cuts'/c;dest.mkdir(parents=True,exist_ok=True);A=json.loads((R/'source'/f'{c}_anchors.json').read_text());ld=R/'layers'/c;ld.mkdir(parents=True,exist_ok=True)
 keys=['entry','cure','release','spew'] if c=='C07' else ['static'];L={k:label(c,k if c=='C07' else None) for k in keys}
 paths={}
 for k,im in L.items():
  if im.getbbox():p=ld/(k+'.png');im.save(p);paths[k]=str(p.relative_to(R))
 meta={'cut':c,'static_label_pngs':paths,'stage_intervals_normalized':{'entry':[0,.30],'cure':[.30,.51],'release':[.51,.69],'spew':[.69,1]} if c=='C07' else None,'animated_marks':'source/'+c+'_anchors.json','character_source':'shared-manifest.json','compose_script':'source/compose.py','transparent_empty_layers':'omitted, not encoded'}
 (ld/'layers.json').write_text(json.dumps(meta,indent=2))
 n=ROWS[c]['frames'];decoder=subprocess.Popen(['ffmpeg','-v','error','-threads','2','-i',str(dest/'scene.mp4'),'-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE)
 encoder=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','-','-frames:v',str(n),'-an','-c:v','libx264','-crf','17','-preset','fast','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(dest/'asset.mp4')],stdin=subprocess.PIPE)
 try:
  for i in range(n):
   data=decoder.stdout.read(1080*1920*3);assert len(data)==1080*1920*3,(c,i,len(data));im=Image.frombytes('RGB',(1080,1920),data).convert('RGBA');im.alpha_composite(overlay(c,i,A,L));encoder.stdin.write(im.convert('RGB').tobytes())
 finally:decoder.stdout.close();encoder.stdin.close()
 assert decoder.wait()==0 and encoder.wait()==0;print('COMPOSE_COMPLETE',c,flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--cut');a=ap.parse_args()
 for c in ([a.cut] if a.cut else list(ROWS)):compose(c)
