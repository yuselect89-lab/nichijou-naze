import math
HOLE_RADIUS=.032
SPEW_RADIUS=.020
SPEW_LENGTH=.31
MOLD_HEIGHT=.42
MOLD_LIFT=.80
POCKET=.16
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def relief(x):return -.115*(math.exp(-((x-.65)/.14)**2)+math.exp(-((x+.65)/.14)**2))
def pocket(x,y):return math.exp(-(x/.30)**2)*(1-.15*min(1,y/.65))
def state(c,t):
 if c=='C04':p=ease(t/.78);return dict(press=p,gap=POCKET*p,spew=0.,cure=0.,lift=0.,air=0.)
 if c=='C05':return dict(press=1.,gap=POCKET,spew=0.,cure=0.,lift=0.,air=0.)
 if c=='C06':a=ease((t-.16)/.68);return dict(press=1.,gap=POCKET*(1-a),spew=0.,cure=0.,lift=0.,air=a)
 return dict(press=1.,gap=0.,spew=ease((t-.06)/.22),cure=ease((t-.30)/.20),lift=MOLD_LIFT*ease((t-.51)/.17),air=1.)
def profile():
 # tip -> curved solid stem -> continuous base -> tire shoulder boundary
 return [(0.,1.),(.007,1.),(.016,.98),(SPEW_RADIUS,.92),(SPEW_RADIUS,.72),(SPEW_RADIUS,.46),(SPEW_RADIUS,.20),(.027,0.),(.048,0.),(.105,0.)]
def tire_mesh(segments=96):
 verts=[(0.,0.,-.24)];weights=[(.24,1.,1.)];rings=[]
 specs=profile()[1:]+[(.105+(1.0-.105)*j/30,0.) for j in range(1,31)]
 for k,(radius,h) in enumerate(specs):
  ring=[]
  for j in range(segments+1):
   angle=math.pi*j/segments
   if k<9:r=radius
   else:
    f=(radius-.105)/(1-.105);edge=min(1.18/max(abs(math.cos(angle)),1e-9),.70/max(abs(math.sin(angle)),1e-9));r=.105+f*(edge-.105)
   x=r*math.cos(angle);y=r*math.sin(angle);ring.append(len(verts));verts.append((x,y,-.24));weights.append((.24+relief(x),pocket(x,y),h))
  rings.append(ring)
 faces=[]
 for j in range(segments):faces.append((0,rings[0][j],rings[0][j+1]))
 for a,b in zip(rings,rings[1:]):
  for j in range(segments):faces.append((a[j],b[j],b[j+1],a[j+1]))
 lower=[]
 for i in rings[-1]:x,y,_=verts[i];lower.append(len(verts));verts.append((x,y,-.82));weights.append((0.,0.,0.))
 for j in range(segments):faces.append((rings[-1][j],lower[j],lower[j+1],rings[-1][j+1]))
 bottom=len(verts);verts.append((0,.25,-.82));weights.append((0.,0.,0.))
 for j in range(segments):faces.append((bottom,lower[j+1],lower[j]))
 faces.append((bottom,lower[0],lower[-1]))
 # One connected solid section face, including the stem. No appended cylinder.
 face=[0]+[r[0] for r in rings]+[lower[0],lower[-1]]+[r[-1] for r in reversed(rings)]
 faces.append(tuple(reversed(face)))
 return verts,faces,weights
