import bpy,json,hashlib,sys,math
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
R=Path(__file__).resolve().parents[1];rows=json.loads((R/'source/timing.json').read_text());cfg=json.loads((R/'source/macro-master.json').read_text());checks=[];hashes={}
def ck(name,ok,**kw):checks.append(dict(check=name,status='PASS' if ok else 'FAIL',**kw))
for name in ['MOLD_VENT_CUTAWAY','TIRE_MACRO_MASTER']:
 p=R/'source/blender'/(name+'.blend');bpy.ops.wm.open_mainfile(filepath=str(p));s=bpy.context.scene;hashes[str(p.relative_to(R))]=hashlib.sha256(p.read_bytes()).hexdigest();ck(name+' native portrait30fps',(s.render.resolution_x,s.render.resolution_y,s.render.resolution_percentage,s.render.fps)==(1080,1920,100,30))
 images=[im for im in bpy.data.images if im.source=='FILE'];ck(name+' relative resources survive extraction',all(im.filepath.startswith('//') and Path(bpy.path.abspath(im.filepath)).exists() for im in images))
 if name=='TIRE_MACRO_MASTER':
  ranges=json.loads((R/'source/macro-ranges.json').read_text());worst=0
  for cut in ['C01','C02','C03','C08']:
   A=json.loads((R/'source'/f'{cut}_anchors.json').read_text());ck(cut+' same fixed hair and picture throughout',all(a['hair_id']=='SPEW_001' and a['source_id']=='TIRE_MACRO_MASTER' for a in A))
   for i,a in enumerate(A):
    s.frame_set(ranges[cut]['first']+i);bpy.context.view_layer.update();p=Vector(((cfg['featured_root_normalized'][0]-.5)*1080,(.5-cfg['featured_root_normalized'][1])*1920,0));v=world_to_camera_view(s,s.camera,p);worst=max(worst,abs(v.x*1080-a['root'][0]),abs((1-v.y)*1920-a['root'][1]))
   n=len(A);c0,c1=cfg['centers'][cut]
   ck(cut+' photographic crop stays within image',all(0<=co[j]-sc/2 and co[j]+sc/2<=1 for co,sc in zip([c0,c1],cfg['crops'][cut]) for j in [0,1]))
  ck('Editable Blender macro camera matches actual fast-rendered projection',worst<.01,max_error_px=worst)
  a=json.loads((R/'source/C01_anchors.json').read_text())[-1];b=json.loads((R/'source/C08_anchors.json').read_text())[-1];ck('C01 C08 same hair and final camera framing',a==b)
  a=json.loads((R/'source/C07_anchors.json').read_text())[-1]['root'];b=json.loads((R/'source/C08_anchors.json').read_text())[0]['root'];ck('C07 C08 root-position match cut',max(abs(x-y) for x,y in zip(a,b))<.01,error_px=max(abs(x-y) for x,y in zip(a,b)))
 else:
  ck('One continuous source rubber with semantic spew group','RUBBER_SPEW' in bpy.data.objects['TIRE_RUBBER'].vertex_groups)
for row in rows:ck(row['cut_id']+' anchor count equals source frame count',len(json.loads((R/'source'/f'{row["cut_id"]}_anchors.json').read_text()))==row['frames'])
j={'status':'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL','checks':checks,'hashes':hashes,'macro_photo_sha256':hashlib.sha256((R/'assets/TIRE_MACRO.png').read_bytes()).hexdigest()};(R/'qc/sources.json').write_text(json.dumps(j,indent=2));print(json.dumps({'status':j['status'],'checks':len(checks),'failed':[c for c in checks if c['status']=='FAIL']}));assert j['status']=='PASS'
