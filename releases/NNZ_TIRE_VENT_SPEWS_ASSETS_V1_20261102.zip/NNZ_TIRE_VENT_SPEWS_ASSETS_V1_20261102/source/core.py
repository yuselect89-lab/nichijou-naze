"""One editable MOLD_VENT_CUTAWAY master. All geometry is original."""
import bpy,math,json,sys,argparse,shutil,hashlib
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'source'))
from geometry import *
ap=argparse.ArgumentParser();ap.add_argument('--cut');ap.add_argument('--still',type=float);ap.add_argument('--prepare',action='store_true');a=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
timing=json.loads((R/'source/timing.json').read_text()) if (R/'source/timing.json').exists() else [{'cut_id':c,'frames':n} for c,n in [('C04',150),('C05',150),('C06',120),('C07',240)]]
N={x['cut_id']:x['frames'] for x in timing};bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);s=bpy.context.scene;s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100;s.render.fps=30;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.compression=10;s.render.threads_mode='FIXED';s.render.threads=4;s.display.render_aa='8';sh=s.display.shading;sh.light='STUDIO';sh.studio_light='outdoor.sl';sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.curvature_ridge_factor=1.2;sh.curvature_valley_factor=1.1;sh.show_specular_highlight=True;s.world.color=(.075,.088,.10);s.view_settings.view_transform='Standard';s.view_settings.look='None';s.view_settings.exposure=.7
C={}
for name in ['MOLD_VENT_CUTAWAY','TIRE_RUBBER','MOLD_SURFACE','AIR_GAP','VENT_HOLE','RUBBER_SPEW','AIRFLOW_GUIDES','ENVIRONMENT']:
 col=bpy.data.collections.new(name);s.collection.children.link(col);C[name]=col
def put(o,col):
 for c in list(o.users_collection):c.objects.unlink(o)
 C[col].objects.link(o);o['master']='MOLD_VENT_CUTAWAY';o['version']='1.0.0';return o
def mat(n,rgb):
 m=bpy.data.materials.new(n);m.diffuse_color=(*rgb,1);m.use_nodes=True;p=m.node_tree.nodes['Principled BSDF'];p.inputs['Base Color'].default_value=(*rgb,1);p.inputs['Metallic'].default_value=.85 if 'Steel' in n else 0;p.inputs['Roughness'].default_value=.30 if 'Steel' in n else .65;return m
steel=mat('Steel outer faces',(.48,.53,.56));cutsteel=mat('Steel machined section',(.32,.38,.42));rubber=mat('Black solid tire surface',(.045,.052,.056));cutrubber=mat('Black rubber section',(.085,.094,.10));gas=mat('Air gap explanatory tint',(.29,.56,.66));blue=mat('Airflow guide',(.32,.70,.85));amber=mat('Heat and pressure annotation',(.65,.33,.09));tablemat=mat('Dark industrial workbench',(.12,.14,.155))
def mesh(n,v,f,col,m):
 me=bpy.data.meshes.new(n+' original mesh');me.from_pydata(v,[],f);me.update();ob=bpy.data.objects.new(n,me);C[col].objects.link(ob);ob.data.materials.append(m);ob['master']='MOLD_VENT_CUTAWAY';return ob
def box(n,loc,dim,col,m,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=put(bpy.context.object,col);o.name=n;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if bevel:mod=o.modifiers.new('Rounded machined edges','BEVEL');mod.width=bevel;mod.segments=3;o.modifiers.new('Weighted face normals','WEIGHTED_NORMAL')
 return o
v,f,w=tire_mesh();tire=mesh('TIRE_RUBBER',v,f,'TIRE_RUBBER',rubber);tire.data.materials.append(cutrubber)
for p in tire.data.polygons:p.use_smooth=p.index<len(f)-1;p.material_index=1 if p.index==len(f)-1 else 0
tire.shape_key_add(name='Basis')
for name,kind in [('PRESSED',0),('AIR_POCKET',1),('CONTINUOUS_SPEW',2)]:
 key=tire.shape_key_add(name=name)
 for pt,co,weights in zip(key.data,v,w):pt.co.z=co[2]+(weights[0] if kind==0 else -POCKET*weights[1] if kind==1 else SPEW_LENGTH*weights[2])
vg=tire.vertex_groups.new(name='RUBBER_SPEW');vg.add([i for i,q in enumerate(w) if q[2]>0],1.,'REPLACE');tire['spew_is_part_of_same_connected_mesh']=True
spewid=bpy.data.objects.new('RUBBER_SPEW',None);C['RUBBER_SPEW'].objects.link(spewid);spewid['geometry_owner']='TIRE_RUBBER';spewid['vertex_group']='RUBBER_SPEW'
root=bpy.data.objects.new('MOLD_TRANSLATION',None);C['MOLD_SURFACE'].objects.link(root)
xs=[-1.24+2.48*i/160 for i in range(161)];outline=[(-1.24,MOLD_HEIGHT),(1.24,MOLD_HEIGHT)]+[(x,relief(x)) for x in reversed(xs)];mv=[(x,y,z) for y in [0.,.76] for x,z in outline];L=len(outline);mf=[tuple(reversed(range(L))),tuple(range(L,2*L))]+[(i,(i+1)%L,(i+1)%L+L,i+L) for i in range(L)];mold=mesh('MOLD_SURFACE',mv,mf,'MOLD_SURFACE',steel);mold.parent=root
bpy.ops.mesh.primitive_cylinder_add(vertices=128,radius=HOLE_RADIUS,depth=2,location=(0,0,.2));tool=bpy.context.object;bpy.context.view_layer.objects.active=mold;mod=mold.modifiers.new('Permanent same VENT_HOLE','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=tool;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(tool,do_unlink=True)
mold.data.materials.append(cutsteel)
for p in mold.data.polygons:
 if p.normal.y<-.9:p.material_index=1
mod=mold.modifiers.new('Visible metal edge thickness','BEVEL');mod.width=.006;mod.segments=3;mold.modifiers.new('Machined face normals','WEIGHTED_NORMAL')
vent=bpy.data.objects.new('VENT_HOLE',None);C['VENT_HOLE'].objects.link(vent);vent.parent=root;vent['radius']=HOLE_RADIUS;vent['axis']='positive Z toward mold exterior';vent['hole_id']='VENT_001';vent['local_center']=[0.,0.,0.]
for x in [-.92,.92]:
 ob=box('TEMPERATURE_STRIP',(x,.45,.425),(.20,.48,.018),'MOLD_SURFACE',amber,.006);ob.parent=root
# Thin cavity indicator lies strictly between the two surfaces, never inside rubber.
av=[];af=[];steps=40
for zside in [0,1]:
 for yy in [0,.50]:
  for i in range(steps+1):x=-.50+i/steps;av.append((x,yy,relief(x)-(POCKET*pocket(x,yy) if zside else 0)))
nn=steps+1
for i in range(steps):
 af.extend([(i,i+1,i+1+nn,i+nn),(i+2*nn,i+3*nn,i+3*nn+1,i+2*nn+1),(i,i+2*nn,i+2*nn+1,i+1),(i+nn,i+nn+1,i+3*nn+1,i+3*nn)])
af.extend([(0,nn,3*nn,2*nn),(steps,steps+2*nn,steps+3*nn,steps+nn)])
air=mesh('AIR_GAP',av,af,'AIR_GAP',gas);air.shape_key_add(name='Basis');key=air.shape_key_add(name='EVACUATED')
for q,co in zip(key.data,av):q.co.z=relief(co[0])
def line3d(n,points,r,m):
 cu=bpy.data.curves.new(n,'CURVE');cu.dimensions='3D';cu.bevel_depth=r;cu.bevel_resolution=2;sp=cu.splines.new('POLY');sp.points.add(len(points)-1)
 for p,xyz in zip(sp.points,points):p.co=(*xyz,1)
 ob=bpy.data.objects.new(n,cu);C['AIRFLOW_GUIDES'].objects.link(ob);ob.data.materials.append(m);return ob
routes=[(-.42,.009,-.10),(-.22,.009,-.055),(-.05,.009,-.028),(0,.009,-.008),(0,.009,.20),(0,.009,.45),(.045,.009,.73)]
def route(u):
 u=max(0,min(.999999,u))*(len(routes)-1);i=int(u);f=u-i;return tuple(x+(y-x)*f for x,y in zip(routes[i],routes[i+1]))
flows=[]
for j in range(3):
 ob=line3d('AIR_FLOW_'+str(j),[route(0)]*12,.005,blue);bpy.ops.mesh.primitive_cone_add(vertices=12,radius1=.012,radius2=0,depth=.038);head=put(bpy.context.object,'AIRFLOW_GUIDES');head.name='AIR_ARROW_'+str(j);head.data.materials.append(blue);flows.append((ob,head))
table=box('WORKBENCH',(0,0,-.90),(18,12,.14),'ENVIRONMENT',tablemat,.02)
cd=bpy.data.cameras.new('CUTAWAY_CAMERA');cam=bpy.data.objects.new('CUTAWAY_CAMERA',cd);s.collection.objects.link(cam);s.camera=cam;cd.type='ORTHO';cd.clip_end=100
WHOLE=(2.3,-5.6,2.6,4.45,0,.1,-.08);CLOSE=(1.8,-5.7,2.3,3.12,0,.06,.10);LIFT=(2.0,-5.8,2.1,3.8,0,.06,.28);FOCUS=(1.7,-5.6,1.9,2.45,0,.03,.12)
def lerp(a,b,t):return tuple(x+(y-x)*t for x,y in zip(a,b))
def apply(c,t):
 d=state(c,t);keys=tire.data.shape_keys.key_blocks;keys['PRESSED'].value=d['press'];keys['AIR_POCKET'].value=d['gap']/POCKET;keys['CONTINUOUS_SPEW'].value=d['spew'];root.location.z=d['lift'];air.data.shape_keys.key_blocks['EVACUATED'].value=1-d['gap']/POCKET;air.hide_render=c=='C07' or c=='C04' or d['gap']<.002
 if c=='C04':q=WHOLE
 elif c=='C05':q=lerp(WHOLE,CLOSE,ease(t/.85))
 elif c=='C06':q=CLOSE
 elif t<.48:q=CLOSE
 elif t<.69:q=lerp(CLOSE,LIFT,ease((t-.48)/.17))
 else:q=lerp(LIFT,FOCUS,ease((t-.69)/.19))
 cam.location=q[:3];cam.rotation_euler=(Vector(q[4:])-cam.location).to_track_quat('-Z','Y').to_euler();cd.ortho_scale=q[3]
 for j,(ob,head) in enumerate(flows):
  visible=c=='C06' and .16<t<.88;ob.hide_render=head.hide_render=not visible;u=((t-.16)*1.85+j*.28)%1
  for k,p in enumerate(ob.data.splines[0].points):p.co=(*route(max(0,u-.115+k*.115/11)),1)
  head.location=route(u);v=Vector(route(min(.999,u+.004)))-Vector(route(max(0,u-.004)))
  if v.length>0:head.rotation_euler=v.to_track_quat('Z','Y').to_euler()
 bpy.context.view_layer.update();return d
def project(p):
 q=world_to_camera_view(s,cam,Vector(p));return [1080*q.x,1920*(1-q.y)]
out=R/'source/blender';out.mkdir(exist_ok=True)
if a.still is not None:
 c=a.cut or 'C06';apply(c,a.still);s.render.filepath=str(R/'qc'/f'{c}-native-{round(a.still*100):03}.png');bpy.ops.render.render(write_still=True);print('STILL_COMPLETE',c,a.still);raise SystemExit(0)
offset=1;ranges={}
for c in ['C04','C05','C06','C07']:
 n=N[c];ranges[c]={'first':offset,'last':offset+n-1};offset+=n
anchors={}
for c in ['C04','C05','C06','C07']:
 anchors[c]=[]
 for i in range(N[c]):
  frame=ranges[c]['first']+i;s.frame_set(frame);d=apply(c,i/(N[c]-1))
  for ob in [root,cam,air]+[z for pair in flows for z in pair]:
   for prop in ['location','rotation_euler','hide_render']:ob.keyframe_insert(prop,frame=frame)
  cd.keyframe_insert('ortho_scale',frame=frame)
  for name in ['PRESSED','AIR_POCKET','CONTINUOUS_SPEW']:tire.data.shape_keys.key_blocks[name].keyframe_insert('value',frame=frame)
  air.data.shape_keys.key_blocks['EVACUATED'].keyframe_insert('value',frame=frame)
  for ob,_ in flows:
   for p in ob.data.splines[0].points:p.keyframe_insert('co',frame=frame)
  anchors[c].append({'state':d,'root':project((0,0,-d['gap'])),'tip':project((0,0,-d['gap']+SPEW_LENGTH*d['spew'])),'hole':project((0,0,.22+d['lift'])),'exit':project((0,0,MOLD_HEIGHT+d['lift']+.13)),'hole_id':'VENT_001'})
 (R/'source'/f'{c}_anchors.json').write_text(json.dumps(anchors[c]))
s.frame_start=1;s.frame_end=offset-1;s.frame_set(ranges['C06']['first']);apply('C06',0)
(R/'source/core-ranges.json').write_text(json.dumps(ranges,indent=2));bpy.ops.wm.save_as_mainfile(filepath=str(out/'MOLD_VENT_CUTAWAY.blend'),compress=True)
if a.prepare:raise SystemExit(0)
cache=R/'.cache/core-frames';cache.mkdir(parents=True,exist_ok=True)
for c in ([a.cut] if a.cut else ['C06','C07','C04','C05']):
 dest=cache/c;dest.mkdir(exist_ok=True);holds={}
 for i in range(N[c]):
  t=i/(N[c]-1);key=('hold-end' if c=='C06' and t>=.88 else 'hold-start' if c=='C07' and t<=.06 else 'hold-end' if c=='C07' and t>=.88 else None);p=dest/f'{i:04}.png'
  if key in holds:shutil.copyfile(holds[key],p);continue
  s.frame_set(ranges[c]['first']+i);apply(c,t);s.render.filepath=str(p);bpy.ops.render.render(write_still=True)
  if key:holds[key]=p
 print('RENDER_COMPLETE',c,flush=True)
