from pathlib import Path
import os,sys,json,subprocess
import numpy as np
sys.path.insert(0,os.environ.get('NNZ_ASR_DEPS','/workspace/tire-asr-deps'))
import sherpa_onnx
R=Path(__file__).resolve().parents[1];data=json.loads((R/'qc/paragraph-bounds.json').read_text());m=Path(os.environ.get('NNZ_ASR_MODEL','/workspace/tire-asr-model/sherpa-onnx-whisper-tiny'))
rec=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(m/'tiny-encoder.int8.onnx'),decoder=str(m/'tiny-decoder.int8.onnx'),tokens=str(m/'tiny-tokens.txt'),language='ja',num_threads=3)
raw=subprocess.run(['ffmpeg','-v','error','-i',str(R/'audio/VO_original.mp3'),'-f','s16le','-ac','1','-ar','16000','-'],capture_output=True,check=True).stdout;x=np.frombuffer(raw,dtype='<i2').astype('float32')/32768
for p in data['paragraphs']:
 stream=rec.create_stream();stream.accept_waveform(16000,x[round(p['begin']*16000):round(p['end']*16000)]);rec.decode_stream(stream);p['recognized']=stream.result.text
 print(json.dumps(p,ensure_ascii=False),flush=True)
data['review_status']='PENDING_CONTENT_REVIEW';data['limitations']='Sentence boundaries measured at midpoints of actual >0.5s pauses; ASR has Japanese spelling errors; no word/phoneme timestamp claim.'
(R/'qc/sentence-alignment.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
