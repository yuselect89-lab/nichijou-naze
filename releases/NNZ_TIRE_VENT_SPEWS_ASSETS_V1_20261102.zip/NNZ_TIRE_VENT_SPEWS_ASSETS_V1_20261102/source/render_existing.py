"""Render the stored common master; never rebuild one model per cut."""
import bpy,json,sys,argparse,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--cuts',nargs='+',default=['C06','C07','C04','C05']);a=ap.parse_args(sys.argv[sys.argv.index('--')+1:])
bpy.ops.wm.open_mainfile(filepath=str(R/'source/blender/MOLD_VENT_CUTAWAY.blend'));s=bpy.context.scene;table=json.loads((R/'source/core-ranges.json').read_text());cache=R/'.cache/core-frames';cache.mkdir(parents=True,exist_ok=True)
for c in a.cuts:
 span=table[c];N=span['last']-span['first']+1;dest=cache/c;dest.mkdir(exist_ok=True);holds={}
 for i in range(N):
  t=i/(N-1);key='end' if c=='C06' and t>=.88 or c=='C07' and t>=.88 else 'start' if c=='C07' and t<=.06 else None;p=dest/f'{i:04}.png'
  if key and key in holds:shutil.copyfile(holds[key],p);continue
  s.frame_set(span['first']+i);bpy.context.view_layer.update();s.render.filepath=str(p);bpy.ops.render.render(write_still=True)
  if key:holds[key]=p
 print('RENDER_COMPLETE',c,flush=True)
