from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,zipfile,tempfile,subprocess,csv,os
R=Path(__file__).resolve().parents[1];repo=R.parents[3];name='NNZ_TIRE_VENT_SPEWS_ASSETS_V1_20261102';out=repo/'releases'/(name+'.zip')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
media=json.loads((R/'qc/media.json').read_text());sources=json.loads((R/'qc/sources.json').read_text());player=json.loads((R/'qc/playback-qc.json').read_text());visual=json.loads((R/'qc/visual-review.json').read_text());core=json.loads((R/'qc/core-geometry.json').read_text())
assert media['status']==sources['status']==player['status']==core['status']=='PASS';assert visual['status']=='REVIEWED';assert len(media['videos'])==16 and len(player['results'])==8
for p in media['videos']:assert sha(R/p['path'])==p['sha256']
for p,h in sources['hashes'].items():assert sha(R/p)==h
for x in player['results']:assert sha(R/'cuts'/x['cut']/'asset.mp4')==x['sha256']
assert sha(R/'source/blender/MOLD_VENT_CUTAWAY.blend')==core['source_sha256']
rows=json.loads((R/'source/timing.json').read_text());audio=json.loads((R/'qc/audio-original.json').read_text());assert sha(R/audio['path'])==audio['sha256']
manifest={'project':'TIRE_VENT_SPEWS','version':'1.0.0','created_utc':datetime.now(timezone.utc).isoformat(timespec='seconds'),'source_commit':'a2ed1be75cca0e0e555a477a9a5b50e65a8bdf04','state':'RENDERED_SELF_REVIEWED','g2_written_qc':'PASS','independent_actual_g2':'NOT_RUN','completed_episode_g3':'NOT_RUN','voice':audio,'voice_timing':'ACTUAL_SENTENCE_BOUNDARIES_NOT_PHONEME_FORCED_ALIGNMENT','shared_assets':json.loads((R/'shared-manifest.json').read_text())['assets'],'masters':[{'id':'MOLD_VENT_CUTAWAY','version':'1.0.0','source':'source/blender/MOLD_VENT_CUTAWAY.blend','cut_ranges':'source/core-ranges.json','cuts':['C04','C05','C06','C07']},{'id':'TIRE_MACRO_MASTER','version':'1.0.0','source':'source/blender/TIRE_MACRO_MASTER.blend','cut_ranges':'source/macro-ranges.json','cuts':['C01','C02','C03','C08']}],'cuts':[dict(row,asset=f'cuts/{row["cut_id"]}/asset.mp4',scene=f'cuts/{row["cut_id"]}/scene.mp4',editable_layers=f'layers/{row["cut_id"]}/layers.json') for row in rows],'qc':{'media':'qc/media.json','sources':'qc/sources.json','core':'qc/core-geometry.json','visual':'qc/visual-review.json','playback':'qc/playback-qc.json','performance':'qc/performance.json'},'handoff':'WORK_ASSEMBLY.md','rights':'PROVENANCE.md'}
(R/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
files=[]
for directory,dirs,names in os.walk(R):
 dirs[:]=[d for d in dirs if d not in ['.cache','__pycache__']]
 for n in names:
  if n.endswith(('.blend1','.pyc')) or n in ['FILELIST.csv','SHA256SUMS.txt','asset-lock.json','finish_qc.py']:continue
  files.append(Path(directory)/n)
files=sorted(files)
with (R/'FILELIST.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['path','bytes','sha256']);w.writerows((p.relative_to(R).as_posix(),p.stat().st_size,sha(p)) for p in files)
files.append(R/'FILELIST.csv');(R/'asset-lock.json').write_text(json.dumps({'version':'1.0.0','files':{p.relative_to(R).as_posix():sha(p) for p in files}},indent=2));files.append(R/'asset-lock.json');(R/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(R).as_posix()+'\n' for p in files));files.append(R/'SHA256SUMS.txt');assert not out.exists()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,name+'/'+p.relative_to(R).as_posix(),compress_type=zipfile.ZIP_STORED if p.suffix=='.xz' else zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(out) as z,tempfile.TemporaryDirectory(prefix='tire-unzip-',dir='/tmp') as temp:
 assert z.testzip() is None
 for p in files:assert hashlib.sha256(z.read(name+'/'+p.relative_to(R).as_posix())).hexdigest()==sha(p)
 z.extractall(temp);extracted=Path(temp)/name
 for script in ['verify_sources.py','verify_core.py']:
  subprocess.run(['blender','-b','-t','2','--python-exit-code','1','--python',str(extracted/'source'/script)],check=True,capture_output=True)
 subprocess.run(['python','-c','from font_loader import fonts;fonts()'],cwd=extracted/'source',check=True,capture_output=True)
 for x in media['videos']:subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(extracted/x['path']),'-an','-f','null','-'],check=True,capture_output=True)
 assert sha(extracted/audio['path'])==audio['sha256']
assert out.stat().st_size<104857600
proof={'status':'PASS','file':out.name,'bytes':out.stat().st_size,'sha256':sha(out),'entries':len(files),'reopened_zip_full_video_decode':16,'portable_common_masters_loaded':2,'core_checks':len(core['checks']),'font_originals_restored_and_sha_checked':True,'original_voice_unchanged':True,'crc':'PASS','all_hashes':'PASS'}
out.with_suffix('.verification.json').write_text(json.dumps(proof,indent=2));out.with_suffix('.zip.sha256').write_text(proof['sha256']+'  '+out.name+'\n');print(json.dumps(proof,indent=2))
