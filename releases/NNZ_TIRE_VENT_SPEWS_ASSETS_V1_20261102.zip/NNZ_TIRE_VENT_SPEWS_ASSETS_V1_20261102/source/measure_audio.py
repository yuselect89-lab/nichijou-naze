"""Analysis only. Never rewrites the uploaded MP3."""
from pathlib import Path
import os,sys,subprocess,json,re
import numpy as np
sys.path.insert(0,os.environ.get('NNZ_ASR_DEPS','/workspace/tire-asr-deps'))
import sherpa_onnx
R=Path(__file__).resolve().parents[1];p=R/'audio/VO_original.mp3'
pcm=subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','s16le','-ac','1','-ar','16000','-'],check=True,capture_output=True).stdout
x=np.frombuffer(pcm,dtype='<i2').astype('float32')/32768;duration=len(x)/16000
sil=subprocess.run(['ffmpeg','-v','info','-i',str(p),'-af','silencedetect=noise=-38dB:d=0.12','-f','null','-'],capture_output=True,text=True,check=True).stderr
events=[(a,float(b)) for a,b in re.findall(r'silence_(start|end): ([0-9.]+)',sil)];pairs=[];start=0
for kind,t in events:
 if kind=='start':start=t
 else:pairs.append([start,t])
split=min([sum(v)/2 for v in pairs if 15<sum(v)/2<25],key=lambda v:abs(v-20),default=20)
m=Path(os.environ.get('NNZ_ASR_MODEL','/workspace/tire-asr-model/sherpa-onnx-whisper-tiny'))
rec=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(m/'tiny-encoder.int8.onnx'),decoder=str(m/'tiny-decoder.int8.onnx'),tokens=str(m/'tiny-tokens.txt'),language='ja',task='transcribe',num_threads=3,enable_token_timestamps=True,enable_segment_timestamps=True)
segments=[]
for begin,end in [(0,split),(split,duration)]:
 stream=rec.create_stream();stream.accept_waveform(16000,x[round(begin*16000):round(end*16000)]);rec.decode_stream(stream);r=stream.result
 j={'begin':begin,'end':end,'text':r.text,'tokens':list(r.tokens),'timestamps':[begin+t for t in r.timestamps]};segments.append(j);print(json.dumps({'begin':begin,'end':end,'text':r.text},ensure_ascii=False),flush=True)
result={'method':'Local Whisper tiny int8 ASR with actual audio samples and token timestamps; human-readable script alignment is reviewed separately','audio_duration_s':duration,'silences':pairs,'segments':segments,'voice_modified':False}
(R/'qc/audio-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('AUDIO_ANALYSIS_COMPLETE',duration,flush=True)
