"""One photographic macro source, meaningful slow reframing, four cuts."""
from pathlib import Path
from PIL import Image
import argparse,json,subprocess,math
from geometry import ease
R=Path(__file__).resolve().parents[1];T=json.loads((R/'source/timing.json').read_text());ROWS={x['cut_id']:x for x in T};CFG=json.loads((R/'source/macro-master.json').read_text())
def frame(c,t):
 im=Image.open(R/'assets/TIRE_MACRO.png').convert('RGB');w,h=im.size;s0,s1=CFG['crops'][c];scale=s0+(s1-s0)*ease(t);q=ease(t);c0,c1=CFG['centers'][c];cx=w*(c0[0]+(c1[0]-c0[0])*q);cy=h*(c0[1]+(c1[1]-c0[1])*q);box=(cx-w*scale*.5,cy-h*scale*.5,cx+w*scale*.5,cy+h*scale*.5)
 out=im.resize((1080,1920),Image.Resampling.LANCZOS,box=box);rx,ry=CFG['featured_root_normalized'];point=[540+(rx-cx/w)*1080/scale,960+(ry-cy/h)*1920/scale]
 return out,{'root':point,'crop_scale':scale,'source_id':'TIRE_MACRO_MASTER','hair_id':'SPEW_001'}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--cut');a=ap.parse_args()
 for c in ([a.cut] if a.cut else ['C01','C02','C03','C08']):
  n=ROWS[c]['frames'];d=R/'cuts'/c;d.mkdir(parents=True,exist_ok=True);anchors=[]
  p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','-','-frames:v',str(n),'-an','-c:v','libx264','-crf','17','-preset','fast','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(d/'scene.mp4')],stdin=subprocess.PIPE)
  try:
   for i in range(n):im,anchor=frame(c,i/(n-1));p.stdin.write(im.tobytes());anchors.append(anchor)
  finally:p.stdin.close()
  assert p.wait()==0;(R/'source'/f'{c}_anchors.json').write_text(json.dumps(anchors));print('MACRO_SCENE_COMPLETE',c,flush=True)
  subprocess.run(['python',str(R/'source/compose.py'),'--cut',c],check=True)
