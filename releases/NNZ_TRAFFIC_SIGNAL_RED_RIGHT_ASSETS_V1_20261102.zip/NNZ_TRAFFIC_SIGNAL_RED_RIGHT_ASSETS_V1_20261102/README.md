# 信号機「赤が右端」素材パッケージ

編集入口は **WORK_ASSEMBLY.md**。全8カットの無音編集素材・分離レイヤー・3D/合成ソース・原画像・プロンプト・編集点CSV・QC・SHA256を収録する。完成本編の組立と実VOの最終照合、G3はWorkの担当。

- `cuts/Cxx/asset.mp4`：そのまま組み立てる編集素材。
- `scene.mp4`、`labels.webm`、`marks.webm`、`character.webm`：再編集する場合の分離版。
- `source/blender/`：8カットの3Dソース。画像は相対パスで `assets/` を共有。
- `reference/`：変更していない発注書、G1 V2、G2 V2、実VO編集点CSV。
- `qc/`：機械検証、実再生、360px、動きと実画のQC結果。

G2 V2の書面QCは未判定。素材の実画確認と区別する。台本・音声・制作LOCKは変更しない。
