from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,math,subprocess,sys,time,argparse
R=Path(__file__).resolve().parents[1];TIM=json.loads((R/'source/timing.json').read_text());N={r['cut_id']:r['frames'] for r in TIM}
PRIMARY=['','なぜ右端？','赤を見やすく','左側通行','街路樹の枝','左側が隠れることも','赤は道路中央寄り','赤を見失わない工夫'];cache={}
def font(n,b=True):
 k=(n,b)
 if k not in cache:cache[k]=ImageFont.truetype(str(R/('public/series/v1/NotoSansCJKjp-Bold.otf' if b else 'assets/Regular.ttc')),n)
 return cache[k]
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def word(d,xy,txt,n=48,b=True,color='#263c48'):
 f=font(n,b);w=d.textlength(txt,font=f);x,y=xy;d.rounded_rectangle((x-w/2-20,y-n*.65-10,x+w/2+20,y+n*.65+10),radius=12,fill='#ffffffed');d.text(xy,txt,font=f,anchor='mm',fill=color)
def overlay(c,i,kind):
 n=N[c];t=i/(n-1);im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im);anchors=ANCH[c][i];ci=list(N).index(c);rx,ry=anchors['red'];gx,gy=anchors['green'];mode=anchors['mode'];rad=abs(rx-gx)/4*.95
 if kind in ['labels','marks']:
  if kind=='labels' and PRIMARY[ci]:word(d,(540,230),PRIMARY[ci],64)
  if kind=='labels' and c=='C05':word(d,(540,340),'想定イメージ',36,False)
  if kind=='labels' and c in ['C06','C07'] and mode>.05:
   word(d,(540,340),'模式図 ／ 想定例',36,False)
   if c=='C07':
    progress=ease(t/.25) if t<.32 else ease((t-.59)/.20);end=150+730*progress;d.line((150,440,end,440),fill='#647981',width=3)
    if progress>.05:d.polygon([(end,440),(end-18,432),(end-18,448)],fill='#647981')
    word(d,(235,403),'木の側',34,False);word(d,(785,403),'道路中央側',34,False)
  if kind=='labels':return im
  if c in ['C02','C03','C08']:
   alpha=math.sin(math.pi*min(1,t*1.5)) if c!='C08' else math.sin(math.pi*max(0,min(1,(t-.3)/.7)))
   if alpha>0:d.ellipse((rx-rad-12,ry-rad-12,rx+rad+12,ry+rad+12),outline=(204,153,45,int(230*alpha)),width=4)
  if c in ['C05','C06']:
   r=rad*1.6;cx=gx-r*.35;d.ellipse((cx-r,gy-r,cx+r,gy+r),outline='#d2a345',width=4)
  if c=='C07' and mode>.6:
   u=ease(t/.25) if t<.32 else ease((t-.59)/.20);sx,sy=rx+rad+100,ry-90;ex,ey=sx-85*u,sy+75*u;d.line((sx,sy,ex,ey),fill='#c3963d',width=5)
   if u>.85:d.polygon([(ex,ey),(ex+25,ey-6),(ex+13,ey-25)],fill='#c3963d')
  if c=='C04':
   # Floating explanatory arrow, not a fabricated road marking.
   d.line((585,1440,560,1290),fill='#f9f8eff0',width=6);d.polygon([(560,1290),(548,1319),(572,1315)],fill='#f9f8ef');word(d,(540,1450),'赤信号で停止',34,False)
 else:
  pose=None;alpha=0
  if c=='C02':pose='think';alpha=ease(t/.18)
  if c=='C03':pose='surprise';alpha=1-ease((t-.10)/.12)
  if c=='C08':pose='happy';alpha=ease((t-.35)/.17)
  if pose:
   pic=SPR[pose].copy();pic.putalpha(pic.getchannel('A').point(lambda x:int(x*alpha)));im.alpha_composite(pic,(70,1110))
 return im
SPR={p:Image.open(R/f'assets/CHAR_{p}.png').convert('RGBA').crop((260,0,1280,960)).resize((410,386),Image.Resampling.LANCZOS) for p in ['think','surprise','happy']};ANCH={}
for pic in SPR.values():
 alpha=pic.getchannel('A');mask=Image.new('L',pic.size,255)
 for y in range(330,386):
  for x in range(410):mask.putpixel((x,y),int(255*(385-y)/55))
 from PIL import ImageChops
 pic.putalpha(ImageChops.multiply(alpha,mask))
def enc_layer(c,kind):
 out=R/'cuts'/c/f'{kind}.webm';p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgba','-s','1080x1920','-r','30','-i','-','-an','-c:v','libvpx-vp9','-pix_fmt','yuva420p','-b:v','0','-crf','20','-deadline','good','-cpu-used','5','-auto-alt-ref','0','-threads','2',str(out)],stdin=subprocess.PIPE)
 try:
  for i in range(N[c]):p.stdin.write(overlay(c,i,kind).tobytes())
 finally:p.stdin.close()
 assert p.wait()==0

def compose(c):
 d=R/'cuts'/c;d.mkdir(parents=True,exist_ok=True);ANCH[c]=json.loads((R/'source'/f'{c}_anchors.json').read_text())
 sequence=('BLEND_'+c) if (R/'source/frames'/('BLEND_'+c)).exists() else c
 subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-i',str(R/'source/frames'/sequence/'%04d.png'),'-frames:v',str(N[c]),'-an','-c:v','libx264','-crf','16','-preset','fast','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(d/'scene.mp4')],check=True)
 for k in ['labels','marks','character']:enc_layer(c,k)
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(d/'scene.mp4'),'-c:v','libvpx-vp9','-i',str(d/'labels.webm'),'-c:v','libvpx-vp9','-i',str(d/'marks.webm'),'-c:v','libvpx-vp9','-i',str(d/'character.webm'),'-filter_complex','[0:v][1:v]overlay=format=auto[a];[a][2:v]overlay=format=auto[b];[b][3:v]overlay=format=auto,format=yuv420p[v]','-map','[v]','-r','30','-frames:v',str(N[c]),'-an','-c:v','libx264','-crf','16','-preset','fast','-threads','2','-movflags','+faststart',str(d/'asset.mp4')],check=True)
 print('COMPLETE',c,flush=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--wait',action='store_true');ap.add_argument('--cut');ap.add_argument('--start-cut');a=ap.parse_args()
 selected=[a.cut] if a.cut else list(N)[list(N).index(a.start_cut):] if a.start_cut else list(N)
 for c in selected:
  if a.wait:
   while len(list((R/'source/frames'/c).glob('*.png')))<N[c]:time.sleep(2)
   while True:
    try:
     for i in range(N[c]):
      with Image.open(R/'source/frames'/c/f'{i:04}.png') as im:im.load()
     break
    except (OSError,FileNotFoundError):time.sleep(2)
  compose(c)
 print('ALL_COMPOSED',flush=True)
if __name__=='__main__':main()
