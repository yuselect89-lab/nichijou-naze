import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
for r in json.loads((R/'source/timing.json').read_text()):
 p=R/'source/blender'/(r['cut_id']+'.blend');bpy.ops.wm.open_mainfile(filepath=str(p))
 for im in bpy.data.images:
  if im.name.startswith('STREET_AI'):name='STREET_AI.png'
  elif im.name.startswith('SIGNAL_PHOTO_SURFACE'):name='SIGNAL_PHOTO_SURFACE.png'
  else:continue
  if im.packed_file:im.unpack(method='REMOVE')
  im.filepath='//../../assets/'+name
 bpy.ops.wm.save_as_mainfile(filepath=str(p),compress=True)
print('Shared texture paths portable; no geometry, animation or image edits')
