from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,subprocess,hashlib,csv
R=Path(__file__).resolve().parents[1];rows=json.loads((R/'source/timing.json').read_text());Q=R/'qc';D=Q/'frames';D.mkdir(exist_ok=True)
checks=[];meta=[];gallery=Image.new('RGB',(1440,1280),'#eef1f3');f=ImageFont.truetype(str(R/'public/series/v1/NotoSansCJKjp-Bold.otf'),22)
def run(a):return subprocess.run(a,check=True,capture_output=True,text=True).stdout
for idx,r in enumerate(rows):
 c=r['cut_id'];n=r['frames']
 for name in ['scene.mp4','asset.mp4','labels.webm','marks.webm','character.webm']:
  p=R/'cuts'/c/name;j=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(p)]));v=next(x for x in j['streams'] if x['codec_type']=='video');ok=v['width']==1080 and v['height']==1920 and v['r_frame_rate']=='30/1' and int(v['nb_read_frames'])==n and not any(x['codec_type']=='audio' for x in j['streams']);assert ok,(c,name,v)
  if name.endswith('webm'):assert v.get('tags',{}).get('alpha_mode')=='1'
  run(['ffmpeg','-v','error','-threads','2']+(['-c:v','libvpx-vp9'] if name.endswith('webm') else [])+['-i',str(p),'-an','-f','null','-'])
  meta.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frames':n,'fps':30,'audio':False,'full_decode':'PASS'})
 sheet=Image.new('RGB',(1080,414),'#edf1f3');d=ImageDraw.Draw(sheet)
 for k,t in enumerate([0,.25,.5,.75,1]):
  frame=round((n-1)*t);out=D/f'{c}_{frame:04}.jpg';run(['ffmpeg','-v','error','-y','-i',str(R/'cuts'/c/'asset.mp4'),'-vf',f'select=eq(n\\,{frame}),scale=216:384','-frames:v','1',str(out)]);sheet.paste(Image.open(out),(k*216,30));d.text((k*216+4,2),f'{c} {frame:03}f',font=f,fill='#243e49')
 sheet.save(Q/f'{c}_motion.jpg',quality=95)
 out=D/f'{c}_360.jpg';run(['ffmpeg','-v','error','-y','-i',str(R/'cuts'/c/'asset.mp4'),'-vf',f'select=eq(n\\,{round((n-1)*.5)}),scale=360:640','-frames:v','1',str(out)]);gallery.paste(Image.open(out),((idx%4)*360,(idx//4)*640))
gallery.save(Q/'contact-360.jpg',quality=95);gallery.convert('L').save(Q/'contact-gray.jpg',quality=95)
# Original CSV is retained verbatim; a separate frame mapping accounts for rounding.
with (R/'EDIT_POINTS_FRAMES.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
(Q/'media.json').write_text(json.dumps({'status':'PASS','videos':meta,'duration_note':'933 frames / 30 = 31.1s. Source VO endpoint 31.085688s retained; max frame rounding < 1/60s. No VO editing or word-level sync claim.'},indent=2))
print('MEDIA PASS',len(meta))
# Same-scene identity and real-video protected-area evidence.
def extract(c,frame,out):
 run(['ffmpeg','-v','error','-y','-i',str(R/'cuts'/c/'scene.mp4'),'-vf',f'select=eq(n\\,{frame})','-frames:v','1',str(out)])
 return Image.open(out).convert('RGBA')
pair=Image.new('RGB',(720,640),'white')
for k,(c,fr) in enumerate([('C01',0),('C08',rows[-1]['frames']-1)]):pair.paste(extract(c,fr,D/f'{c}-identity.png').resize((360,640),Image.Resampling.LANCZOS).convert('RGB'),(k*360,0))
pair.save(Q/'C01-C08-identity.jpg',quality=95)
ui=Image.new('RGB',(1440,640),'white')
for k,c in enumerate(['C01','C02','C04','C06']):
 fr=0 if c=='C01' else next(r['frames'] for r in rows if r['cut_id']==c)-1;out=D/f'{c}-ui.png';run(['ffmpeg','-v','error','-y','-i',str(R/'cuts'/c/'asset.mp4'),'-vf',f'select=eq(n\\,{fr})','-frames:v','1',str(out)]);im=Image.open(out).convert('RGBA')
 if c=='C01':im.alpha_composite(Image.open(R/'public/series/approved/opening_banner.png').convert('RGBA').resize((920,920),Image.Resampling.LANCZOS),(80,88))
 mask=Image.new('RGBA',im.size);d=ImageDraw.Draw(mask);d.rectangle((96,1510,984,1790),fill=(30,45,60,190));d.rectangle((984,580,1080,1790),fill=(30,45,60,120));im.alpha_composite(mask);ui.paste(im.resize((360,640),Image.Resampling.LANCZOS).convert('RGB'),(360*k,0))
ui.save(Q/'protected-ui.jpg',quality=95)
listing=Q/'continuity.txt';listing.write_text(''.join("file '../cuts/"+c+"/asset.mp4'\n" for c in ['C05','C06','C07']))
run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(listing),'-c','copy','-an',str(Q/'C05-C07-continuity.mp4')])
print('Identity, UI and continuity evidence generated')
