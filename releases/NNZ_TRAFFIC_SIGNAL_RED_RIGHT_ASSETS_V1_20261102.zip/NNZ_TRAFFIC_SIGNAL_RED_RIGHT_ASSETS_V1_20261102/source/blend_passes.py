from pathlib import Path
from PIL import Image
import json,shutil,argparse
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--cut');args=ap.parse_args()
for c in ([args.cut] if args.cut in ['C06','C07','C08'] else [] if args.cut else ['C06','C07','C08']):
 dest=R/'source/frames'/('BLEND_'+c);dest.mkdir(parents=True,exist_ok=True)
 for i,a in enumerate(json.loads((R/'source'/f'{c}_anchors.json').read_text())):
  raw=R/'source/frames'/c/f'{i:04}.png';out=dest/f'{i:04}.png';mode=a['mode']
  if not 0<mode<1:shutil.copy2(raw,out);continue
  with Image.open(R/'source/frames'/('PHOTO_'+c)/f'{i:04}.png') as p,Image.open(raw) as b:Image.blend(p.convert('RGB'),b.convert('RGB'),mode).save(out,compress_level=2)
print('Matched-camera dissolves composited')
