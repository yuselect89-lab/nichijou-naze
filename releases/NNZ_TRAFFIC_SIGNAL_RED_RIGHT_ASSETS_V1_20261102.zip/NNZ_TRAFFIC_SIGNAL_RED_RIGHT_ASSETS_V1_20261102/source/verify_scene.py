import bpy,json,hashlib
from mathutils import Vector
from pathlib import Path
R=Path(__file__).resolve().parents[1];rows=json.loads((R/'source/timing.json').read_text());edges={};checks=[]
ids=['GREEN_OFF','AMBER_OFF','RED_ON','LEFT_SIGNAL_POST','TREE_TRUNK','STOPPED_CAR_0','STOPPED_CAR_1','CENTER_LINE']
def edge(f):
 s=bpy.context.scene;s.frame_set(f);bpy.context.view_layer.update();return {'camera':list(s.camera.matrix_world[0])+list(s.camera.matrix_world[1])+list(s.camera.matrix_world[2])+[s.camera.data.ortho_scale],'positions':{id:list(bpy.data.objects[id].matrix_world.translation) for id in ids}}
for r in rows:
 c=r['cut_id'];p=R/f'source/blender/{c}.blend';bpy.ops.wm.open_mainfile(filepath=str(p));edges[c]={'first':edge(1),'last':edge(r['frames'])}
 checks.append({'check':c+' texture resources','status':'PASS' if all(Path(bpy.path.abspath(im.filepath)).is_file() for im in bpy.data.images if im.source=='FILE' and im.name.startswith(('STREET_AI','SIGNAL_PHOTO_SURFACE'))) else 'FAIL'})
 checks.append({'check':c+' ordering and central side','status':'PASS' if bpy.data.objects['LEFT_SIGNAL_POST'].location.x < bpy.data.objects['GREEN_OFF'].location.x < bpy.data.objects['AMBER_OFF'].location.x < bpy.data.objects['RED_ON'].location.x < bpy.data.objects['CENTER_LINE'].location.x else 'FAIL'})
 checks.append({'check':c+' left-hand traffic / stopped cars','status':'PASS' if all(bpy.data.objects['STOPPED_CAR_'+str(i)].location.x<0 and bpy.data.objects['STOPPED_CAR_'+str(i)].location.y < -.8 for i in [0,1]) else 'FAIL'})
 if c in ['C06','C07']:
  dep=bpy.context.evaluated_depsgraph_get();direction=bpy.context.scene.camera.matrix_world.to_quaternion()@Vector((0,0,-1));counts={}
  for lamp in ['GREEN_OFF','RED_ON']:
   center=bpy.data.objects[lamp].matrix_world.translation;blocked=0;total=0
   for dx in [-.24,-.12,0,.12,.24]:
    for dz in [-.24,-.12,0,.12,.24]:
     if dx*dx+dz*dz>.28**2:continue
     point=center+Vector((dx,-.08,dz));hit,loc,normal,index,obj,matrix=bpy.context.scene.ray_cast(dep,point-direction*30,direction,distance=32);total+=1
     if hit and obj.name.startswith(('LEAF_CLUSTER','BRANCH_')):blocked+=1
   counts[lamp]={'tree_blocked_samples':blocked,'samples':total}
  checks.append({'check':c+' model branch partly hides left / red remains clear','samples':counts,'status':'PASS' if counts['GREEN_OFF']['tree_blocked_samples']>0 and counts['RED_ON']['tree_blocked_samples']==0 else 'FAIL'})
for c in edges:
 err=max(abs(a-b) for k in ids for a,b in zip(edges['C01']['first']['positions'][k],edges[c]['first']['positions'][k]));checks.append({'check':c+' fixed world coordinates','error':err,'status':'PASS' if err<1e-5 else 'FAIL'})
for a,b in zip(list(edges),list(edges)[1:]):
 err=max(abs(x-y) for x,y in zip(edges[a]['last']['camera'],edges[b]['first']['camera']));checks.append({'check':a+'→'+b+' camera match','error':err,'status':'PASS' if err<1e-5 else 'FAIL'})
err=max(abs(x-y) for x,y in zip(edges['C01']['first']['camera'],edges['C08']['last']['camera']));checks.append({'check':'C01↔C08 identity camera','error':err,'status':'PASS' if err<1e-5 else 'FAIL'})
result={'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'edges':edges,'hashes':{f'source/blender/{r["cut_id"]}.blend':hashlib.sha256((R/f'source/blender/{r["cut_id"]}.blend').read_bytes()).hexdigest() for r in rows}}
(R/'qc/scene.json').write_text(json.dumps(result,indent=2));assert result['status']=='PASS';print('SCENE PASS',len(checks))
