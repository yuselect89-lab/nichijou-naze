# Matching-camera photographic passes make the street/model dissolve editable.
import bpy,json,shutil,subprocess,sys,argparse
from pathlib import Path
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--cut');args=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
for c in ([args.cut] if args.cut in ['C06','C07','C08'] else [] if args.cut else ['C06','C07','C08']):
 bpy.ops.wm.open_mainfile(filepath=str(R/'source/blender'/(c+'.blend')));s=bpy.context.scene;s.render.threads_mode='FIXED';s.render.threads=4
 # Freeze visibility/material overrides while preserving animated camera.
 for key in ['MODEL_ROAD','TREE_MASTER']:
  for obj in bpy.data.collections[key].objects:obj.animation_data_clear();obj.hide_render=True
 bpy.data.objects['STREET_MASTER'].animation_data_clear()
 bpy.data.objects['STREET_MASTER'].data.materials[0].node_tree.animation_data_clear()
 for ma in bpy.data.materials:
  if '_photo_style' in ma.name:ma.node_tree.animation_data_clear()
 anchors=json.loads((R/'source'/f'{c}_anchors.json').read_text());dest=R/'source/frames'/('BLEND_'+c);dest.mkdir(parents=True,exist_ok=True);ref=R/'source/frames'/('PHOTO_'+c);ref.mkdir(exist_ok=True)
 for i,a in enumerate(anchors):
  native=R/'source/frames'/c/f'{i:04}.png';out=dest/f'{i:04}.png';mode=a['mode']
  if not 0<mode<1:shutil.copy2(native,out);continue
  photo=ref/f'{i:04}.png'
  if not photo.exists():
   s.frame_set(i+1)
   for key in ['MODEL_ROAD','TREE_MASTER']:
    for o in bpy.data.collections[key].objects:o.hide_render=True
   o=bpy.data.objects['STREET_MASTER'];o.hide_render=False
   for node in o.data.materials[0].node_tree.nodes:
    if node.type=='MIX_SHADER':node.inputs[0].default_value=1
   for ma in bpy.data.materials:
    if '_photo_style' in ma.name:
     for node in ma.node_tree.nodes:
      if node.type=='MIX_SHADER':node.inputs[0].default_value=0
   bpy.context.view_layer.update();s.render.filepath=str(photo);bpy.ops.render.render(write_still=True)
 print('DISSOLVE',c,flush=True)

subprocess.run(["python3",str(R/"source/blend_passes.py")]+(["--cut",args.cut] if args.cut else []),check=True)
