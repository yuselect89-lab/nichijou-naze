from pathlib import Path
import subprocess,time,sys,json,hashlib
R=Path(__file__).resolve().parents[1];repo=R.parents[3]
while not (R/'qc/compose.log').exists() or 'ALL_COMPOSED' not in (R/'qc/compose.log').read_text():time.sleep(2)
def run(args,name,cwd=None):
 with (R/'qc'/name).open('w') as f:subprocess.run(args,cwd=cwd or repo,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('COMPLETE',name,flush=True)
run(['node',str(R/'tools/verify-production.mjs')],'lock-final.log',R)
run(['blender','-b','-t','4','--python',str(R/'source/photo_pass.py')],'dissolve.log')
for c in ['C06','C07','C08']:run([sys.executable,str(R/'source/compose.py'),'--cut',c],f'compose-{c}-final.log')
run(['blender','-b','-t','2','--python',str(R/'source/unpack_shared_textures.py')],'textures.log')
run(['blender','-b','-t','2','--python',str(R/'source/verify_scene.py')],'scene.log')
run([sys.executable,str(R/'source/check_media.py')],'media.log')
run(['node',str(R/'source/playback.mjs')],'playback.log')
for r in json.loads((R/'source/timing.json').read_text()):
 c=r['cut_id'];run(['node',str(repo/'tools/media-evidence.mjs'),str(R/'cuts'/c),'--out',str(R/'qc/evidence'/c),'--limit','6'],f'evidence-{c}.log')
protected=json.loads((R/'qc/protected.json').read_text());assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in protected.items())
(R/'qc/protected-final.json').write_text(json.dumps({'status':'PASS','hashes':protected},indent=2))
print('ALL_CHECKS_COMPLETE',flush=True)
