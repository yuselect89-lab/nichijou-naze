import bpy,math,json,sys,argparse,random,shutil
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--cut');p.add_argument('--still',type=int);p.add_argument('--samples',type=int,default=8);a=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
T=json.loads((R/'source/timing.json').read_text());N={r['cut_id']:r['frames'] for r in T}
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=a.samples;s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100;s.render.fps=30;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.compression=15;s.render.threads_mode='FIXED';s.render.threads=4;s.view_settings.view_transform='Standard';s.view_settings.look='None';s.render.film_transparent=False
s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.87,.90,.94,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.65
C={}
for name in ['SIGNAL_MASTER','TREE_MASTER','MODEL_ROAD','STREET_MASTER','LIGHTS']:
 c=bpy.data.collections.new(name);s.collection.children.link(c);C[name]=c
CUR='SIGNAL_MASTER'
def put(o):
 for c in list(o.users_collection):c.objects.unlink(o)
 C[CUR].objects.link(o);return o
def color(h):
 def f(v):return v/12.92 if v<.04045 else ((v+.055)/1.055)**2.4
 return tuple(f(int(h[i:i+2],16)/255) for i in (0,2,4))+(1,)
def mat(name,h,metal=0,rough=.5,emit=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;m.diffuse_color=color(h);n=m.node_tree.nodes['Principled BSDF'];n.inputs['Base Color'].default_value=color(h);n.inputs['Metallic'].default_value=metal;n.inputs['Roughness'].default_value=rough;n.inputs['Emission Color'].default_value=color(h);n.inputs['Emission Strength'].default_value=emit;return m
silver=mat('Weathered galvanized aluminum','a4afb1',.6,.35);black=mat('Black lens surround','172127',.15,.36);hood=mat('Dark gray hood interior','344348',.35,.38);red=mat('RED ACTIVE only','eb1b12',.1,.27,1.5);green=mat('GREEN OFF tinted glass','15473c',.15,.33);yellow=mat('AMBER OFF tinted glass','665126',.15,.33);white=mat('Warm model white','e6e8e5');road=mat('Model road gray','b5bdc3');ink=mat('Window charcoal','35434b');treeM=mat('Matte muted foliage','8faaa0');bark=mat('Tree bark','766c5c')
def box(name,loc,dim,m,b=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=put(bpy.context.object);o.name=name;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if b:q=o.modifiers.new('Rounded manufactured edge','BEVEL');q.width=b;q.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return o
def cyl(name,loc,r,d,m,rot=(0,0,0),verts=48):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=r,depth=d,location=loc,rotation=rot);o=put(bpy.context.object);o.name=name;o.data.materials.append(m)
 for f in o.data.polygons:f.use_smooth=True
 return o
def tube(name,pts,r,m):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.bevel_depth=r;cu.bevel_resolution=3;sp=cu.splines.new('POLY');sp.points.add(len(pts)-1)
 for q,xyz in zip(sp.points,pts):q.co=(*xyz,1)
 o=bpy.data.objects.new(name,cu);C[CUR].objects.link(o);o.data.materials.append(m);return o
def sphere(name,loc,scale,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=6,radius=1,location=loc);o=put(bpy.context.object);o.name=name;o.scale=scale;o.data.materials.append(m)
 for f in o.data.polygons:f.use_smooth=True
 return o
# Signal face toward approaching driver at y<0. All heads remain fixed.
H=-1.5;Z=5.2
box('SIGNAL_HOUSING',(H,0,Z),(2.7,.4,.80),silver,.10)
for i,(name,m) in enumerate([('GREEN_OFF',green),('AMBER_OFF',yellow),('RED_ON',red)]):
 x=H+(i-1)*.84
 cyl(name+'_RIM',(x,-.235,Z),.355,.085,black,(math.pi/2,0,0))
 cyl(name,(x,-.29,Z),.300,.035,m,(math.pi/2,0,0))
 # Lens concentric Fresnel rings are geometry, not flat colored disks.
 for j in range(1,7):
  bpy.ops.mesh.primitive_torus_add(major_segments=48,minor_segments=6,location=(x,-.316,Z),rotation=(math.pi/2,0,0),major_radius=j*.041,minor_radius=.004);o=put(bpy.context.object);o.name=name+'_FRESNEL';o.data.materials.append(m)
 vs=[];fs=[]
 for y in [-.21,-.80]:
  for k in range(33):th=-.10*math.pi+k*1.20*math.pi/32;vs.append((x+.36*math.cos(th),y,Z+.36*math.sin(th)))
 for k in range(32):fs.append((k,k+1,k+34,k+33))
 me=bpy.data.meshes.new(name+'_HOOD');me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name+'_HOOD',me);C[CUR].objects.link(o);o.data.materials.append(hood);md=o.modifiers.new('Hood thickness','SOLIDIFY');md.thickness=.018
 for xx in [-.33,.33]:
  for zz in [-.33,.33]:cyl(name+'_BOLT',(x+xx,-.215,Z+zz),.017,.016,silver,(math.pi/2,0,0),12)
cyl('LEFT_SIGNAL_POST',(-4.5,.2,2.85),.075,5.7,silver)
tube('SUPPORT_ARM',[(-4.5,.2,5.65),(-4.5,.2,5.9),(-.1,.2,5.9)],.065,silver)
for x in [H-.85,H+.85]:tube('HEAD_BRACKET',[(x,.18,5.9),(x,.18,5.2)],.036,silver)
# Shared street model coordinates: driver lane x<0; right/central red closer x=0.
CUR='MODEL_ROAD'
box('ROAD_BASE',(-.5,1,-.22),(10,15,.35),white,.12);box('LEFT_LANE',(-2,1,0),(4,14,.05),road);box('OPPOSING_LANE',(2,1,0),(4,14,.05),road)
for x in [-4.3,4.3]:box('SIDEWALK',(x,1,.12),(.6,14,.22),white)
box('CENTER_LINE',(0,1,.045),(.07,14,.01),mat('Muted center marker','cfb67c'))
box('STOP_LINE',(-2,-.8,.05),(3.7,.20,.015),white)
for i in range(7):box('CROSSWALK_'+str(i),(-3.6+i*1.15,.9,.05),(.62,1.7,.02),white)
for idx,yy in enumerate([-3.2,-5.8]):
 car=box('STOPPED_CAR_'+str(idx),(-2,yy,.58),(1.5,2.2,.75),white,.18)
 box('CAR_CABIN_'+str(idx),(-2,yy+.1,1.08),(1.25,1.35,.65),white,.17)
 box('CAR_REAR_WINDOW_'+str(idx),(-2,yy-.59,1.1),(1.08,.03,.40),ink,.06)
 for x in [-2.72,-1.28]:
  for y in [yy-.7,yy+.7]:cyl('STATIC_WHEEL',(x,y,.34),.27,.16,ink,(0,math.pi/2,0),24)
# Ground shadows on a large pale surface, avoiding a small floating toy island.
box('STUDIO_GROUND',(0,0,-.46),(200,200,.08),mat('Studio near white','f1f3f4'),0)
CUR='TREE_MASTER'
cyl('TREE_TRUNK',(-5,-.2,2.8),.20,5.6,bark)
branchRoot=bpy.data.objects.new('BRANCH_GROWTH_ROOT',None);C[CUR].objects.link(branchRoot);branchRoot.location=(-4.8,-.9,5.25)
random.seed(22)
# Actual branch elongation is confined to hypothetical model only.
branches=[]
for j in range(7):
 end=(2.0+random.random()*.25,random.uniform(-.12,.12),random.uniform(-.25,.28));o=tube('BRANCH_'+str(j),[(0,0,0),(.8,0,.12),end],.026,bark);o.parent=branchRoot;branches.append(o)
 for k in range(6):
  u=(k+1)/6;loc=(end[0]*u+random.uniform(-.12,.12),end[1]+random.uniform(-.15,.15),end[2]*u+random.uniform(-.13,.13));vs=[];fs=[]
  for n in range(9):
   angle=n*2.399;cx=loc[0]+.15*math.cos(angle);cy=loc[1]+.08*math.sin(angle);cz=loc[2]+.06*math.sin(angle*2);dx=.14*math.cos(angle);dz=.14*math.sin(angle)
   j0=len(vs);vs.extend([(cx-dx,cy,cz-dz),(cx-dz*.45,cy-.025,cz+dx*.45),(cx+dx,cy,cz+dz),(cx+dz*.45,cy+.025,cz-dx*.45)]);fs.extend([(j0,j0+1,j0+2),(j0,j0+2,j0+3)])
  me=bpy.data.meshes.new('Leaves');me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new('LEAF_CLUSTER',me);C[CUR].objects.link(o);o.data.materials.append(treeM);o.parent=branchRoot;branches.append(o)
# Photographic background on a fixed projected plane, not a substitute signal.
CUR='STREET_MASTER'
im=bpy.data.images.load(str(R/'assets/STREET_AI.png'));im.pack();m=bpy.data.materials.new('AI street plate');m.use_nodes=True;m.surface_render_method='BLENDED';nt=m.node_tree;nt.nodes.clear();tex=nt.nodes.new('ShaderNodeTexImage');tex.image=im;em=nt.nodes.new('ShaderNodeEmission');nt.links.new(tex.outputs['Color'],em.inputs[0]);tr=nt.nodes.new('ShaderNodeBsdfTransparent');mx=nt.nodes.new('ShaderNodeMixShader');nt.links.new(tr.outputs[0],mx.inputs[1]);nt.links.new(em.outputs[0],mx.inputs[2]);out=nt.nodes.new('ShaderNodeOutputMaterial');nt.links.new(mx.outputs[0],out.inputs[0]);photo_alpha=mx.inputs[0]
uvn=nt.nodes.new('ShaderNodeTexCoord');sep=nt.nodes.new('ShaderNodeSeparateXYZ');nt.links.new(uvn.outputs['UV'],sep.inputs[0]);rx=nt.nodes.new('ShaderNodeMapRange');rx.inputs['From Min'].default_value=.55;rx.inputs['From Max'].default_value=.10;nt.links.new(sep.outputs['X'],rx.inputs['Value']);ry=nt.nodes.new('ShaderNodeMapRange');ry.inputs['From Min'].default_value=.52;ry.inputs['From Max'].default_value=.9;nt.links.new(sep.outputs['Y'],ry.inputs['Value']);mul=nt.nodes.new('ShaderNodeMath');mul.operation='MULTIPLY';nt.links.new(rx.outputs[0],mul.inputs[0]);nt.links.new(ry.outputs[0],mul.inputs[1]);wind=nt.nodes.new('ShaderNodeMath');wind.operation='MULTIPLY';nt.links.new(mul.outputs[0],wind.inputs[0]);wind_value=wind.inputs[1];v=nt.nodes.new('ShaderNodeCombineXYZ');nt.links.new(wind.outputs[0],v.inputs['X']);add=nt.nodes.new('ShaderNodeVectorMath');add.operation='ADD';nt.links.new(uvn.outputs['UV'],add.inputs[0]);nt.links.new(v.outputs[0],add.inputs[1]);nt.links.new(add.outputs[0],tex.inputs['Vector'])
verts=[(-1.5-14*9/32,9,3.5-7),(-1.5+14*9/32,9,3.5-7),(-1.5+14*9/32,9,3.5+7),(-1.5-14*9/32,9,3.5+7)]
me=bpy.data.meshes.new('PHOTO');me.from_pydata(verts,[],[(0,1,2,3)]);me.update();uv=me.uv_layers.new()
for li,co in zip(me.polygons[0].loop_indices,[(0,0),(1,0),(1,1),(0,1)]):uv.data[li].uv=co
photo=bpy.data.objects.new('STREET_MASTER',me);C[CUR].objects.link(photo);photo.data.materials.append(m)
CUR='LIGHTS'
for name,loc,power,size in [('Sun softbox',(-6,-8,12),1300,7),('Sky fill',(5,-4,9),650,8)]:
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size;d.use_shadow_jitter=False;o=bpy.data.objects.new(name,d);C[CUR].objects.link(o);o.location=loc;o.rotation_euler=(Vector((-1,0,4))-o.location).to_track_quat('-Z','Y').to_euler()
camd=bpy.data.cameras.new('CAMERA');cam=bpy.data.objects.new('CAMERA',camd);s.collection.objects.link(cam);s.camera=cam;camd.type='ORTHO'
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def lerp(a,b,u):return tuple(x+(y-x)*u for x,y in zip(a,b))
P0=(-1.5,-15,5.5,8.2,-1.5,0,5.5);PW=(-1.5,-15,3.5,14,-1.5,0,3.5);PM=(4,-13,9,12,-1.6,0,2.6)
def pose(c,t):
 mode=0;grow=.65
 if c=='C01':q=lerp(P0,(-1.47,-15,5.46,8,-1.5,0,5.46),ease(t))
 elif c=='C02':q=lerp((-1.47,-15,5.46,8,-1.5,0,5.46),P0,ease(t))
 elif c=='C03':q=lerp(P0,(-1.4,-15,5.4,7.8,-1.4,0,5.4),math.sin(math.pi*t)**2)
 elif c=='C04':q=lerp(P0,PW,ease(t))
 elif c=='C05':q=PW
 elif c=='C06':
  mode=ease(t/.35);q=lerp(PW,PM,ease((t-.2)/.8));grow=.65+.35*ease((t-.35)/.65)
 elif c=='C07':
  # A brief return to the same real street, then the same fixed model.
  mode=1-ease((t-.32)/.07)*(1-ease((t-.52)/.07));q=lerp(PM,PW,1-mode);grow=1
 elif c=='C08':mode=1-ease(t/.24);q=lerp(PM,P0,ease(t/.24));grow=1-.35*ease(t/.24)
 return q,mode,grow
STYLE=[]
edges={}
def setstate(c,t):
 q,mode,grow=pose(c,t)
 wind_value.default_value=.0018*math.sin((list(N).index(c)+t)*math.pi*2)
 for f in STYLE:f.default_value=mode
 cam.location=q[:3];cam.rotation_euler=(Vector(q[4:7])-cam.location).to_track_quat('-Z','Y').to_euler();camd.ortho_scale=q[3];photo_alpha.default_value=1-mode;photo.hide_render=mode>=.999
 for o in C['MODEL_ROAD'].objects:o.hide_render=mode<.001
 for o in C['TREE_MASTER'].objects:o.hide_render=mode<.001
 branchRoot.rotation_euler.y=(-.18*ease((t-.4)/.6) if c=='C06' else -.18 if c=='C07' else -.18*(1-ease(t/.24)) if c=='C08' else 0)
 branchRoot.scale=(grow,1,1);branchRoot.rotation_euler.z=.012*math.sin(t*math.pi*2) if c=='C05' else 0
 # Driver-eye branches extend over green only: x end never reaches red.
 bpy.context.view_layer.update()
def project(o):
 from bpy_extras.object_utils import world_to_camera_view
 v=world_to_camera_view(s,cam,o.matrix_world.translation);return [v.x*1080,(1-v.y)*1920]
# Registered AI photographic surface maps on actual separate signal meshes.
setstate('C01',0)
from bpy_extras.object_utils import world_to_camera_view
surface=bpy.data.images.load(str(R/'assets/SIGNAL_PHOTO_SURFACE.png'));surface.pack();styled={}
for obj in C['SIGNAL_MASTER'].objects:
 if obj.type!='MESH' or obj.name=='LEFT_SIGNAL_POST':continue
 uv=obj.data.uv_layers.active or obj.data.uv_layers.new(name='Photographic registered UV')
 for poly in obj.data.polygons:
  for li in poly.loop_indices:
   pt=world_to_camera_view(s,cam,obj.matrix_world@obj.data.vertices[obj.data.loops[li].vertex_index].co);uv.data[li].uv=(pt.x,pt.y)
 original=obj.data.materials[0]
 if original.name not in styled:
  ma=original.copy();ma.name=original.name+'_photo_style';nt=ma.node_tree;out=nt.nodes.get('Material Output');old=out.inputs[0].links[0].from_socket;tx=nt.nodes.new('ShaderNodeTexImage');tx.image=surface;tx.extension='EXTEND';e=nt.nodes.new('ShaderNodeEmission');nt.links.new(tx.outputs['Color'],e.inputs[0]);mix=nt.nodes.new('ShaderNodeMixShader');nt.links.new(e.outputs[0],mix.inputs[1]);nt.links.new(old,mix.inputs[2]);nt.links.new(mix.outputs[0],out.inputs[0]);STYLE.append(mix.inputs[0]);styled[original.name]=ma
 obj.data.materials.clear();obj.data.materials.append(styled[original.name])
# Bright camera background for the explanatory model, independent of lighting.
wn=s.world.node_tree;old=wn.nodes['Background'];lp=wn.nodes.new('ShaderNodeLightPath');bg=wn.nodes.new('ShaderNodeBackground');bg.inputs[0].default_value=(.97,.98,.99,1);bg.inputs[1].default_value=1;mx=wn.nodes.new('ShaderNodeMixShader');wn.links.new(lp.outputs['Is Camera Ray'],mx.inputs[0]);wn.links.new(old.outputs[0],mx.inputs[1]);wn.links.new(bg.outputs[0],mx.inputs[2]);wn.links.new(mx.outputs[0],wn.nodes['World Output'].inputs[0])
for c in ([a.cut] if a.cut else list(N)):
 n=N[c];s.frame_start=1;s.frame_end=n
 for o in [cam,photo,branchRoot]+list(C['MODEL_ROAD'].objects)+list(C['TREE_MASTER'].objects):o.animation_data_clear()
 camd.animation_data_clear();m.node_tree.animation_data_clear();anchors=[]
 for f in STYLE:f.id_data.animation_data_clear()
 for i in range(n):
  s.frame_set(i+1);setstate(c,i/(n-1));cam.keyframe_insert('location',frame=i+1);cam.keyframe_insert('rotation_euler',frame=i+1);camd.keyframe_insert('ortho_scale',frame=i+1);photo_alpha.keyframe_insert('default_value',frame=i+1);wind_value.keyframe_insert('default_value',frame=i+1);photo.keyframe_insert('hide_render',frame=i+1)
  for f in STYLE:f.keyframe_insert('default_value',frame=i+1)
  for o in C['MODEL_ROAD'].objects:o.keyframe_insert('hide_render',frame=i+1)
  for o in C['TREE_MASTER'].objects:o.keyframe_insert('hide_render',frame=i+1)
  branchRoot.keyframe_insert('scale',frame=i+1);branchRoot.keyframe_insert('rotation_euler',frame=i+1)
  anchors.append({'red':project(bpy.data.objects['RED_ON']),'green':project(bpy.data.objects['GREEN_OFF']),'post':project(bpy.data.objects['LEFT_SIGNAL_POST']),'mode':pose(c,i/(n-1))[1]})
 dest=R/'source/frames'/c;dest.mkdir(parents=True,exist_ok=True);bl=R/'source/blender';bl.mkdir(exist_ok=True);setstate(c,0);s.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(bl/(c+'.blend')),compress=True)
 (R/'source'/f'{c}_anchors.json').write_text(json.dumps(anchors))
 hold_cache={}
 for i in ([a.still] if a.still is not None else range(n)):
  f=dest/f'{i:04}.png'
  hold_key='C07_MODEL' if c=='C07' and pose(c,i/(n-1))[1]==1.0 else None
  if f.exists() and a.still is None:
   if hold_key:hold_cache[hold_key]=f
   continue
  if hold_key in hold_cache:
   shutil.copy2(hold_cache[hold_key],f);continue
  s.frame_set(i+1);setstate(c,i/(n-1));s.render.filepath=str(f);bpy.ops.render.render(write_still=True)
  if hold_key:hold_cache[hold_key]=f
