import bpy,json
from pathlib import Path
from bpy_extras.object_utils import world_to_camera_view
R=Path(__file__).resolve().parents[1];meta={}
for r in json.loads((R/'source/timing.json').read_text()):
 c=r['cut_id'];bpy.ops.wm.open_mainfile(filepath=str(R/'source/blender'/f'{c}.blend'));s=bpy.context.scene;o=bpy.data.objects['KITCHEN_MASTER'];uv=o.data.uv_layers.active;points=[]
 for i in range(r['frames']):
  s.frame_set(i+1);bpy.context.view_layer.update();pairs=[]
  for li in o.data.polygons[0].loop_indices:
   p=world_to_camera_view(s,s.camera,o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co);u,v=uv.data[li].uv;pairs.append([[p.x*1080,(1-p.y)*1920],[u,1-v]])
  points.append(pairs)
 meta[c]=points
(R/'source/background_coords.json').write_text(json.dumps(meta))
