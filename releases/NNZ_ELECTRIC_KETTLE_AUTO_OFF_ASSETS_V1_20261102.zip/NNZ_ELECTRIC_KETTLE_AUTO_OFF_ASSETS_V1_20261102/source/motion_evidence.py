from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json,hashlib
R=Path(__file__).resolve().parents[1];Q=R/'qc';font=ImageFont.truetype(str(R/'public/series/v1/NotoSansCJKjp-Bold.otf'),19);records=[]
for c,frames in [('C01',[35,48,52,65]),('C06',[155,168,169,170,171,185]),('C07',[0,3,6,8,12,36])]:
 sheet=Image.new('RGB',(360*len(frames),670),'#edf1f3');d=ImageDraw.Draw(sheet)
 for j,f in enumerate(frames):
  p=Q/'frames'/f'{c}-action-{f}.jpg';subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'cuts'/c/'asset.mp4'),'-vf',f'select=eq(n\\,{f}),scale=360:640','-frames:v','1',str(p)],check=True);sheet.paste(Image.open(p),(j*360,30));d.text((j*360+5,4),f'{c} / {f}f / {f/30:.3f}s',font=font,fill='#273b44')
 sheet.save(Q/f'{c}-action.jpg',quality=95);records.append({'cut':c,'source_sha256':hashlib.sha256((R/'cuts'/c/'asset.mp4').read_bytes()).hexdigest(),'frames':frames,'evidence':f'qc/{c}-action.jpg'})
# Replace earlier internal diagnostic copies with evidence from the final video.
for f in [35,48,52,65]:
 p=Q/f'C01-action-{f}.jpg';p.write_bytes((Q/'frames'/f'C01-action-{f}.jpg').read_bytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'cuts/C02/asset.mp4'),'-vf','select=eq(n\\,70)','-frames:v','1',str(Q/'C02-face.jpg')],check=True)
(Q/'motion-evidence.json').write_text(json.dumps({'status':'EVIDENCE_ONLY_NOT_QC_PASS','records':records},indent=2))
for c,frames,box in [('C06',[168,169,170,171,185],(250,850,700,500)),('C07',[0,3,6,8,12,36],(100,550,880,550))]:
 sheet=Image.new('RGB',(420*len(frames),330),'#edf1f3');d=ImageDraw.Draw(sheet);x,y,w,h=box
 for j,f in enumerate(frames):
  p=Q/'frames'/f'{c}-detail-{f}.jpg';vf=f'select=eq(n\\,{f}),crop={w}:{h}:{x}:{y},scale=420:300';subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'cuts'/c/'asset.mp4'),'-vf',vf,'-frames:v','1',str(p)],check=True);sheet.paste(Image.open(p),(j*420,30));d.text((j*420+4,3),f'{c} {f}f',font=font,fill='#273b44')
 sheet.save(Q/f'{c}-detail.jpg',quality=95)
