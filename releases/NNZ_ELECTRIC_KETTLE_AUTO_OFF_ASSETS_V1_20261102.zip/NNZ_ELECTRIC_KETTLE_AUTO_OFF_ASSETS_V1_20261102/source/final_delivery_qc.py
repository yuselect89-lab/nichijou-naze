# Development repository orchestration. Standalone ZIP audits: verify_scene.py, check_media.py, playback.mjs (dependencies in source/package.json).
from pathlib import Path
import subprocess,time,hashlib,json
R=Path(__file__).resolve().parents[1];repo=R.parents[3]
def run(cmd,log,cwd=None):
 with (R/'qc'/log).open('w') as f:subprocess.run(cmd,cwd=cwd or R,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('COMPLETE',log,flush=True)
for c in ['C01','C02','C03','C04','C05','C08']:
 run(['python3',str(R/'source/compose.py'),'--cut',c,'--steam-only'],'compose-'+c+'-steam-final.log')
run(['python3',str(R/'source/check_media.py')],'media.log')
run(['python3',str(R/'source/motion_evidence.py')],'motion-evidence.log')
run(['node',str(R/'source/playback.mjs')],'playback.log',repo)
for c in ['C01','C02','C03','C04','C05','C08']:
 run(['node',str(repo/'tools/media-evidence.mjs'),str(R/'cuts'/c),'--out',str(R/'qc/evidence'/c)],'evidence-'+c+'.log',repo)
old=json.loads((R/'qc/protected.json').read_text());new={k:hashlib.sha256((repo/k).read_bytes()).hexdigest() for k in old};assert old==new;(R/'qc/protected-final.json').write_text(json.dumps({'status':'PASS','hashes':new},indent=2))
print('ALL_QC_COMPLETE_FINAL',flush=True)
