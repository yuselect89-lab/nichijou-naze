"""Photographic background completion with exact animated 3D subject mattes.
Preserves the rendered kettle/lever pixels. Extends the SAME kitchen through its
camera projection, avoiding viewport texture-boundary artifacts. Adds a soft
contact shadow; no generated objects or scientific geometry are changed.
Run in Blender after render.py and before compose.py.
"""
import bpy,json,math,sys,argparse
import numpy as np
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
R=Path(__file__).resolve().parents[1];T=json.loads((R/'source/timing.json').read_text());coords=json.loads((R/'source/background_coords.json').read_text());source=Image.open(R/'assets/KITCHEN_AI.png').convert('RGB');w,h=source.size;pad=max(w,h);extended=Image.fromarray(np.pad(np.asarray(source),((pad,pad),(pad,pad),(0,0)),mode='edge'));report={};ap=argparse.ArgumentParser();ap.add_argument('--cut');ap.add_argument('--still',type=int);args=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
for row in T:
 c=row['cut_id']
 if c in ['C06','C07'] or (args.cut and c!=args.cut):continue
 bpy.ops.wm.open_mainfile(filepath=str(R/'source/blender'/f'{c}.blend'));s=bpy.context.scene;anchors=json.loads((R/'source'/f'{c}_anchors.json').read_text());dep=bpy.context.evaluated_depsgraph_get();meshes=[]
 for ob in bpy.data.collections['KETTLE_BODY'].objects:
  if ob.type not in ['MESH','CURVE']:continue
  ev=ob.evaluated_get(dep);me=ev.to_mesh();vertices=np.array([[*v.co,1] for v in me.vertices],dtype=np.float64);faces=[list(p.vertices) for p in me.polygons];meshes.append((ob,vertices,faces));ev.to_mesh_clear()
 def project(vertices,mat):
  clip=vertices@mat.T;return np.stack(((clip[:,0]/clip[:,3]*.5+.5)*1080,(.5-clip[:,1]/clip[:,3]*.5)*1920),axis=1)
 count=0
 for i in ([args.still] if args.still is not None else range(row['frames'])):
  mode=anchors[i]['mode']
  if mode>.9999:continue
  s.frame_set(i+1);dep=bpy.context.evaluated_depsgraph_get();bpy.context.view_layer.update();proj=np.array(s.camera.calc_matrix_camera(dep,x=1080,y=1920));view=np.array(s.camera.matrix_world.inverted());mask=Image.new('L',(1080,1920),0);draw=ImageDraw.Draw(mask)
  for ob,vertices,faces in meshes:
   xy=project(vertices,proj@view@np.array(ob.matrix_world));points=[tuple(p) for p in xy]
   for face in faces:draw.polygon([points[j] for j in face],fill=255)
  mask=mask.filter(ImageFilter.MaxFilter(3)).filter(ImageFilter.GaussianBlur(.45))
  pose=coords[c][i];xy=np.array([[*x[0],1] for x in pose[:3]]);uv=np.array([[(.5+(x[1][0]-.5)/1.85)*w+pad,(.32+(x[1][1]-.32)/1.85)*h+pad] for x in pose[:3]]);co=np.linalg.solve(xy,uv);coeff=(co[0,0],co[1,0],co[2,0],co[0,1],co[1,1],co[2,1]);bg=extended.transform((1080,1920),Image.Transform.AFFINE,coeff,Image.Resampling.BICUBIC).convert('RGBA')
  # Soft near-contact shadow under the base, retained after power OFF.
  circle=np.array([[1.04*math.cos(k*math.tau/48)+.04,1.04*math.sin(k*math.tau/48)+.05,.012,1] for k in range(48)]);foot=project(circle,proj@view);shadow=Image.new('L',(1080,1920));ImageDraw.Draw(shadow).polygon([tuple(x) for x in foot],fill=48);shadow=shadow.filter(ImageFilter.GaussianBlur(15*6/anchors[i]['scale']));shade=Image.new('RGBA',(1080,1920),(25,20,15,0));shade.putalpha(shadow);bg.alpha_composite(shade)
  raw=R/'source/frames'/c/f'{i:04}.png';partial=.0001<mode<.9999;p=R/'source/frames'/('PASS_'+c)/f'{i:04}_0.png' if partial else raw;foreground=Image.open(p).convert('RGB');finished=Image.composite(foreground,bg.convert('RGB'),mask);finished.save(p,compress_level=2)
  if partial:Image.blend(finished,Image.open(p.with_name(f'{i:04}_1.png')).convert('RGB'),mode).save(raw,compress_level=2)
  count+=1
 report[c]=count;print('PHOTO FINISH',c,count,flush=True)
(R/'qc/photo-finish.json').write_text(json.dumps({'status':'COMPLETE','frames':report,'method':'Same kitchen affine projection with common uniform background scale 1.85 around image center (0.5,0.32), all corners within source image; animated 3D mesh mattes preserve foreground; soft contact shadow; no optical-flow interpolation'},indent=2))
