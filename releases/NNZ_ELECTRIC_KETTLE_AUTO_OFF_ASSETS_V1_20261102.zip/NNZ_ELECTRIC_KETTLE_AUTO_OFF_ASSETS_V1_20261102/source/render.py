"""Final raster pipeline: registered photographic exterior + Workbench studio cutaway.
Every output frame uses its actual 3D camera/lever/shape-key pose. No optical-flow
interpolation, no enlargement of low-resolution frame renders. The two looks
are rendered with the SAME camera and blended during the cutaway transitions.
"""
import bpy,sys,argparse,json,math,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--cut');ap.add_argument('--still',type=int);ap.add_argument('--aa',default='8');a=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
T=json.loads((R/'source/timing.json').read_text())
for row in T:
 c=row['cut_id']
 if a.cut and c!=a.cut:continue
 bpy.ops.wm.open_mainfile(filepath=str(R/'source/blender'/f'{c}.blend'));s=bpy.context.scene;s.render.engine='BLENDER_WORKBENCH';s.display.render_aa=a.aa;s.render.film_transparent=False;sh=s.display.shading;sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.curvature_ridge_factor=1.15;sh.curvature_valley_factor=1.0;sh.background_type='VIEWPORT';sh.background_color=(.93,.95,.96);sh.show_specular_highlight=True;sh.studio_light='outdoor.sl';sh.studiolight_intensity=1.5
 for ob in bpy.data.objects:
  if ob.animation_data and ob.animation_data.action:
   for fc in list(ob.animation_data.action.fcurves):
    if fc.data_path=='hide_render':ob.animation_data.action.fcurves.remove(fc)
 for o in bpy.data.collections['EXTERIOR_STEAM'].objects:o.hide_render=True;o.hide_set(True);o.animation_data_clear()
 body=bpy.data.objects['KETTLE_BODY'];uv=body.data.uv_layers.active;baseUV=[tuple(x.uv) for x in uv.data]
 # A physical rear half shell makes a real section cut instead of a flat drawing.
 me=body.data;vs=[tuple(v.co) for v in me.vertices];fs=[tuple(p.vertices) for p in me.polygons if sum(me.vertices[j].co.y for j in p.vertices)/len(p.vertices)>.03];sm=bpy.data.meshes.new('Rear half of same kettle wall');sm.from_pydata(vs,[],fs);sm.update();section=bpy.data.objects.new('SECTIONED_REAR_WALL',sm);s.collection.objects.link(section);section.matrix_world=body.matrix_world.copy();ma=bpy.data.materials.new('Section wall pale glass');ma.diffuse_color=(.69,.79,.81,1);section.data.materials.append(ma);sol=section.modifiers.new('Real wall thickness','SOLIDIFY');sol.thickness=.025
 for p in sm.polygons:p.use_smooth=True
 for po in bpy.data.objects['BOIL_ZONE'].data.polygons:po.use_smooth=True
 white=bpy.data.materials.new('Studio ground');white.diffuse_color=(.86,.88,.90,1)
 ground=bpy.data.objects['COUNTER_AND_STUDIO_GROUND'];groundmat=ground.data.materials[0];back=bpy.data.objects['KITCHEN_MASTER']
 # Extend the same background plate beyond the original field of view.
 for v in back.data.vertices:v.co.x*=4;v.co.y*=4
 for v in back.data.uv_layers.active.data:v.uv=((v.uv.x-.5)*4+.5,(v.uv.y-.5)*4+.5)
 # Open-front channel rails reveal the internal ribbons without opaque pipe walls.
 rails=[]
 for side in [-1,1]:
  base=bpy.data.objects['STEAM_CHANNEL'];ob=base.copy();ob.data=base.data.copy();ob.animation_data_clear();ob.data.animation_data_clear();s.collection.objects.link(ob);ob.name='STEAM_CHANNEL_SECTION_RAIL';ob.location.x+=side*.075;ob.data.bevel_depth=.012;rails.append(ob)
 def visibility(ob,hidden):ob.hide_render=hidden;ob.hide_set(hidden)
 def section_copy(ob):
  if ob.type!='MESH':return None
  me=ob.data;vs=[tuple(v.co) for v in me.vertices];fs=[tuple(p.vertices) for p in me.polygons if sum(me.vertices[j].co.y for j in p.vertices)/len(p.vertices)>.03]
  dm=bpy.data.meshes.new(ob.name+'_section');dm.from_pydata(vs,[],fs);dm.update();o=bpy.data.objects.new(ob.name+'_REAR_SECTION',dm);s.collection.objects.link(o);o.matrix_world=ob.matrix_world.copy();o.data.materials.append(ma);return o
 lids=[section_copy(bpy.data.objects[n]) for n in ['CLOSED_LID','UPPER_STEEL_BAND','HANDLE']]
 heat_material=bpy.data.objects['THERMAL_CHAMBER'].data.materials[0].copy();heat_material.name='THERMAL_CHAMBER_WARMING';bpy.data.objects['THERMAL_CHAMBER'].data.materials[0]=heat_material
 power_material=bpy.data.objects['HEATER_POWER_FEED'].data.materials[0].copy();power_material.name='POWER_FEED_ON_OFF';bpy.data.objects['HEATER_POWER_FEED'].data.materials[0]=power_material
 anchors=json.loads((R/'source'/f'{c}_anchors.json').read_text());dest=R/'source/frames'/c;dest.mkdir(parents=True,exist_ok=True)
 for i in ([a.still] if a.still is not None else range(row['frames'])):
  out=dest/f'{i:04}.png'
  if out.exists() and a.still is None:continue
  if c=='C07' and i>36 and (dest/'0036.png').exists():
   shutil.copyfile(dest/'0036.png',out);continue
  s.frame_set(i+1);an=anchors[i];mode=an['mode'];sec=i/30
  # Workbench reads UV coordinates directly. Motion is confined to the water texture,
  # preserving the registered outer silhouette, lid, handle and background.
  for item,(u,v) in zip(uv.data,baseUV):
   mask=max(0,min(1,(v-.28)/.03))*max(0,min(1,(.56-v)/.04));item.uv=(u+.0026*mask*math.sin(v*180+sec*13),v+.0015*mask*math.sin(u*90+sec*11))
  warmth=max(0,min(1,(sec-2.0)/3.6)) if c=='C06' else 1 if c in ['C07','C08'] else 0
  heat_material.diffuse_color=tuple(x+(y-x)*warmth for x,y in zip((.48,.57,.59,1),(.62,.51,.36,1)))
  power_material.diffuse_color=(.72,.36,.10,1) if an['on']>.5 else (.22,.25,.27,1)
  lm=bpy.data.materials.get('Amber power indicator');lm.diffuse_color=(1,.45,.08,1) if an['on']>.5 else (.10,.065,.035,1)
  def setup(model):
   s.world.color=(.93,.95,.96) if model else (.05,.05,.05);sh.light='STUDIO' if model else 'FLAT';sh.studiolight_rotate_z=.4;sh.color_type='MATERIAL' if model else 'TEXTURE';sh.show_shadows=bool(model);sh.show_cavity=bool(model);visibility(body,model);visibility(section,not model);visibility(back,model)
   ground.data.materials[0]=white if model else groundmat;ground.scale=(20,20,1) if model else (1,1,1)
   for name in ['HANDLE','DRY_SWITCH_HOUSING','CLOSED_LID','UPPER_STEEL_BAND','LID_SEAL','LID_BUTTON']:visibility(bpy.data.objects[name],model)
   for ob in lids:
    if ob:visibility(ob,not model)
   for ob in rails:visibility(ob,not model)
   for gr in ['STEAM_INLET','STEAM_CHANNEL','BIMETAL','ACTUATOR','CONTACTS']:
    for ob in bpy.data.collections[gr].objects:visibility(ob,not model)
   visibility(bpy.data.objects['STEAM_CHANNEL'],True)
   for ob in bpy.data.collections['BOIL_ZONE'].objects:visibility(ob,not model or c in ['C06','C07'])
   bpy.data.objects['HEATER_POWER_FEED'].hide_render=not model
   bpy.context.view_layer.update()
  if mode<.0001 or mode>.9999:
   setup(mode>.5);s.render.filepath=str(out);bpy.ops.render.render(write_still=True)
  else:
   from PIL import Image
   d=R/'source/frames'/('PASS_'+c);d.mkdir(exist_ok=True)
   paths=[]
   for model in [False,True]:
    setup(model);p=d/f'{i:04}_{int(model)}.png';s.render.filepath=str(p);bpy.ops.render.render(write_still=True);paths.append(p)
   Image.blend(Image.open(paths[0]).convert('RGB'),Image.open(paths[1]).convert('RGB'),mode).save(out,compress_level=2)
 print('RENDER COMPLETE',c,flush=True)
