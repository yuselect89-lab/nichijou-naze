import bpy,json,hashlib,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];rows=json.loads((R/'source/timing.json').read_text());checks=[];edges={};geometry={};mechanism_geometry={}
required=['KETTLE_BODY','BOIL_ZONE','STEAM_INLET','STEAM_CHANNEL','BIMETAL','ACTUATOR','CONTACTS','HEATER']
def check(name,ok,**extra):checks.append(dict(check=name,status='PASS' if ok else 'FAIL',**extra))
def edge(frame):
 s=bpy.context.scene;s.frame_set(frame);bpy.context.view_layer.update();cam=s.camera;hot=bpy.data.objects['BIMETAL'].data.shape_keys.key_blocks['HOT_INVERTED'].value;moving=bpy.data.objects['CONTACTS_MOVING'];fixed=bpy.data.objects['CONTACTS_FIXED'];a=moving.matrix_world.translation;b=fixed.matrix_world.translation
 return {'camera':[float(x) for row in cam.matrix_world for x in row]+[float(cam.data.ortho_scale)],'snap':hot,'lever':bpy.data.objects['EXTERIOR_LEVER_PIVOT'].rotation_euler.y,'pin_z':bpy.data.objects['ACTUATOR'].location.z,'blade':bpy.data.objects['CONTACT_SPRING_ROOT'].rotation_euler.y,'contact_gap':float(a.z-b.z-.035),'lamp_emission':bpy.data.materials['Amber power indicator'].node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value,'disc_origin':list(bpy.data.objects['BIMETAL'].location),'inlet_origin':list(bpy.data.objects['STEAM_INLET'].location),'flow_tips':[list(bpy.data.objects['STEAM_FLOW_ARROW_'+str(i)].matrix_world.translation) for i in range(4)],'feed_emission':bpy.data.objects['HEATER_POWER_FEED'].data.materials[0].node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value}
for r in rows:
 c=r['cut_id'];bpy.ops.wm.open_mainfile(filepath=str(R/'source/blender'/f'{c}.blend'));edges[c]={'first':edge(1),'last':edge(r['frames'])}
 mechanism_geometry[c]={'inlet':[list(p.co) for p in bpy.data.objects['STEAM_INLET'].data.splines[0].bezier_points],'channel':[list(p.co) for p in bpy.data.objects['STEAM_CHANNEL'].data.splines[0].bezier_points],'fixed_contact':list(bpy.data.objects['CONTACTS_FIXED'].location),'blade_pivot':list(bpy.data.objects['CONTACT_SPRING_ROOT'].location),'disc_support':list(bpy.data.objects['BIMETAL'].location),'heater':list(bpy.data.objects['HEATER'].location)}
 check(c+' all independent part collections',all(x in bpy.data.collections for x in required))
 images=[x for x in bpy.data.images if x.source=='FILE'];check(c+' portable relative image resources',all(x.filepath.startswith('//') and Path(bpy.path.abspath(x.filepath)).is_file() for x in images))
 obj=bpy.data.objects['KETTLE_BODY'];geometry[c]=hashlib.sha256(json.dumps([[round(v,6) for v in p.co] for p in obj.data.vertices]).encode()).hexdigest()
 check(c+' steam intake above waterline',2.25>max(v.co.z for v in bpy.data.objects['BOIL_ZONE'].data.vertices))
 check(c+' thermal chamber separated from dry contacts',.14-.08 > -.26+.065)
 check(c+' water volume unchanged by OFF',abs(bpy.data.objects['WATER_VOLUME'].location.z-.97)<1e-5)
 if c=='C01':
  values=[edge(i+1)['lever'] for i in range(r['frames'])];check('C01 lever moves continuously, not two-state fading',len(set(round(x,4) for x in values))>=6,distinct_positions=len(set(round(x,4) for x in values)))
  check('C01 power indicator ON to OFF',edges[c]['first']['lamp_emission']>1 and edges[c]['last']['lamp_emission']==0)
 if c=='C06':
  values=[edge(i+1)['snap'] for i in range(r['frames'])];inter=[i for i,x in enumerate(values) if .001<x<.999];check('C06 threshold snap in <= 4 source frames',values[0]==0 and values[-1]==1 and 0<len(inter)<=4,transition_frames=inter)
  check('C06 pushrod follows disc displacement',abs(edges[c]['last']['pin_z']-edges[c]['first']['pin_z']-.09)<1e-4)
 if c=='C07':
  check('C07 contacts closed before trip',abs(edges[c]['first']['contact_gap'])<1e-4,gap=edges[c]['first']['contact_gap'])
  sequence=[edge(i+1) for i in range(r['frames'])];check('C07 electrical feed OFF when contacts open',all(v['feed_emission']==0 for v in sequence if v['contact_gap']>1e-4))
  check('C07 mechanical trip opens contacts',edges[c]['last']['contact_gap']>.10 and edges[c]['last']['blade']<-.2,gap=edges[c]['last']['contact_gap'])
check('C05-C07 identical channel, supports, pivots and heater coordinates',mechanism_geometry['C05']==mechanism_geometry['C06']==mechanism_geometry['C07'])
for a,b in [('C06','C07'),('C07','C08')]:
 err=max(abs(x-y) for p,q in zip(edges[a]['last']['flow_tips'],edges[b]['first']['flow_tips']) for x,y in zip(p,q));check(a+' to '+b+' streamline phase continuity',err<1e-4,error=err)
check('Same kettle body geometry in all eight cuts',len(set(geometry.values()))==1)
for a,b in [('C04','C05'),('C05','C06'),('C06','C07'),('C07','C08')]:
 err=max(abs(x-y) for x,y in zip(edges[a]['last']['camera'],edges[b]['first']['camera']));check(a+' to '+b+' camera continuity',err<1e-4,error=err)
for a,b in [('C05','C06'),('C06','C07')]:check(a+' to '+b+' fixed disc support',edges[a]['last']['disc_origin']==edges[b]['first']['disc_origin'])
check('C06 to C07 continuous snap state',edges['C06']['last']['snap']==edges['C07']['first']['snap']==1)
check('C01 to C08 identical exterior camera',max(abs(x-y) for x,y in zip(edges['C01']['last']['camera'],edges['C08']['last']['camera']))<1e-5)
check('C01 to C08 identical OFF lever',abs(edges['C01']['last']['lever']-edges['C08']['last']['lever'])<1e-5)
result={'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','mechanism':'Representative steam-heated snap-action disc; illustrative geometry and exaggerated travel, not product CAD','checks':checks,'edges':edges,'body_geometry_hashes':geometry,'hashes':{f'source/blender/{r["cut_id"]}.blend':hashlib.sha256((R/f'source/blender/{r["cut_id"]}.blend').read_bytes()).hexdigest() for r in rows}}
(R/'qc/scene.json').write_text(json.dumps(result,indent=2));assert result['status']=='PASS',[x for x in checks if x['status']=='FAIL'];print('SCENE PASS',len(checks))
