from pathlib import Path
import json,hashlib,zipfile,csv,tempfile,subprocess
from datetime import datetime
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parents[1];repo=R.parents[3];name='NNZ_ELECTRIC_KETTLE_AUTO_OFF_ASSETS_V1_20261102';OUT=repo/'releases'/(name+'.zip')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
media=json.loads((R/'qc/media.json').read_text());scene=json.loads((R/'qc/scene.json').read_text());player=json.loads((R/'qc/playback-qc.json').read_text());visual=json.loads((R/'qc/visual-review.json').read_text());assert media['status']==scene['status']==player['status']=='PASS';assert visual['status']=='REVIEWED' and len(player['results'])==8
for r in media['videos']:assert sha(R/r['path'])==r['sha256']
for p,h in scene['hashes'].items():assert sha(R/p)==h
for r in player['results']:assert sha(R/'cuts'/r['cut']/'asset.mp4')==r['sha256']
rows=json.loads((R/'source/timing.json').read_text());shared=json.loads((R/'shared-manifest.json').read_text())['assets']
manifest={'project':'ELECTRIC_KETTLE_AUTO_OFF','version':'1.0.0','created_jst':datetime.now(ZoneInfo('Asia/Tokyo')).isoformat(timespec='seconds'),'state':'RENDERED_SELF_REVIEWED','voice_timing':'NOT_MEASURED_USE_VOICE_ANCHORS','g2_written_qc':'PASS','final_g3':'NOT_RUN','voice_modification':False,'assets':shared,'shared_files':{p:{'path':'assets/CHAR_'+p+'.png','asset_id':'NNZ_CHAR_FEMALE_01','version':'v03_expressions','sha256':sha(R/('assets/CHAR_'+p+'.png'))} for p in ['think','surprise','happy']},'masters':[{ 'id':'NNZ_KETTLE_'+x,'version':'1.0.0','source':'source/scene.py','collection':x,'rights':'Original AI-assisted scene; see PROVENANCE.md'} for x in ['KETTLE_BODY','BOIL_ZONE','STEAM_INLET','STEAM_CHANNEL','BIMETAL','ACTUATOR','CONTACTS','HEATER']],'mechanism':'Representative steam-heated snap-action bimetal disc; illustrative geometry, not product CAD','cuts':[dict(r,id='NNZ_KETTLE_'+r['cut_id'],version='1.0.0',files={k:f'cuts/{r["cut_id"]}/{v}' for k,v in {'composite':'asset.mp4','scene':'scene.mp4','text':'labels.webm','circles_arrows':'marks.webm','character':'character.webm','external_mist':'steam.webm'}.items()},source=f'source/blender/{r["cut_id"]}.blend') for r in rows],'handoff':'WORK_ASSEMBLY.md','qc':{'media':'qc/media.json','scene':'qc/scene.json','playback':'qc/playback-qc.json','visual':'qc/visual-review.json'}}
(R/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
files=sorted(p for p in R.rglob('*') if p.is_file() and not any(x in p.relative_to(R).parts for x in ['frames','__pycache__']) and not p.name.endswith(('.blend1','.pyc')) and p.name not in ['SHA256SUMS.txt','FILELIST.csv','asset-lock.json','repair_background.py','finish_qc.py'])
# Keep encoded-video evidence as high-quality JPEG; full-size diagnostic PNGs are reproducible and retained locally, not duplicated in ZIP.
files+=sorted(p for p in (R/'qc/frames').rglob('*') if p.is_file() and p.suffix.lower() != '.png')
files=sorted(set(files))
with (R/'FILELIST.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['path','bytes','sha256']);w.writerows((p.relative_to(R).as_posix(),p.stat().st_size,sha(p)) for p in files)
files.append(R/'FILELIST.csv');(R/'asset-lock.json').write_text(json.dumps({'version':'1.0.0','files':{p.relative_to(R).as_posix():sha(p) for p in files}},indent=2));files.append(R/'asset-lock.json')
(R/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(R).as_posix()+'\n' for p in files));files.append(R/'SHA256SUMS.txt');assert not OUT.exists();assert len(media['videos'])==48
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,name+'/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(OUT) as z,tempfile.TemporaryDirectory(prefix='kettle-zip-',dir='/tmp') as temp:
 assert z.testzip() is None
 for p in files:assert hashlib.sha256(z.read(name+'/'+p.relative_to(R).as_posix())).hexdigest()==sha(p)
 z.extractall(temp)
 extracted=Path(temp)/name
 subprocess.run(['blender','-b','-t','2','--python-exit-code','1','--python',str(extracted/'source/verify_scene.py')],check=True,capture_output=True)
 assert json.loads((extracted/'qc/scene.json').read_text())['status']=='PASS'
 count=0
 for r in media['videos']:
  p=Path(z.extract(name+'/'+r['path'],temp));cmd=['ffmpeg','-v','error','-threads','2']+(['-c:v','libvpx-vp9'] if p.suffix=='.webm' else [])+['-i',str(p),'-an','-f','null','-'];subprocess.run(cmd,check=True,capture_output=True);count+=1
proof={'status':'PASS','file':OUT.name,'bytes':OUT.stat().st_size,'sha256':sha(OUT),'entries':len(files),'reopened_zip_full_decode':count,'portable_blend_sources_loaded':8,'crc':'PASS','all_hashes':'PASS'}
OUT.with_suffix('.verification.json').write_text(json.dumps(proof,indent=2));OUT.with_suffix('.zip.sha256').write_text(proof['sha256']+'  '+OUT.name+'\n');print(json.dumps(proof,indent=2))
