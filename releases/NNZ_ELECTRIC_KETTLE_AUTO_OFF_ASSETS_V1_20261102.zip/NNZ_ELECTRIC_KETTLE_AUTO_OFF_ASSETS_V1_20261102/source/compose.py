from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageChops,ImageFilter
import json,math,subprocess,argparse,time
R=Path(__file__).resolve().parents[1];T=json.loads((R/'source/timing.json').read_text());N={r['cut_id']:r['frames'] for r in T};A={};cache={}
TEXT={'C01':('',''),'C02':('どうやって？',''),'C03':('水温を直接測らない','一般的なタイプ'),'C04':('秘密は蒸気',''),'C05':('蒸気の通り道','模式図'),'C06':('熱で変形','バイメタル'),'C07':('スイッチOFF','模式図：機械連動で接点が開く'),'C08':('蒸気が知らせる','')}
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def font(n,b):
 k=(n,b)
 if k not in cache:cache[k]=ImageFont.truetype(str(R/('public/series/v1/NotoSansCJKjp-Bold.otf' if b else 'assets/Regular.ttc')),n)
 return cache[k]
def word(d,xy,txt,n=62,b=True):
 f=font(n,b);w=d.textlength(txt,font=f);x,y=xy;d.rounded_rectangle((x-w/2-18,y-n*.65-12,x+w/2+18,y+n*.65+12),radius=12,fill='#fffffff0');d.text(xy,txt,font=f,anchor='mm',fill='#273b44')
SPR={p:Image.open(R/f'assets/CHAR_{p}.png').convert('RGBA').crop((260,0,1280,960)).resize((500,470),Image.Resampling.LANCZOS) for p in ['think','surprise','happy']}
for pic in SPR.values():
 mask=Image.new('L',pic.size,255)
 for y in range(395,470):
  for x in range(500):mask.putpixel((x,y),int(255*(469-y)/74))
 pic.putalpha(ImageChops.multiply(pic.getchannel('A'),mask))
def overlay(c,i,kind):
 t=i/(N[c]-1);sec=i/30;im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im);a=A[c][i];mode=a['mode']
 if kind=='steam':
  if mode>.999:return im
  unit=1920/a['scale'];height=int(unit*1.1);width=int(unit*.76);cloud=Image.new('RGBA',(width,height),(239,244,247,0));dd=ImageDraw.Draw(cloud);cx=width*.5
  # Advected thin curved wisps, not white internal smoke or water droplets.
  for k in range(15):
   pts=[]
   for j in range(40):
    v=j/39;xx=cx+(7+v*width*.16)*math.sin(v*9+sec*1.8+k*.9)+(k-7)*width*.018*v;yy=height*(1-v);pts.append((xx,yy))
   opacity=int((90+35*math.sin(k))*(1-mode)*(.65+.35*a['on']))
   dd.line(pts,fill=(239,244,247,max(0,opacity)),width=max(2,int(unit*.013)))
  cloud=cloud.filter(ImageFilter.GaussianBlur(max(1,unit*.013)));root=(a['steam'][0],a['steam'][1]+unit*.47*.96)
  im.alpha_composite(cloud,(round(root[0]-width*.5),round(root[1]-height)))
  return im
 if kind=='labels':
  primary,secondary=TEXT[c]
  if c=='C03' and sec<.7:primary='水温を直接測る？'
  if primary:word(d,(540,220),primary,62)
  if secondary:word(d,(540,330),secondary,34,False)
  if c=='C05' and mode>.8:
   word(d,(300,480),'上部の取入口',32,False);word(d,(760,1430),'スイッチ側へ',32,False)
  if c=='C06':
   word(d,(540,420),'跳躍型の模式図',30,False)
   if sec<2.1:status='加熱前'
   elif sec<5.60:status='蒸気の熱で加熱'
   elif sec<5.72:status='閾値で反転'
   else:status='反転後'
   word(d,(540,1405),status,38,False)
  if c=='C07':
   if sec<.10:status='バイメタル反転後'
   elif sec<.23:status='連動部が動く'
   elif sec<1.0:status='接点が開く'
   else:status='ヒーター通電OFF'
   word(d,(540,1405),status,38,False)
  return im
 if kind=='marks':
  gold=(202,157,66,225)
  def ring(pt,rad,alpha=1):
   x,y=pt;d.ellipse((x-rad,y-rad,x+rad,y+rad),outline=(*gold[:3],int(225*alpha)),width=4)
  if c=='C02':ring(a['lever'],85,math.sin(math.pi*t))
  if c=='C03' and .7<sec<1.8:
   # A hypothetical thermometer icon stays outside the real body; it is never an installed water probe.
   x,y=180,560;d.rounded_rectangle((x-12,y-90,x+12,y+35),radius=12,outline='#74858b',width=4);d.ellipse((x-25,y+18,x+25,y+68),outline='#74858b',width=4);d.line((130,470,230,650),fill='#986f59',width=5)
  if c=='C04':ring(a['steam'],110,math.sin(math.pi*t))
  if c=='C05' and mode>.9:ring(a['inlet'],48)
  if c=='C06' and sec>2:ring(a['disc'],175)
  if c=='C07' and sec<1.8:ring(a['contact'],95)
  if c=='C08' and sec>1.1:
   if sec<2.5:ring(a['steam'],105,math.sin(math.pi*(sec-1.1)/1.4))
   elif sec<4.5:ring(a['lever'],85,math.sin(math.pi*(sec-2.5)/2))
  return im
 if kind=='character':
  pose=None;alpha=0
  if c=='C02':pose='think';alpha=ease(sec/.35)
  if c=='C03':pose='surprise';alpha=1-ease((sec-.45)/.30)
  if c=='C08':pose='happy';alpha=ease((sec-1.3)/.5)
  if pose:
   p=SPR[pose].copy();p.putalpha(p.getchannel('A').point(lambda x:int(x*alpha)));im.alpha_composite(p,(30,980))
  return im
def layer(c,kind):
 p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgba','-s','1080x1920','-r','30','-i','-','-an','-c:v','libvpx-vp9','-pix_fmt','yuva420p','-b:v','0','-crf','20','-deadline','good','-cpu-used','5','-auto-alt-ref','0','-threads','2',str(R/'cuts'/c/(kind+'.webm'))],stdin=subprocess.PIPE)
 try:
  for i in range(N[c]):p.stdin.write(overlay(c,i,kind).tobytes())
 finally:p.stdin.close()
 assert p.wait()==0
def compose(c,steam_only=False):
 d=R/'cuts'/c;d.mkdir(parents=True,exist_ok=True);A[c]=json.loads((R/'source'/f'{c}_anchors.json').read_text())
 if not steam_only:
  subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-i',str(R/'source/frames'/c/'%04d.png'),'-frames:v',str(N[c]),'-an','-c:v','libx264','-crf','16','-preset','fast','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(d/'scene.mp4')],check=True)
  for k in ['steam','labels','marks','character']:layer(c,k)
 else:layer(c,'steam')
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(d/'scene.mp4'),'-c:v','libvpx-vp9','-i',str(d/'steam.webm'),'-c:v','libvpx-vp9','-i',str(d/'labels.webm'),'-c:v','libvpx-vp9','-i',str(d/'marks.webm'),'-c:v','libvpx-vp9','-i',str(d/'character.webm'),'-filter_complex','[0:v][1:v]overlay=format=auto[a];[a][2:v]overlay=format=auto[b];[b][3:v]overlay=format=auto[c];[c][4:v]overlay=format=auto,format=yuv420p[v]','-map','[v]','-r','30','-frames:v',str(N[c]),'-an','-c:v','libx264','-crf','16','-preset','fast','-threads','2','-movflags','+faststart',str(d/'asset.mp4')],check=True)
 print('COMPLETE',c,flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--cut');ap.add_argument('--wait',action='store_true');ap.add_argument('--start-cut');ap.add_argument('--steam-only',action='store_true');a=ap.parse_args()
 for c in ([a.cut] if a.cut else list(N)[list(N).index(a.start_cut):] if a.start_cut else list(N)):
  if a.wait:
   while True:
    try:
     for i in range(N[c]):
      with Image.open(R/'source/frames'/c/f'{i:04}.png') as im:im.load()
     break
    except (OSError,FileNotFoundError,SyntaxError):time.sleep(2)
  compose(c,a.steam_only)
