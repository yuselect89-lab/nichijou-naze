"""Original coherent kettle model. Blender 4.3.2; no proprietary CAD.
Representative steam-heated snap-disc trip, not a reconstruction of a named appliance.
Coordinates in illustrative units. No live disassembly is depicted.
"""
import bpy, math, json, sys, argparse, random
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--cut');ap.add_argument('--still',type=int);ap.add_argument('--prepare',action='store_true');ap.add_argument('--limit',type=int);ap.add_argument('--samples',type=int,default=4);args=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
T=json.loads((R/'source/timing.json').read_text());N={x['cut_id']:x['frames'] for x in T}
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=args.samples;s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100;s.render.fps=30;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.compression=12;s.render.threads_mode='FIXED';s.render.threads=4;s.view_settings.view_transform='Standard';s.view_settings.look='None';s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.75,.82,.90,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.55
C={}
for name in ['KETTLE_BODY','BOIL_ZONE','STEAM_INLET','STEAM_CHANNEL','BIMETAL','ACTUATOR','CONTACTS','HEATER','EXTERIOR_STEAM','ENVIRONMENT','LIGHTS']:
 c=bpy.data.collections.new(name);s.collection.children.link(c);C[name]=c
CUR='KETTLE_BODY'
def put(o):
 for c in list(o.users_collection):c.objects.unlink(o)
 C[CUR].objects.link(o);o['part_id']=CUR;o['version']='1.0.0';return o
def rgb(h):
 def f(v):return v/12.92 if v<.04045 else ((v+.055)/1.055)**2.4
 return tuple(f(int(h[k:k+2],16)/255) for k in [0,2,4])+(1,)
def mat(name,h,metal=0,rough=.45,alpha=1,emit=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;m.diffuse_color=rgb(h);p=m.node_tree.nodes['Principled BSDF'];p.inputs['Base Color'].default_value=rgb(h);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;p.inputs['Alpha'].default_value=alpha;p.inputs['Emission Color'].default_value=rgb(h);p.inputs['Emission Strength'].default_value=emit
 if alpha<1:m.surface_render_method='BLENDED';m.use_transparent_shadow=False
 return m
steel=mat('Brushed stainless steel','bbc2c3',.85,.23);dark=mat('Charcoal molded polymer','20272b',.05,.27);rubber=mat('Rubber seals','141b1c',0,.6);glass=mat('Borosilicate wall','b7d2dc',.12,.12,.14);water=mat('Hot water - remains hot after OFF','7fa9b8',.25,.16,.68);copper=mat('Copper electrical conductors','bd8963',.8,.28);ceramic=mat('Insulating ceramic','eee9d9',0,.3);blue=mat('Vapor streamline cyan','398a9b',.1,.32,.8,.12);channelM=mat('Dedicated vapor channel wall','a2b4b7',.2,.3,.25);bimetalM=mat('Bimetal two bonded metal layers','a9bac5',.85,.27);contactM=mat('Silver contact faces','e1e4df',.9,.18);warm=mat('Heat indication, not red-hot metal','c5a77a',.25,.5);lamp=mat('Amber power indicator','f5a341',.1,.16,1,1.8)
# Fine surface roughness: no logos or synthetic text on the appliance.
for m in []:
 nt=m.node_tree;noise=nt.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=180;noise.inputs['Roughness'].default_value=.75;b=nt.nodes.new('ShaderNodeBump');b.inputs['Strength'].default_value=.1;b.inputs['Distance'].default_value=.008;nt.links.new(noise.outputs['Fac'],b.inputs['Height']);nt.links.new(b.outputs['Normal'],nt.nodes['Principled BSDF'].inputs['Normal'])
def box(name,loc,dim,m,bevel=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=put(bpy.context.object);o.name=name;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if bevel:q=o.modifiers.new('Manufactured edge radius','BEVEL');q.width=bevel;q.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return o
def cyl(name,loc,r,depth,m,rot=(0,0,0),verts=64):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=r,depth=depth,location=loc,rotation=rot);o=put(bpy.context.object);o.name=name;o.data.materials.append(m)
 q=o.modifiers.new('Edge radius','BEVEL');q.width=min(.018,depth*.2);q.segments=2;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 for p in o.data.polygons:p.use_smooth=True
 return o
def tube(name,pts,r,m):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=12;cu.bevel_depth=r;cu.bevel_resolution=3;sp=cu.splines.new('BEZIER');sp.bezier_points.add(len(pts)-1)
 for p,xyz in zip(sp.bezier_points,pts):p.co=xyz;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,cu);C[CUR].objects.link(o);o.data.materials.append(m);o['part_id']=CUR;return o
def shell(name,zr,m,segments=96):
 vs=[(r*math.cos(a*math.tau/segments),r*math.sin(a*math.tau/segments),z) for z,r in zr for a in range(segments)];fs=[]
 for j in range(len(zr)-1):
  for a in range(segments):b=(a+1)%segments;fs.append((j*segments+a,j*segments+b,(j+1)*segments+b,(j+1)*segments+a))
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name,me);C[CUR].objects.link(o);o.data.materials.append(m);o['part_id']=CUR
 for p in me.polygons:p.use_smooth=True
 return o
body=shell('KETTLE_BODY',[(.35,.92),(.46,1.0),(2.28,.84),(2.40,.78)],glass)
cyl('POWER_BASE',(0,0,.14),1.03,.22,dark);cyl('LOWER_STEEL_BAND',(0,0,.39),.99,.23,steel);cyl('UPPER_STEEL_BAND',(0,0,2.34),.86,.15,steel);cyl('CLOSED_LID',(0,0,2.43),.80,.14,dark);cyl('LID_SEAL',(0,0,2.36),.80,.035,rubber);cyl('LID_BUTTON',(0,0,2.52),.22,.08,dark)
handleM=dark.copy();handleM.name='Handle cover becomes sectioned';handleM.surface_render_method='BLENDED'
tube('HANDLE',[(.75,.12,2.30),(1.35,.12,2.25),(1.72,.12,1.6),(1.62,.12,.68),(.91,.12,.48)],.135,handleM)
cover=box('DRY_SWITCH_HOUSING',(1.30,-.02,.70),(.86,.45,.65),handleM,.10)
# Spout stays fixed and open only at its lip; the lid never opens.
tube('SPOUT',[(-.73,0,2.16),(-1.0,0,2.18),(-1.26,0,2.42)],.19,steel)
cyl('SPOUT_DARK_APERTURE',(-1.26,0,2.44),.145,.015,rubber,(0,-.60,0))
tube('POWER_CORD',[(.6,.75,.15),(1.4,.9,.05),(2.1,1.4,.03),(2.7,2,.02)],.028,rubber)
leverRoot=bpy.data.objects.new('EXTERIOR_LEVER_PIVOT',None);C[CUR].objects.link(leverRoot);leverRoot.location=(1.45,-.12,.75)
lever=box('POWER_LEVER',(0,0,0),(.48,.30,.12),dark,.04);lever.parent=leverRoot;lever.location=(.23,-.08,0)
indicator=box('POWER_INDICATOR',(0,0,0),(.14,.025,.045),lamp,.015);indicator.parent=leverRoot;indicator.location=(.24,-.24,.012)
CUR='HEATER';heater=cyl('HEATER',(0,0,.50),.87,.05,steel);heater['mechanism']='Concealed heater below water; only illustrative power indication changes.'
feed=tube('HEATER_POWER_FEED',[(1.69,-.34,.87),(1.83,-.34,.74),(1.83,-.34,.28),(.74,-.34,.28)],.018,copper)
CUR='BOIL_ZONE';cyl('WATER_VOLUME',(0,0,.97),.86,.86,water)
vs=[(0,0,1.41)];faces=[]
for j in range(1,9):
 for a in range(48):vs.append((.85*j/8*math.cos(a*math.tau/48),.85*j/8*math.sin(a*math.tau/48),1.41))
for a in range(48):faces.append((0,1+a,1+(a+1)%48))
for j in range(7):
 for a in range(48):b=(a+1)%48;faces.append((1+j*48+a,1+j*48+b,1+(j+1)*48+b,1+(j+1)*48+a))
me=bpy.data.meshes.new('Boiling water surface');me.from_pydata(vs,[],faces);me.update();surface=bpy.data.objects.new('BOIL_ZONE',me);C[CUR].objects.link(surface);surface.data.materials.append(water)
surface.shape_key_add(name='Basis');wave=surface.shape_key_add(name='Wave');
for v in wave.data:v.co.z+=.014*math.sin(v.co.x*17+v.co.y*12)
random.seed(42);bubbles=[];bubbleM=mat('Small boiling bubbles','d7e6e8',.1,.15,.45)
for i in range(30):
 a=random.random()*math.tau;ra=.74*math.sqrt(random.random());bpy.ops.mesh.primitive_uv_sphere_add(segments=10,ring_count=6,radius=1,location=(ra*math.cos(a),ra*math.sin(a),.6));o=put(bpy.context.object);o.name='BOILING_BUBBLE_%02d'%i;o.data.materials.append(bubbleM);bubbles.append((o,random.random(),random.uniform(.014,.032)))
# Internal parts are always the same objects, with no teleportation between cuts.
CUR='STEAM_INLET';inlet=tube('STEAM_INLET',[(.61,.14,2.25),(.85,.14,2.25),(1.17,.14,2.16)],.095,channelM);inlet['above_waterline']=True
CUR='STEAM_CHANNEL';path=[(.64,.14,2.25),(.95,.14,2.24),(1.30,.14,2.08),(1.36,.14,1.68),(1.36,.14,.63),(1.30,.14,.48)]
channel=tube('STEAM_CHANNEL',path,.080,channelM)
# Vapor warms the underside of the disc in a separate thermal chamber. The electrical contacts are in front of an insulating wall, not inside the vapor route.
chamber=cyl('THERMAL_CHAMBER',(1.30,.04,.48),.28,.10,channelM)
CUR='BIMETAL';discCenter=Vector((1.30,.04,.565));dv=[(0,0,-.045)];df=[]
for j in range(1,7):
 for a in range(48):ra=.23*j/6;dv.append((ra*math.cos(a*math.tau/48),ra*math.sin(a*math.tau/48),-.045*(1-(ra/.23)**2)))
for a in range(48):df.append((0,1+a,1+(a+1)%48))
for j in range(5):
 for a in range(48):b=(a+1)%48;df.append((1+j*48+a,1+j*48+b,1+(j+1)*48+b,1+(j+1)*48+a))
dm=bpy.data.meshes.new('Bonded snap disc');dm.from_pydata(dv,[],df);dm.update();disc=bpy.data.objects.new('BIMETAL',dm);C[CUR].objects.link(disc);disc.location=discCenter;disc.data.materials.append(bimetalM);disc.data.materials.append(copper);sol=disc.modifiers.new('Two bonded layers, symbolic thickness','SOLIDIFY');sol.thickness=.012;sol.material_offset=1
disc.shape_key_add(name='COLD_DISHED');hot=disc.shape_key_add(name='HOT_INVERTED')
for v in hot.data:v.co.z=-v.co.z
disc['mechanism']='Steam-heated snap-action dished bimetal disc; rim-supported; threshold inversion. Simplified representative mechanism, displacements exaggerated.'
for a in [0,math.pi/2,math.pi,math.pi*1.5]:
 box('DISC_RIM_SUPPORT',(1.30+.24*math.cos(a),.04+.24*math.sin(a),.56),(.055,.055,.07),ceramic,.01)
CUR='ACTUATOR';pin=cyl('ACTUATOR',(1.30,.04,.68),.038,.32,ceramic);pin['purpose']='Thermal-to-mechanical transfer; electrically insulating pushrod.'
tube('INSULATING_SEPARATION',[(1.02,-.08,.45),(1.02,-.08,.84),(1.59,-.08,.84)],.025,ceramic)
rockerRoot=bpy.data.objects.new('ROCKER_PIVOT',None);C[CUR].objects.link(rockerRoot);rockerRoot.location=(1.02,-.12,.94)
rocker=box('TRIP_ROCKER',(0,0,0),(.54,.40,.045),ceramic,.015);rocker.parent=rockerRoot;rocker.location=(.26,0,0)
cyl('ROCKER_AXLE',(1.02,-.12,.94),.047,.22,steel,(math.pi/2,0,0))
CUR='CONTACTS';bladeRoot=bpy.data.objects.new('CONTACT_SPRING_ROOT',None);C[CUR].objects.link(bladeRoot);bladeRoot.location=(1.02,-.26,1.08)
blade=box('CONTACTS_MOVING_BLADE',(0,0,0),(.67,.12,.025),copper,.005);blade.parent=bladeRoot;blade.location=(.33,0,-.01)
moving=cyl('CONTACTS_MOVING',(0,0,0),.065,.035,contactM);moving.parent=bladeRoot;moving.location=(.61,0,-.045)
fixed=cyl('CONTACTS_FIXED',(1.63,-.26,1.00),.065,.035,contactM);fixed['dry_contact']=True
box('CONTACT_INSULATING_BASE',(1.63,-.26,.94),(.22,.25,.08),ceramic)
for x,z in [(1.02,1.08),(1.63,.94)]:cyl('CONTACT_MOUNT_SCREW',(x,-.26,z+.05),.026,.025,steel)
# Three finite translucent arrow ribbons show direction within the dedicated tube, never droplets in the contacts.
CUR='STEAM_CHANNEL';flows=[]
for i in range(4):
 cu=bpy.data.curves.new('Vapor streamline','CURVE');cu.dimensions='3D';cu.bevel_depth=.018;cu.bevel_resolution=2;sp=cu.splines.new('POLY');sp.points.add(9);o=bpy.data.objects.new('STEAM_FLOW_%d'%i,cu);C[CUR].objects.link(o);o.data.materials.append(blue)
 bpy.ops.mesh.primitive_cone_add(vertices=12,radius1=.045,radius2=0,depth=.095);tip=put(bpy.context.object);tip.name='STEAM_FLOW_ARROW_%d'%i;tip.data.materials.append(blue);flows.append((o,tip))
def pathpoint(u):
 u=max(0,min(.99999,u));lengths=[(Vector(b)-Vector(a)).length for a,b in zip(path,path[1:])];target=u*sum(lengths)
 for a,b,ll in zip(path,path[1:],lengths):
  if target<=ll:return Vector(a).lerp(Vector(b),target/ll)
  target-=ll
 return Vector(path[-1])
# External white mist is condensed droplets outside the spout. Inside: only labeled vapor flow ribbons.
CUR='EXTERIOR_STEAM';steamM=bpy.data.materials.new('External condensed mist');steamM.use_nodes=True;steamM.surface_render_method='BLENDED';nt=steamM.node_tree;nt.nodes.clear();out=nt.nodes.new('ShaderNodeOutputMaterial');mix=nt.nodes.new('ShaderNodeMixShader');tr=nt.nodes.new('ShaderNodeBsdfTransparent');em=nt.nodes.new('ShaderNodeEmission');em.inputs[0].default_value=(.90,.94,.96,1);em.inputs[1].default_value=.8;nt.links.new(tr.outputs[0],mix.inputs[1]);nt.links.new(em.outputs[0],mix.inputs[2]);nt.links.new(mix.outputs[0],out.inputs[0]);uv=nt.nodes.new('ShaderNodeTexCoord');sep=nt.nodes.new('ShaderNodeSeparateXYZ');nt.links.new(uv.outputs['UV'],sep.inputs[0]);noise=nt.nodes.new('ShaderNodeTexNoise');noise.noise_dimensions='4D';noise.inputs['Scale'].default_value=4;noise.inputs['Detail'].default_value=3;nt.links.new(uv.outputs['UV'],noise.inputs['Vector'])
def mathnode(op,a,b):
 n=nt.nodes.new('ShaderNodeMath');n.operation=op
 for k,v in enumerate([a,b]):
  if isinstance(v,(float,int)):n.inputs[k].default_value=v
  else:nt.links.new(v,n.inputs[k])
 return n.outputs[0]
x=mathnode('SUBTRACT',sep.outputs['X'],.5);xx=mathnode('MULTIPLY',x,x);edge=mathnode('SUBTRACT',1,mathnode('MULTIPLY',xx,4));vertical=mathnode('MULTIPLY',sep.outputs['Y'],mathnode('SUBTRACT',1,sep.outputs['Y']));a1=mathnode('MULTIPLY',edge,vertical);a2=mathnode('MULTIPLY',a1,noise.outputs['Fac']);strength=nt.nodes.new('ShaderNodeMath');strength.operation='MULTIPLY';nt.links.new(a2,strength.inputs[0]);strength.inputs[1].default_value=1.2;nt.links.new(strength.outputs[0],mix.inputs[0])
mist=[]
for i in range(3):
 vs=[(-.37,0,0),(.37,0,0),(.60,0,1.2),(-.60,0,1.2)];me=bpy.data.meshes.new('Mist billboard');me.from_pydata(vs,[],[(0,1,2,3)]);me.update();uvl=me.uv_layers.new()
 for li,co in zip(me.polygons[0].loop_indices,[(0,0),(1,0),(1,1),(0,1)]):uvl.data[li].uv=co
 o=bpy.data.objects.new('CONDENSED_MIST_%d'%i,me);C[CUR].objects.link(o);o.data.materials.append(steamM);o.location=(-1.24,.06+i*.08,2.34);mist.append(o)
CUR='LIGHTS'
for name,loc,power,size in [('Window key',(-3,-4,7),800,4),('Soft bounce',(4,-2,4),450,3),('Rim window',(-1,3,5),700,3)]:
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size;d.use_shadow_jitter=False;o=bpy.data.objects.new(name,d);C[CUR].objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,1.2))-o.location).to_track_quat('-Z','Y').to_euler()
cd=bpy.data.cameras.new('CAMERA');cam=bpy.data.objects.new('CAMERA',cd);s.collection.objects.link(cam);s.camera=cam;cd.type='ORTHO'
H=(4.5,-9,4.4,6.0,0,0,1.7);Q=(4.7,-9,4.2,4.9,.58,-.05,1.25);S=(4.5,-9,4.4,4.9,-.10,0,2.03);M=(4.9,-8.5,4.9,5.5,.30,0,1.45);D=(3.8,-8,4.1,1.90,1.31,-.05,.73)
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def lerp(a,b,u):return tuple(x+(y-x)*u for x,y in zip(a,b))
def camera(q):cam.location=q[:3];cam.rotation_euler=(Vector(q[4:])-cam.location).to_track_quat('-Z','Y').to_euler();cd.ortho_scale=q[3];bpy.context.view_layer.update()
camera(H)
CUR='ENVIRONMENT'
photo=bpy.data.images.load(str(R/'assets/KITCHEN_AI.png'))
def projectedMaterial(name,base,emission=False):
 ma=bpy.data.materials.new(name);ma.use_nodes=True;nt=ma.node_tree;nt.nodes.clear();tx=nt.nodes.new('ShaderNodeTexImage');tx.image=photo;tx.extension='EXTEND';ph=nt.nodes.new('ShaderNodeEmission');nt.links.new(tx.outputs['Color'],ph.inputs[0]);ph.inputs[1].default_value=.85
 if not emission:
  ph=nt.nodes.new('ShaderNodeBsdfPrincipled');nt.links.new(tx.outputs['Color'],ph.inputs['Base Color']);nt.links.new(tx.outputs['Color'],ph.inputs['Emission Color']);ph.inputs['Emission Strength'].default_value=.3;ph.inputs['Roughness'].default_value=.62
 if emission:other=nt.nodes.new('ShaderNodeEmission');other.inputs[0].default_value=(.83,.85,.87,1)
 else:other=nt.nodes.new('ShaderNodeBsdfPrincipled');other.inputs['Base Color'].default_value=(.85,.87,.88,1);other.inputs['Roughness'].default_value=.65
 mx=nt.nodes.new('ShaderNodeMixShader');nt.links.new(ph.outputs[0],mx.inputs[1]);nt.links.new(other.outputs[0],mx.inputs[2]);out=nt.nodes.new('ShaderNodeOutputMaterial');nt.links.new(mx.outputs[0],out.inputs[0]);return ma,mx.inputs[0]
floorM,floorMix=projectedMaterial('Photo counter to light studio',None);backM,backMix=projectedMaterial('Kitchen background to light studio',None,True)
ground=box('COUNTER_AND_STUDIO_GROUND',(0,0,-.025),(18,18,.04),floorM,0)
# Fixed photographic perspective, shared by every cut, with real 3D kettle in front.
bpy.ops.mesh.primitive_plane_add(size=2);back=put(bpy.context.object);back.name='KITCHEN_MASTER';back.location=Vector(H[:3])+(Vector(H[4:])-Vector(H[:3])).normalized()*18;back.rotation_euler=cam.rotation_euler;back.scale=(6*9/32,3,1);back.data.materials.append(backM)
bpy.context.view_layer.update()
for o in [ground,back]:
 uvl=o.data.uv_layers.active or o.data.uv_layers.new()
 for poly in o.data.polygons:
  for li in poly.loop_indices:
   p=world_to_camera_view(s,cam,o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co);uvl.data[li].uv=(p.x,p.y)
# Registered AI photographic surface on the same mesh master. The moving lever is excluded.
# This is surface animation, not measured fluid simulation. The cutaway retains real 3D water.
camera(H)
surface_image=bpy.data.images.load(str(R/'assets/KETTLE_PHOTO_SURFACE.png'));PHOTO_STYLE=[];WARP=[];styled={}
for ob in list(C['KETTLE_BODY'].objects):
 if ob.type=='CURVE' and ob.name!='POWER_CORD':
  bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.convert(target='MESH')
for obj in C['KETTLE_BODY'].objects:
 if obj.type!='MESH' or obj.name in ['POWER_LEVER','POWER_INDICATOR']:continue
 uv=obj.data.uv_layers.active or obj.data.uv_layers.new(name='Registered photographic surface')
 for poly in obj.data.polygons:
  for li in poly.loop_indices:
   pt=world_to_camera_view(s,cam,obj.matrix_world@obj.data.vertices[obj.data.loops[li].vertex_index].co);uv.data[li].uv=(pt.x,pt.y)
 original=obj.data.materials[0]
 if original.name not in styled:
  ma=original.copy();ma.name=original.name+'_REGISTERED_PHOTO';nt=ma.node_tree;out=nt.nodes.get('Material Output');old=out.inputs[0].links[0].from_socket;tx=nt.nodes.new('ShaderNodeTexImage');tx.image=surface_image;tx.extension='EXTEND';em=nt.nodes.new('ShaderNodeEmission');nt.links.new(tx.outputs['Color'],em.inputs[0]);em.inputs[1].default_value=1.0;mix=nt.nodes.new('ShaderNodeMixShader');nt.links.new(em.outputs[0],mix.inputs[1]);nt.links.new(old,mix.inputs[2]);nt.links.new(mix.outputs[0],out.inputs[0]);PHOTO_STYLE.append(mix.inputs[0]);styled[original.name]=ma
  if original==glass:
   # Localized water-surface motion. The lid, handle and kitchen never warp.
   uvn=nt.nodes.new('ShaderNodeTexCoord');sep=nt.nodes.new('ShaderNodeSeparateXYZ');nt.links.new(uvn.outputs['UV'],sep.inputs[0]);no=nt.nodes.new('ShaderNodeTexNoise');no.noise_dimensions='4D';no.inputs['Scale'].default_value=38;no.inputs['Detail'].default_value=2;nt.links.new(uvn.outputs['UV'],no.inputs['Vector']);w=nt.nodes.new('ShaderNodeMapRange');w.inputs['From Min'].default_value=.31;w.inputs['From Max'].default_value=.56;nt.links.new(sep.outputs['Y'],w.inputs[0]);z=nt.nodes.new('ShaderNodeMath');z.operation='MULTIPLY';z.inputs[1].default_value=.004;nt.links.new(no.outputs['Fac'],z.inputs[0]);v=nt.nodes.new('ShaderNodeCombineXYZ');nt.links.new(z.outputs[0],v.inputs['X']);add=nt.nodes.new('ShaderNodeVectorMath');add.operation='ADD';nt.links.new(uvn.outputs['UV'],add.inputs[0]);nt.links.new(v.outputs[0],add.inputs[1]);nt.links.new(add.outputs[0],tx.inputs['Vector']);WARP.append(no.inputs['W'])
 obj.data.materials.clear();obj.data.materials.append(styled[original.name])
def state(c,t):
 sec=t*(N[c]-1)/30;mode=0;snap=0;trip=0;on=1;boil=1
 if c=='C01':q=H;trip=ease((sec-1.55)/.22);on=1-trip;boil=1-.20*trip
 elif c=='C02':q=lerp(H,Q,ease(t));trip=1;on=0;boil=.55
 elif c=='C03':q=lerp(Q,H,ease(t));trip=1;on=0;boil=.48
 elif c=='C04':q=lerp(H,S,ease(t));trip=0;on=1
 elif c=='C05':
  q=lerp(S,M,ease(t));mode=ease((sec-.25)/1.05);trip=0;on=1
 elif c=='C06':
  q=lerp(M,D,ease(sec/2.0));mode=1;snap=ease((sec-5.60)/.10);trip=0;on=1
 elif c=='C07':q=D;mode=1;snap=1;trip=ease((sec-.22)/.18);on=1 if trip<.001 else 0
 elif c=='C08':q=lerp(D,H,ease(sec/.85));mode=1-ease(sec/.85);snap=1;trip=1;on=0;boil=.45
 return q,mode,snap,trip,on,boil,sec
def setstate(c,t):
 q,mode,snap,trip,on,boil,sec=state(c,t);camera(q);floorMix.default_value=backMix.default_value=mode
 for sty in PHOTO_STYLE:sty.default_value=mode
 for w in WARP:w.default_value=sec*.65
 hot.value=snap;pin.location.z=.68+.09*snap;rockerRoot.rotation_euler.y=-.27*(ease((sec-.08)/.15) if c=='C07' else trip);bladeRoot.rotation_euler.y=-.28*trip;leverRoot.rotation_euler.y=.20-.70*trip
 lp=lamp.node_tree.nodes['Principled BSDF'];lp.inputs['Base Color'].default_value=rgb('f5a341') if on>.5 else rgb('553e2d');lp.inputs['Emission Strength'].default_value=1.8*on
 # Warm thermal tint is mild, never incandescent or molten.
 bimetalM.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=tuple(a+(b-a)*(.28*ease((sec-2.2)/2.9) if c=='C06' else .28 if c in ['C07','C08'] else 0) for a,b in zip(rgb('a9bac5'),rgb('d7b895')))
 handleM.node_tree.nodes['Principled BSDF'].inputs['Alpha'].default_value=1-.96*mode
 glass.node_tree.nodes['Principled BSDF'].inputs['Alpha'].default_value=.14-.055*mode
 for ob in [inlet,channel,chamber]+[x for group in ['BIMETAL','ACTUATOR','CONTACTS'] for x in C[group].objects]:ob.hide_render=mode<.005
 feed.hide_render=mode<.005
 copper.node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value=.13*on*mode
 wave.value=.5+.5*math.sin(sec*9)
 surface.hide_render=mode<.005;C['BOIL_ZONE'].objects['WATER_VOLUME'].hide_render=mode<.005
 for i,(o,phase,ra) in enumerate(bubbles):
  v=(sec*.9+phase)%1;o.location.z=.58+.84*v;o.scale=(ra,ra,ra*(1+.35*v));o.hide_render=mode<.005 or c in ['C06','C07']
 noise.inputs['W'].default_value=sec*.55;strength.inputs[1].default_value=(1.45 if c=='C04' else .9)*boil*(1-mode)
 for i,o in enumerate(mist):o.rotation_euler.z=.46+i*.22;o.location.x=-1.24+.045*math.sin(sec*1.5+i);o.scale=(1+.08*math.sin(sec+i),1,1+.1*math.sin(sec*.9+i))
 for i,(o,tip) in enumerate(flows):
  flowtime=min(sec,1.2)+(N['C06']-1)/30 if c=='C07' else sec+1.2+(N['C06']-1)/30 if c=='C08' else sec
  u=(flowtime*.28+i*.25)%1;start=max(0,u-.16)
  for j,p in enumerate(o.data.splines[0].points):p.co=(*pathpoint(start+(u-start)*j/9),1)
  tip.location=pathpoint(u);direction=(pathpoint(min(.999,u+.015))-pathpoint(max(0,u-.015))).normalized();tip.rotation_euler=direction.to_track_quat('Z','Y').to_euler();o.hide_render=tip.hide_render=mode<.90
 bpy.context.view_layer.update()
def project(p):
 p=world_to_camera_view(s,cam,Vector(p));return [p.x*1080,(1-p.y)*1920]
ANIM_OBJECTS=[cam,pin,rockerRoot,bladeRoot,leverRoot]+[x for gr in ['BIMETAL','ACTUATOR','CONTACTS','STEAM_INLET','STEAM_CHANNEL','HEATER','EXTERIOR_STEAM','BOIL_ZONE'] for x in C[gr].objects]
def keyframe(f):
 for o in ANIM_OBJECTS:
  for prop in ['location','rotation_euler','scale','hide_render']:o.keyframe_insert(prop,frame=f)
 cd.keyframe_insert('ortho_scale',frame=f);hot.keyframe_insert('value',frame=f);wave.keyframe_insert('value',frame=f)
 for x in PHOTO_STYLE+WARP+[floorMix,backMix,noise.inputs['W'],strength.inputs[1],handleM.node_tree.nodes['Principled BSDF'].inputs['Alpha'],glass.node_tree.nodes['Principled BSDF'].inputs['Alpha'],lamp.node_tree.nodes['Principled BSDF'].inputs['Base Color'],lamp.node_tree.nodes['Principled BSDF'].inputs['Emission Strength'],bimetalM.node_tree.nodes['Principled BSDF'].inputs['Base Color'],copper.node_tree.nodes['Principled BSDF'].inputs['Emission Strength']]:x.keyframe_insert('default_value',frame=f)
 # Flow ribbon mesh control points are animated too, not just arrow tips.
 for o,tip in flows:
  for p in o.data.splines[0].points:p.keyframe_insert('co',frame=f)
# Final exterior framing keeps the lever and indicator clear of the right Shorts UI.
# Registration above intentionally used the original reference camera.
H=(4.5,-9,4.4,6.0,.35,0,1.7);Q=(4.7,-9,4.2,4.9,.80,-.05,1.25)
for c in ([args.cut] if args.cut else list(N)):
 for datablock in list(bpy.data.objects)+list(bpy.data.materials)+[cd]:
  datablock.animation_data_clear()
  if hasattr(datablock,'node_tree') and datablock.node_tree:datablock.node_tree.animation_data_clear()
 for o,tip in flows:o.data.animation_data_clear()
 disc.data.shape_keys.animation_data_clear();surface.data.shape_keys.animation_data_clear()
 n=N[c];s.frame_start=1;s.frame_end=n;anchors=[]
 for i in range(n):
  s.frame_set(i+1);setstate(c,i/(n-1));keyframe(i+1)
  q,mode,snap,trip,on,boil,sec=state(c,i/(n-1));anchors.append({'lever':project(leverRoot.matrix_world@Vector((.28,-.22,0))),'steam':project((-1.2,0,2.9)),'inlet':project((.64,.14,2.25)),'disc':project(discCenter),'contact':project((1.63,-.26,1.03)),'scale':cd.ortho_scale,'mode':mode,'snap':snap,'trip':trip,'on':on})
 for im in bpy.data.images:
  if im.source=='FILE':im.filepath='//../../assets/'+Path(im.filepath).name
 dest=R/'source/frames'/c;dest.mkdir(parents=True,exist_ok=True);s.frame_set(1);setstate(c,0);bpy.ops.wm.save_as_mainfile(filepath=str(R/'source/blender'/f'{c}.blend'),compress=True);(R/'source'/f'{c}_anchors.json').write_text(json.dumps(anchors))
 if args.prepare:continue
 for i in ([args.still] if args.still is not None else range(min(n,args.limit) if args.limit else n)):
  f=dest/f'{i:04}.png'
  if f.exists() and args.still is None:continue
  s.frame_set(i+1);setstate(c,i/(n-1));s.render.filepath=str(f);bpy.ops.render.render(write_still=True)
 print('COMPLETE',c,flush=True)
