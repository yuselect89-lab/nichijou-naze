# 電気ケトル自動停止｜全8カット素材 V1

Work用の無音素材と編集ソース。完成本編ではない。

各`cuts/C01`〜`C08/asset.mp4`が通常使う合成済み素材。背景／説明文字／注目線／外部湯気／キャラを別レイヤーでも収録。3D部品は各.blendの同名コレクションで独立している。

最初に`WORK_ASSEMBLY.md`、`qc/QC_REPORT.md`を読む。`manifest.json`、`FILELIST.csv`、`SHA256SUMS.txt`で内容と版を確認する。

G1 PASS・G2書面PASSの正本は`reference/`。実画確認は制作担当セルフQC、完成本編G3はWork工程。実VO尺は未測定。音声を生成・変更していない。
