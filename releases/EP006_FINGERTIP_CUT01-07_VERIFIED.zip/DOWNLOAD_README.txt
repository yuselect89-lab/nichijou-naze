EP006 visual assets V1
Start: episodes/EP006/HANDOFF_TO_WORK.md
Manifest: episodes/EP006/manifest.json
Preview: episodes/EP006/preview/v1/EP006-material-preview-360.mp4
Continuous science: episodes/EP006/preview/v1/CUT04-06-continuous-1080.mp4
Source runtime dependencies and approved shared assets are in the nichijou-naze GitHub repository. Use that repository to run the full validation commands. This archive contains EP006 only, including clearly labelled rejected-output QC evidence. VO timing, final compositing and external G3 remain pending.
