Codex handoff - 日常のなぜ？ 駅のベンチ編

音声マスター: MP3 included in this ZIP. 実測38.922438秒。改変・代替生成禁止。
台本: SCRIPT_V3_JA.txt。添付音声を正本とする。
C01/C07用駅ホーム実写: このZIPに含まれない。権利確認済み実写も未確保。
進行: C01/C07と全編最終同期はHOLD。C02-C06の無音素材制作は継続。
素材制作時はGitHub yuselect89-lab/nichijou-naze のAGENTS.md、production-lock.jsonと制作仕様ロックを先に確認。
このパッケージはChatGPT側からCodexワークスペースに自動配置されない。Codex作業依頼へファイルを添付して引き渡す。
