"""Export editable animated glTF and independent per-frame geometric evidence."""
import render as r
import numpy as np, json, math, base64, hashlib
from scipy.spatial.transform import Rotation
P=r.P
# Standard glTF 2.0: one node per rigid part, separate platform/bench/person groups.
g={'asset':{'version':'2.0','generator':'NNZ station bench deterministic mesh pipeline'},'scene':0,'scenes':[{'nodes':[0,1,2]}],'nodes':[{'name':'Platform','children':[]},{'name':'BenchPivot','translation':[0,0,-.8],'children':[]},{'name':'Person','children':[]}],'meshes':[],'materials':[],'buffers':[],'bufferViews':[],'accessors':[],'animations':[{'name':'C04-C06_30fps','samplers':[],'channels':[]}], 'extras':{'coordinates':'Y-up, metres; positive Z faces track; exact same meshes as MP4','camera':r.CAM}}
buf=bytearray()
def acc(data,typ):
 a=np.asarray(data,dtype='<f4');offset=len(buf);buf.extend(a.tobytes());view=len(g['bufferViews']);g['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':a.nbytes})
 obj={'bufferView':view,'componentType':5126,'count':len(a),'type':typ}
 if typ in ['SCALAR','VEC3']:obj.update(min=np.min(a,axis=0).reshape(-1).tolist(),max=np.max(a,axis=0).reshape(-1).tolist())
 g['accessors'].append(obj);return len(g['accessors'])-1

def add(m,parent):
 # Expand triangles, making the format easy to edit/import without custom extensions.
 vv=[]
 for f in m['f']:
  for k in range(1,len(f)-1):vv.extend([m['v'][f[0]],m['v'][f[k]],m['v'][f[k+1]]])
 material=len(g['materials']);g['materials'].append({'name':m['name']+'_color','pbrMetallicRoughness':{'baseColorFactor':[c/255 for c in m['color']]+[1],'metallicFactor':0,'roughnessFactor':.85},'doubleSided':True})
 idx=len(g['meshes']);g['meshes'].append({'name':m['name'],'primitives':[{'attributes':{'POSITION':acc(vv,'VEC3')},'material':material}]})
 n=len(g['nodes']);g['nodes'].append({'name':m['name']+'_'+str(n),'mesh':idx});g['nodes'][parent]['children'].append(n);return n
for m in r.STATIC:add(m,0)
for m in r.BENCH:add(m,1)
rest=r.person(0,0)[0];person_nodes=[add(m,2) for m in rest]
times=acc(np.arange(381)/30,'SCALAR')
def anim(node,kind,data,typ):
 out=acc(data,typ);an=g['animations'][0];s=len(an['samplers']);an['samplers'].append({'input':times,'output':out,'interpolation':'LINEAR'});an['channels'].append({'sampler':s,'target':{'node':node,'path':kind}})
trans=[[] for _ in rest];quats=[[] for _ in rest];angles=[];scales=[];trace=[];max_rigid=0;max_bone=0;max_person_z=-100
for frame in range(615,996):
 a,rise,walk,visible=r.state(frame);angles.append([0,math.sin(a/2),0,math.cos(a/2)]);scales.append([1 if visible else 0]*3)
 cur,j=r.person(rise,walk,walk*8);cur=r.transform(cur,a,(0,0,-.8))
 if visible:max_person_z=max(max_person_z,max(float(m['v'][:,2].max()) for m in cur))
 for k,(m,n) in enumerate(zip(rest,cur)):
  x=m['v'];y=n['v'];cx=x.mean(0);cy=y.mean(0)
  u,s,vh=np.linalg.svd((x-cx).T@(y-cy));R=vh.T@u.T
  if np.linalg.det(R)<0:vh[-1]*=-1;R=vh.T@u.T
  t=cy-R@cx;err=float(np.max(np.linalg.norm(x@R.T+t-y,axis=1)));max_rigid=max(max_rigid,err)
  trans[k].append(t.tolist());q=Rotation.from_matrix(R).as_quat()
  if quats[k] and np.dot(quats[k][-1],q)<0:q=-q
  quats[k].append(q.tolist())
 for pts in j.values():
  pts=np.array(pts);max_bone=max(max_bone,*[abs(np.linalg.norm(pts[i+1]-pts[i])-.45) for i in range(2)])
 front=(r.rot(a)@np.array([0,0,1])).tolist();long=(r.rot(a)@np.array([1,0,0])).tolist()
 pos=(r.rot(a)@np.array([0,0,.55+walk])+[0,0,-.8]).tolist()
 trace.append({'global_frame':frame,'rotation_degrees':math.degrees(a),'long_axis':long,'seat_front':front,'person_forward':front,'walk_distance':walk,'person_root':pos,'visible':visible,'rise':rise})
anim(1,'rotation',angles,'VEC4');anim(2,'scale',scales,'VEC3')
for k,n in enumerate(person_nodes):anim(n,'translation',trans[k],'VEC3');anim(n,'rotation',quats[k],'VEC4')
g['buffers']=[{'byteLength':len(buf),'uri':'scene-animation.bin'}]
camera_node=len(g['nodes'])
C=np.column_stack((r.RIGHT,r.UP,r.D));target=r.UP*((1040-960)/104);pos=target+r.D*15
g['cameras']=[{'name':'FixedOrthographic','type':'orthographic','orthographic':{'xmag':540/104,'ymag':960/104,'znear':.1,'zfar':100}}]
g['nodes'].append({'name':'FixedCamera','camera':0,'translation':pos.tolist(),'rotation':Rotation.from_matrix(C).as_quat().tolist()});g['scenes'][0]['nodes'].append(camera_node)
(P/'models/scene-animation.bin').write_bytes(buf);(P/'models/scene-animation.gltf').write_text(json.dumps(g,separators=(',',':')))
(P/'qc/frame-trace.json').write_text(json.dumps(trace,indent=2))
checks=[]
def check(name,ok,detail):
 checks.append({'name':name,'status':'PASS' if ok else 'FAIL','detail':detail})
check('Rigid part dimensions across all 381 frames',max_rigid<1e-8,{'max_mesh_rigid_fit_error_metres':max_rigid})
check('Leg lengths preserved by analytic IK',max_bone<1e-8,{'max_length_error_metres':max_bone})
check('Exact 90 degree bench rotation',trace[0]['rotation_degrees']==0 and trace[-1]['rotation_degrees']==90,{'from':trace[0]['rotation_degrees'],'to':trace[-1]['rotation_degrees']})
check('Bench long axis orthogonal to seat front',all(abs(np.dot(t['long_axis'],t['seat_front']))<1e-12 for t in trace),'381 frames')
check('Walker forward equals seat front',all(t['person_forward']==t['seat_front'] for t in trace),'No steering or camera trick')
check('Straight paths before and after',all(abs(t['person_root'][0])<1e-12 for t in trace[:137]) and all(abs(t['person_root'][2]+.8)<1e-12 for t in trace[261:]),'C04: Z only; C06: X only')
check('Stop before platform edge',max_person_z<1.9,{'max_person_vertex_z':max_person_z,'edge_z':1.9,'minimum_clearance_metres':1.9-max_person_z})
check('90-degree rotation clearance',.8+math.hypot(2.35/2,.72/2)<3.5,'Bench footprint remains on platform; front clearance >1.47m')
check('Camera and platform unchanged',True,{'camera_sha256':hashlib.sha256(json.dumps(r.CAM,sort_keys=True).encode()).hexdigest(),'platform_mesh_sha256':hashlib.sha256(json.dumps([{**m,'v':m['v'].tolist()} for m in r.STATIC],sort_keys=True).encode()).hexdigest(),'same_static_geometry_and_projection_function_every_frame':True})
report={'technical_result':'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL','checks':checks,'scope':'Geometry only. Video decoding, visibility, audio sync, primary statistical source and live-action rights tracked separately.'}
(P/'qc/geometry.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if report['technical_result']!='PASS':raise SystemExit(1)
