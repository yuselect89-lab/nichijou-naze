import {openBrowser} from '@remotion/renderer';
import http from 'node:http';import fs from 'node:fs';import path from 'node:path';
const root=process.cwd(),base='/episodes/STATION_BENCH/v1/';
const server=http.createServer((req,res)=>{
 const name=decodeURIComponent(new URL(req.url,'http://local').pathname);if(name==='/'){res.setHeader('Content-Type','text/html');res.end('<html><body style="background:#eee"><video muted controls width="360" height="640"></video></body></html>');return;}
 const file=path.resolve(root,'.'+name);if(!file.startsWith(root+'/')){res.writeHead(403);res.end();return;}
 try{const size=fs.statSync(file).size;const range=req.headers.range;res.setHeader('Content-Type',file.endsWith('.mp4')?'video/mp4':'application/octet-stream');res.setHeader('Accept-Ranges','bytes');if(range){const [,a,b]=range.match(/bytes=(\d+)-(\d*)/);const start=+a,end=b?+b:size-1;res.writeHead(206,{'Content-Range':`bytes ${start}-${end}/${size}`,'Content-Length':end-start+1});fs.createReadStream(file,{start,end}).pipe(res);}else{res.setHeader('Content-Length',size);fs.createReadStream(file).pipe(res);}}catch{res.writeHead(404);res.end();}
});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});const reports=[];
try{
 const page=await browser.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
 await page.goto({url:`http://127.0.0.1:${server.address().port}`,timeout:20000,options:{waitUntil:'load'}});
 for(const file of ['C02-C06-material-preview-360.mp4','C04-C06-continuous-360.mp4']){
  const result=await page.evaluate(async(url)=>{
   const v=document.querySelector('video');v.src=url;v.muted=true;let presented=0;const step=()=>{presented++;if(!v.ended)v.requestVideoFrameCallback(step);};v.requestVideoFrameCallback(step);
   const ended=new Promise((resolve,reject)=>{v.onended=()=>resolve({ended:true,duration:v.duration,videoWidth:v.videoWidth,videoHeight:v.videoHeight,presentedCallbacks:presented,decodedFrames:v.getVideoPlaybackQuality().totalVideoFrames,droppedFrames:v.getVideoPlaybackQuality().droppedVideoFrames});v.onerror=()=>reject(Error('Video error '+v.error?.message));});
   await v.play();return await ended;
  },base+'previews/'+file);
  if(!result.ended||result.videoWidth!==360||result.decodedFrames<100)throw Error(JSON.stringify(result));reports.push({file,...result});console.log('PLAYED',file,JSON.stringify(result));
 }
 fs.writeFileSync(root+base+'qc/browser-playback.json',JSON.stringify({result:'PASS',method:'HTML5 video playback to ended in Chromium, 360px wide; silent assets',reports},null,2));
}finally{await browser.close({silent:true});server.close();}
