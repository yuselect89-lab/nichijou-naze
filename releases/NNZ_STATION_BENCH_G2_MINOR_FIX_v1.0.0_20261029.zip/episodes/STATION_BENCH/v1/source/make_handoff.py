from pathlib import Path
import zipfile,json,hashlib
P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
dest=ROOT/'releases/NNZ_STATION_BENCH_G2_MINOR_FIX_v1.0.0_20261029.zip'
if dest.exists():raise RuntimeError('Archive exists')
files=[]
for f in P.rglob('*'):
 if not f.is_file() or '__pycache__' in f.parts or 'superseded' in f.parts:continue
 if f.parent.name=='previews' and (f.name.startswith('mechanism-g') or f.name in ['intro.png','stat.png']):continue
 files.append(f)
ref=json.loads((P/'qc/presenter-resolve.json').read_text())
extras=ref['files']+['public/series/v1/NotoSansCJKjp-Bold.otf','production-lock.json','public/series/approved/opening_banner.png','AGENTS.md','docs/PRODUCTION_LOCK.md','docs/PRESENTER_DIRECTION.md','docs/VISUAL_QUESTION_DIRECTION.md','docs/WORK_HANDOFF.md','package.json','package-lock.json']
files +=[ROOT/f for f in extras]
# Sources and lock are complete before assembling the archive.
lock=json.loads((P/'asset-lock.json').read_text())
for f in (P/'source').glob('*'):
 if f.is_file():lock['files'][str(f.relative_to(P))]=hashlib.sha256(f.read_bytes()).hexdigest()
(P/'asset-lock.json').write_text(json.dumps(lock,ensure_ascii=False,indent=2))
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.writestr('START_HERE.txt','駅のベンチ編 G2 MINOR FIX / 2026-10-29\n\nOpen episodes/STATION_BENCH/v1/index.html\nRead episodes/STATION_BENCH/v1/README_WORK.md and QC_REPORT.md\nC02-C06 silent assets only. C01/C07 live action HOLD. Not a completed full episode.\nVoice master and script V3 are preserved unchanged in inputs/.\nNo posting or publication.\n')
 for f in sorted(set(files)):z.write(f,str(f.relative_to(ROOT)))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for name,sha in lock['files'].items():
  archive_name=str(P.relative_to(ROOT)/name)
  assert hashlib.sha256(z.read(archive_name)).hexdigest()==sha,archive_name
 assert not any('superseded/' in n for n in z.namelist())
print(json.dumps({'archive':str(dest),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'crc':'PASS','file_lock':'PASS'},indent=2))
