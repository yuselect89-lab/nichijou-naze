from pathlib import Path
import subprocess,json
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parents[1];R=P/'renders';Q=P/'qc';V=P/'previews'
def run(args):subprocess.run([args[0],'-y',*args[1:]],check=True)
for name,start,n in [('C04',0,137),('C05',137,124),('C06',261,120)]:
 decoder=subprocess.Popen(['ffmpeg','-v','error','-i',str(R/'C04-C06-continuous.mp4'),'-vf',f'trim=start_frame={start}:end_frame={start+n}','-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE)
 encoder=subprocess.run(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-framerate','30','-i','-','-an','-c:v','libx264','-crf','18','-preset','fast','-threads','3','-pix_fmt','yuv420p','-movflags','+faststart',str(R/f'{name}.mp4')],stdin=decoder.stdout,check=True)
 decoder.stdout.close()
 assert decoder.wait()==0
files=['C02','C03','C04','C05','C06']
(Q/'concat.txt').write_text(''.join("file '../renders/"+n+".mp4'\n" for n in files))
run(['ffmpeg','-v','error','-f','concat','-safe','0','-i',str(Q/'concat.txt'),'-c','copy','-movflags','+faststart',str(R/'C02-C06-material-preview.mp4')])
for n in ['C02','C03','C04','C05','C06','C04-C06-continuous','C02-C06-material-preview']:
 run(['ffmpeg','-v','error','-i',str(R/f'{n}.mp4'),'-vf','scale=360:640','-an','-c:v','libx264','-crf','20','-preset','fast','-threads','2','-movflags','+faststart',str(V/f'{n}-360.mp4')])
 # Actual MP4 frames, not renderer's before-encode frames.
 nframes=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=nb_frames','-of','json',str(R/f'{n}.mp4')]))['streams'][0]['nb_frames']
 frames=[0,int(nframes)//4,int(nframes)//2,3*int(nframes)//4,int(nframes)-1]
 for j,f in enumerate(frames):
  run(['ffmpeg','-v','error','-i',str(R/f'{n}.mp4'),'-vf',f'select=eq(n\\,{f}),scale=360:640','-frames:v','1',str(V/f'{n}-decoded-{j}.png')])
 canvas=Image.new('RGB',(360*5,680),'white');d=ImageDraw.Draw(canvas)
 for j,f in enumerate(frames):canvas.paste(Image.open(V/f'{n}-decoded-{j}.png'),(360*j,40));d.text((360*j+12,12),f'{n} frame {f}',fill='black')
 canvas.save(V/f'{n}-decoded-sheet.jpg',quality=93)
 # A labelled representative full-resolution frame.
 run(['ffmpeg','-v','error','-i',str(R/f'{n}.mp4'),'-vf',f'select=eq(n\\,{int(nframes)//2})','-frames:v','1',str(V/f'{n}-representative.png')])
reports=[]
for path in sorted(R.glob('*.mp4')):
 data=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(path)]))
 run(['ffmpeg','-v','error','-i',str(path),'-f','null','-'])
 stream=data['streams'][0]
 expected={'C02':108,'C03':277,'C04':137,'C05':124,'C06':120,'C04-C06-continuous':381,'C04-C06-clean':381,'C03-statistics':277,'C02-C06-material-preview':766}[path.stem]
 assert stream['codec_name']=='h264' and stream['width']==1080 and stream['height']==1920 and stream['r_frame_rate']=='30/1' and int(stream['nb_frames'])==expected
 assert int(stream['nb_read_frames'])==expected and abs(float(data['format']['duration'])-expected/30)<.001
 assert not any(s['codec_type']=='audio' for s in data['streams'])
 reports.append({'file':str(path.relative_to(P)),'frames':int(stream['nb_frames']),'expected':expected,'duration':data['format']['duration'],'dimensions':[1080,1920],'fps':30,'full_decode':'PASS','silent':True})
(Q/'video-validation.json').write_text(json.dumps({'result':'PASS','videos':reports},indent=2))
print('PASS: 9 delivered videos fully decoded with exact frame counts')
