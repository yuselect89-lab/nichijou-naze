"""Deterministic mesh renderer: true 3D geometry, orthographic projection, rigid Y rotation.
No generated video or flat-image rotation. Units metres; y up, z toward tracks.
"""
from pathlib import Path
import json, math, subprocess, sys, hashlib
import numpy as np
from PIL import Image, ImageDraw, ImageFont
P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
W,H=1080,1920
FONT=ROOT/'public/series/v1/NotoSansCJKjp-Bold.otf'
fonts={n:ImageFont.truetype(str(FONT),n) for n in [24,28,30,32,36,40,44,48,54,64,80,112]}
BG=(242,246,249); INK=(25,46,64); BLUE=(30,111,173); TEAL=(0,139,136); RED=(211,76,58)
D=np.array([4.,10.,16.]); D/=np.linalg.norm(D)
RIGHT=np.cross([0,1,0],D); RIGHT/=np.linalg.norm(RIGHT)
UP=np.cross(D,RIGHT)
CAM={'projection':'orthographic','direction':D.tolist(),'right':RIGHT.tolist(),'up':UP.tolist(),'scale':104,'origin':[540,1040]}
MODEL={'units':'metres','bench_center':[0,0,-.8],'bench_long_axis':[1,0,0],'seat_front':[0,0,1],'rotation_axis':[0,1,0],'rotation_degrees':[0,90], 'camera':CAM,'platform_bounds':[-4.5,4.5,-3.5,1.9],'edge_z':1.9,'stop_z':1.28,'person':{'thigh':.45,'shin':.45,'torso':.48,'upper_arm':.29,'forearm':.28,'head_radius':.14},'timeline':{'C02':[230,337],'C03':[338,614],'C04':[615,751],'C05':[752,875],'C06':[876,995]}}
(P/'models/scene.json').write_text(json.dumps(MODEL,indent=2))

def smooth(x):
 x=max(0,min(1,x));return x*x*(3-2*x)
def rot(a):
 c,s=math.cos(a),math.sin(a);return np.array([[c,0,s],[0,1,0],[-s,0,c]])
def proj(v,top=False):
 v=np.asarray(v)
 if top:return np.column_stack((540+v[:,0]*100,980+v[:,2]*100))
 return np.column_stack((540+v@RIGHT*104,1040-v@UP*104))
def cube(center,size,color,name):
 x,y,z=np.array(size)/2
 v=np.array([[-x,-y,-z],[x,-y,-z],[x,y,-z],[-x,y,-z],[-x,-y,z],[x,-y,z],[x,y,z],[-x,y,z]])+center
 return {'name':name,'v':v,'f':[[0,3,2,1],[4,5,6,7],[0,1,5,4],[3,7,6,2],[0,4,7,3],[1,2,6,5]],'color':color}
def sphere(c,r,color,name):
 v=[]
 for j in range(7):
  phi=math.pi*j/6
  for i in range(12):
   t=2*math.pi*i/12;v.append([c[0]+r*math.sin(phi)*math.cos(t),c[1]+r*math.cos(phi),c[2]+r*math.sin(phi)*math.sin(t)])
 f=[]
 for j in range(6):
  for i in range(12):f.append([j*12+i,j*12+(i+1)%12,(j+1)*12+(i+1)%12,(j+1)*12+i])
 return {'name':name,'v':np.array(v),'f':f,'color':color}
def bone(a,b,r,color,name):
 a,b=np.array(a),np.array(b);axis=b-a;axis/=np.linalg.norm(axis)
 u=np.cross(axis,[1,0,0])
 if np.linalg.norm(u)<.1:u=np.cross(axis,[0,0,1])
 u/=np.linalg.norm(u);v=np.cross(axis,u)
 verts=[p+r*(u*math.cos(i*math.pi/4)+v*math.sin(i*math.pi/4)) for p in [a,b] for i in range(8)]
 faces=[[i,(i+1)%8,(i+1)%8+8,i+8] for i in range(8)]+[list(range(7,-1,-1)),list(range(8,16))]
 return {'name':name,'v':np.array(verts),'f':faces,'color':color}
def transform(meshes,a=0,offset=(0,0,0)):
 return [{**m,'v':m['v']@rot(a).T+offset} for m in meshes]
def bench():
 ms=[]
 for i in range(5):ms.append(cube([0,.62,-.28+i*.14],[2.35,.10,.125],(183,112,62),'seat_slat_'+str(i)))
 for i in range(3):ms.append(cube([0,.88+i*.15,-.37],[2.35,.12,.09],(183,112,62),'back_slat_'+str(i)))
 for x in [-.9,.9]:
  for z in [-.25,.25]:ms.append(cube([x,.28,z],[.095,.55,.095],(58,77,89),'leg'))
  ms.append(cube([x,.91,-.39],[.08,.70,.08],(58,77,89),'back_support'))
  ms.append(cube([x,.52,0],[.09,.08,.72],(58,77,89),'cross_support'))
 return ms
BENCH=bench()
def platform():
 ms=[cube([0,-.2,-.8],[9,.4,5.4],(209,220,226),'platform'),cube([0,-.38,3.4],[9,.15,2.9],(62,78,91),'track_bed')]
 for z in [2.65,4.05]:ms.append(cube([0,-.24,z],[9,.10,.10],(160,173,185),'rail'))
 for x in np.arange(-4.4,4.5,.52):ms.append(cube([x,-.30,3.35],[.15,.10,2.4],(91,101,108),'sleeper'))
 ms.append(cube([0,.012,1.57],[9,.025,.30],(232,190,61),'tactile_strip'))
 for x in np.arange(-4.4,4.5,.40):
  for z in [1.49,1.64]:ms.append(cube([x,.034,z],[.06,.025,.06],(244,211,88),'tactile_stud'))
 for x in np.arange(-4.5,4.6,1):ms.append(cube([x,.005,-.8],[.012,.01,5.4],(191,205,213),'tile_joint'))
 for z in [-3,-2,-1,0,1]:ms.append(cube([0,.006,z],[9,.01,.012],(191,205,213),'tile_joint'))
 return ms
STATIC=platform()
def person(rise,walk,phase=0):
 # Analytic two-bone IK preserves leg lengths throughout sit/stand/walk.
 pelvis=np.array([0,.72+.26*rise,.02+.53*rise])
 hip=pelvis+np.array([0,0,walk]);ms=[];joints={}
 for side,x in [('L',-.14),('R',.14)]:
  s=1 if side=='L' else -1
  stride=.22*math.sin(phase)*s if walk>0 else 0
  lift=.065*max(0,math.cos(phase)*s) if walk>0 else 0
  h=hip+np.array([x,0,0]);ankle=np.array([x,.09+lift,.46+walk+stride])
  mid=(h+ankle)/2;vec=ankle-h;dist=np.linalg.norm(vec)
  if dist>.899:ankle=h+vec/dist*.899;vec=ankle-h;dist=.899;mid=(h+ankle)/2
  perp=np.array([0,-vec[2],vec[1]]);perp/=np.linalg.norm(perp)
  if perp[2]<0:perp=-perp
  knee=mid+perp*math.sqrt(max(0,.45**2-(dist/2)**2))
  joints[side]=[h.tolist(),knee.tolist(),ankle.tolist()]
  ms +=[bone(h,knee,.08,(42,66,90),'thigh_'+side),bone(knee,ankle,.065,(42,66,90),'shin_'+side),cube(ankle+[0,-.045,.055],[.16,.09,.26],(35,45,56),'shoe_'+side)]
 torso=np.array([0,.46,-.055*(1-rise)]);torso=torso/np.linalg.norm(torso)*.48
 shoulder=hip+torso
 ms.append(bone(hip,shoulder,.21,(25,129,151),'torso'))
 ms.append(sphere(shoulder+[0,.25,0],.145,(220,162,116),'head'))
 ms.append(sphere(shoulder+[0,.31,-.025],.128,(43,50,56),'hair'))
 # A visible nose makes the forward direction unambiguous.
 ms.append(sphere(shoulder+[0,.24,.139],.042,(220,162,116),'nose'))
 for s in [-1,1]:
  a=shoulder+np.array([s*.23,-.03,0]);swing=.15*math.sin(phase)*s if walk>0 else .13*(1-rise)
  b=a+np.array([s*.02,-math.sqrt(.29**2-.02**2-swing**2),swing]);fz=.12*(1-rise);c=b+np.array([0,-math.sqrt(.28**2-fz**2),fz])
  ms +=[bone(a,b,.065,(25,129,151),'upper_arm'),bone(b,c,.05,(220,162,116),'forearm')]
 return ms,joints

def state(g):
 if g<=751:
  q=g-615;rise=smooth((q-15)/34);walk=1.53*smooth((q-57)/62);a=0;visible=True
 elif g<=875:
  q=g-752;a=math.pi/2*smooth((q-10)/100);rise=1;walk=1.53;visible=False
 else:
  q=g-876;a=math.pi/2;rise=smooth((q-24)/30);walk=2.05*smooth((q-60)/50);visible=True
 return a,rise,walk,visible

def draw_meshes(im,ms,top=False):
 d=ImageDraw.Draw(im);faces=[]
 light=np.array([-.35,.82,.45]);light/=np.linalg.norm(light)
 for m in ms:
  vs=m['v'];screen=proj(vs,top)
  for f in m['f']:
   points=vs[f];normal=np.cross(points[1]-points[0],points[2]-points[0]);norm=np.linalg.norm(normal)
   if norm<1e-10:continue
   normal/=norm;shade=.72+.28*abs(normal@light)
   col=tuple(int(c*shade) for c in m['color'])
   depth=np.mean(points[:,1]) if top else np.mean(points@D)
   faces.append((depth,screen[f],col))
 for _,pts,col in sorted(faces,key=lambda f:f[0]):d.polygon([tuple(p) for p in pts],fill=col)

def text(im,xy,s,size=40,fill=INK,anchor=None):ImageDraw.Draw(im).text(xy,s,font=fonts[size],fill=fill,anchor=anchor)
def line_arrow(im,a,b,color=TEAL,width=10):
 a,b=np.array(a),np.array(b);v=b-a;l=np.linalg.norm(v)
 if l<1:return
 u=v/l;p=np.array([-u[1],u[0]]);d=ImageDraw.Draw(im);d.line([tuple(a),tuple(b)],fill=color,width=width)
 d.polygon([tuple(b),tuple(b-u*26+p*15),tuple(b-u*26-p*15)],fill=color)
def tag(im,s):
 text(im,(90,370),'駅のベンチ',32,TEAL);text(im,(90,434),s,54)
def path_arrow(im,a,length,color=TEAL):
 v=np.array([math.sin(a),0,math.cos(a)]);p=np.array([0,.04,-.8])+v*.7;end=p+v*length
 xy=proj([p,end]);line_arrow(im,*xy,color,12)

def mechanism(g,labels=True):
 a,r,w,visible=state(g);im=Image.new('RGB',(W,H),BG)
 ms=STATIC+transform(BENCH,a,(0,0,-.8))
 if visible:
  p,j=person(r,w,w*8);ms+=transform(p,a,(0,0,-.8))
 draw_meshes(im,ms)
 alpha=1-smooth((g-742)/9) if g<=751 else smooth((g-876)/6) if g>=876 else 0
 if visible and alpha<1:
  base=Image.new('RGB',(W,H),BG);draw_meshes(base,STATIC+transform(BENCH,a,(0,0,-.8)))
  im=Image.blend(base,im,alpha)
 if labels:
  if g<=751:
   tag(im,'変更前');text(im,(90,535),'座席の正面 ＝ 線路の方向',36,RED)
   path_arrow(im,0,.95,RED)
   if g>729:
    text(im,(540,1360),'ホーム端の手前で停止',36,RED,'mm')
  elif g<=875:
   tag(im,'ベンチだけを90°回転');text(im,(90,535),'線路・ホーム・カメラは固定',36)
   text(im,(540,760),f'{math.degrees(a):.0f}°',80,TEAL,'mm')
   # Arc lies on the actual horizontal plane around bench centre.
   arc=[(1.55*math.sin(t),.025,-.8+1.55*math.cos(t)) for t in np.linspace(0,max(.001,a),45)]
   xy=proj(arc);ImageDraw.Draw(im).line([tuple(p) for p in xy],fill=TEAL,width=7)
   if a>.1:line_arrow(im,xy[-3],xy[-1],TEAL,7)
  else:
   tag(im,'変更後');text(im,(90,535),'座席の正面 ＝ 線路に沿う方向',36,TEAL)
   path_arrow(im,math.pi/2,2.6,TEAL)
  text(im,(540,1430),'仕組みを示す再現図',28,(89,108,120),'mm')
 return im

CHAR=Image.open(ROOT/'common_assets/nichijou_naze/characters/female_v01/poses/NNZ_CHAR_FEMALE_01_pose_point_right.png').convert('RGBA')
# Crop the existing high-resolution upper body; never synthesize new poses.
CHAR=CHAR.crop((0,0,1536,1460));CHAR.thumbnail((850,850))
def intro(f):
 im=Image.new('RGB',(W,H),BG);tag(im,'ベンチの向きにある工夫')
 # Supporting schematic has no cause/solution reveal in this introduction.
 tile=Image.new('RGB',(1080,1920),BG);draw_meshes(tile,STATIC+transform(BENCH,0,(0,0,-.8)),True)
 tile=tile.crop((80,690,1000,1600)).resize((430,425))
 im.paste(tile,(585,850));text(im,(800,1320),'ホームと線路',28,INK,'mm')
 alpha=1-smooth((f-78)/29);x=-70+int(45*smooth(f/14))
 ch=CHAR.copy();ch.putalpha(ch.getchannel('A').point(lambda v:int(v*alpha)));im.paste(ch,(x,650),ch)
 text(im,(90,1450),'安全対策の話へ',40,TEAL)
 return im

def stat_overlay(im,f,only=False):
 t=smooth((f-130)/55)
 if t<=0:return
 d=ImageDraw.Draw(im)
 # The diagram and statistical denominator are deliberately separated.
 d.rounded_rectangle((76,520,1004,845),radius=26,fill=(255,255,255))
 text(im,(110,550),'飲酒した人の転落等の事例の分類',32)
 text(im,(110,601),'線路に向かって歩く分類',36,RED)
 text(im,(110,655),'57%',80,RED)
 text(im,(450,687),'約6割',48,INK)
 d.rounded_rectangle((112,780,960,806),radius=13,fill=(222,230,236))
 d.rounded_rectangle((112,780,112+848*.57*t,806),radius=13,fill=RED)
 d.rectangle((76,1430,1004,1505),fill=BG)
 text(im,(90,1436),'JR西日本の2015年分析：該当分類57%',24)
 text(im,(90,1471),'全転落事故やベンチ利用者の割合ではありません。',24)

def behavior(f,stat_only=False):
 im=Image.new('RGB',(W,H),BG)
 if stat_only:
  stat_overlay(im,f,True);return im
 tag(im,'線路に向かって歩く')
 # No bench in this statistical scene: 57% must not imply bench-origin cases.
 ms=STATIC
 walk=1.6*smooth((f-10)/105)
 p,j=person(1,walk,walk*9);ms=ms+transform(p,0,(-.7,0,-.8))
 draw_meshes(im,ms,True)
 xy=proj([[-.7,.04,.0],[-.7,.04,1.18]],True);line_arrow(im,*xy,RED)
 text(im,(540,1390),'行動の再現イメージ',28,INK,'mm')
 stat_overlay(im,f)
 return im

def mesh_export():
 # Independent editable OBJ models: bench origin is its fixed rotation pivot.
 for name,ms in [('bench',BENCH),('platform',STATIC),('person-seated',person(0,0)[0]),('person-standing',person(1,0)[0])]:
  lines=['# Original parametric mesh; metres; Y-up'];k=0
  for m in ms:
   lines.append('o '+m['name']);lines +=['v '+' '.join(map(str,v)) for v in m['v']]
   lines +=['f '+' '.join(str(i+1+k) for i in f) for f in m['f']];k+=len(m['v'])
  (P/'models'/f'{name}.obj').write_text('\n'.join(lines))
 (P/'models/bench-mesh.json').write_text(json.dumps([{**m,'v':m['v'].tolist()} for m in BENCH]))

def render(name,frames,fn):
 dest=P/'renders'/f'{name}.mp4'
 if dest.exists():raise RuntimeError('Refusing overwrite '+str(dest))
 cmd=['ffmpeg','-v','error','-f','rawvideo','-pixel_format','rgb24','-video_size','1080x1920','-framerate','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-threads','3','-movflags','+faststart',str(dest)]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for i in range(frames):
  im=fn(i);proc.stdin.write(im.tobytes())
  if i in [0,frames//2,frames-1]:
   im.save(P/'previews'/f'{name}-{i:04d}.jpg',quality=94)
  if i%60==0:print(name,i,'/',frames,flush=True)
 proc.stdin.close()
 if proc.wait():raise RuntimeError(name+' encode failed')
 print('DONE',name,flush=True)

if __name__=='__main__':
 mesh_export()
 mode=sys.argv[1] if len(sys.argv)>1 else 'all'
 if mode in ['all','stills']:
  for g in [615,650,700,751,752,800,830,875,876,910,950,995]:mechanism(g).save(P/'previews'/f'mechanism-g{g}.png')
  intro(40).save(P/'previews/intro.png');behavior(240).save(P/'previews/stat.png')
 if mode=='stills':sys.exit()
 if mode in ['all','intro']:render('C02',108,intro)
 if mode in ['all','stat']:render('C03',277,behavior);render('C03-statistics',277,lambda f:behavior(f,True))
 if mode in ['all','mechanism']:render('C04-C06-continuous',381,lambda f:mechanism(f+615))
 if mode=='clean':render('C04-C06-clean',381,lambda f:mechanism(f+615,False))
