from pathlib import Path
import json,numpy as np,math
R=Path(__file__).parent;d=json.load(open(R/'person-meshes.json'));m=json.load(open(R/'walk-retarget-150.json'));sh=next(x for x in d['meshes'] if x['name']=='shoes');v=np.array(sh['vertices']);w=np.array(sh['weights']);loc=[]
for i in range(150):
 out=np.zeros_like(v)
 for j,n in enumerate(d['regions']):
  a=m['frames'][i][n];out+=w[:,j,None]*((v-np.array(a['rest_anchor']))@np.array(a['rotation']).T+np.array(a['anchor']))
 out[:,:2]-=[.04,-1.1+.44*i/30]
 feet=[]
 for side in [-1,1]:
  p=out[v[:,0]*side>0];feet.append([float(p[:,0].mean()),float(p[:,1].mean()),float(p[:,2].min())])
 loc.append(feet)
loc=np.array(loc);support=np.argmin(loc[:,:,2],axis=1);distance=[0.]
for i in range(1,150):
 side=int(support[i-1]);step=float(loc[i-1,side,1]-loc[i,side,1]);distance.append(distance[-1]+float(np.clip(step,.015,.075)))
distance=np.array(distance);distance-=distance[75];x=.04;y=0.;path=[None]*150
# Integrate from the threshold in both directions. Body turns after leaving the doorway.
path[75]={'x':x,'y':0,'theta':0}
for i in range(76,150):
 theta=min(math.radians(62),max(0,(distance[i]-.28)/1.3)*math.radians(62));ds=distance[i]-distance[i-1];x+=math.sin(theta)*ds;y+=math.cos(theta)*ds;path[i]={'x':x,'y':y,'theta':theta}
for i in range(75):path[i]={'x':.04,'y':float(distance[i]),'theta':0}
cal=json.load(open(R/'head-plane-calibration.json'))
for q in path:q['y']-=cal['head_depth_offset_m']
json.dump({'fps':30,'threshold_frame':75,'trajectory':path,'source':'stance-driven forward root motion from actual transformed shoe vertices; curved exit after threshold','support_drift_before_turn_median_m_s':float(np.median([abs((loc[i,support[i-1],1]-loc[i-1,support[i-1],1])+(distance[i]-distance[i-1]))*30 for i in range(1,76)]))},open(R/'root-path.json','w'),indent=2)
print('distance m',distance[0],distance[-1],'end',path[-1])
