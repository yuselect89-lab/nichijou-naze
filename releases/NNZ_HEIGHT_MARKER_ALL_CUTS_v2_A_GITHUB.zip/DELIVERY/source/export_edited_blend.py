"""Use: blender -b A-clothed-editable.blend -t 4 --python export_edited_blend.py
Preserves manual edits in the .blend; does not rebuild meshes/materials.
"""
import bpy
from pathlib import Path
root=Path(bpy.data.filepath).parent;dest=root/'walk-v2-raw-rgba';dest.mkdir(exist_ok=True)
s=bpy.context.scene;s.render.use_border=False;s.render.film_transparent=True;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA';s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100
for f in range(1,151):s.frame_set(f);s.render.filepath=str(dest/f'{f-1:04d}.png');bpy.ops.render.render(write_still=True)
