import re,json,math
from pathlib import Path
import numpy as np
p=Path(__file__).parent/'assets/walk1.bvh';s=p.read_text();hier,motion=s.split('MOTION');tokens=re.findall(r'[{}]|[^\s{}]+',hier);i=0;nodes={};order=[]
def parse(parent=None):
 global i
 kind=tokens[i];name=tokens[i+1];i+=2
 if kind=='End':name=parent+'_end'
 assert tokens[i]=='{';i+=1
 n={'name':name,'parent':parent,'channels':[]};nodes[name]=n;order.append(name)
 while tokens[i]!='}':
  typ=tokens[i]
  if typ=='OFFSET':n['offset']=list(map(float,tokens[i+1:i+4]));i+=4
  elif typ=='CHANNELS':k=int(tokens[i+1]);n['channels']=tokens[i+2:i+2+k];i+=2+k
  else:parse(name)
 i+=1
i=1;parse();lines=motion.strip().splitlines();frames=int(lines[0].split(':')[1]);dt=float(lines[1].split(':')[1]);data=np.array([list(map(float,l.split())) for l in lines[2:] if l.strip()]);col=0
for n in order:nodes[n]['start']=col;col+=len(nodes[n]['channels'])
out={'nodes':nodes,'order':order,'frame_time':dt,'frames':data.tolist()};p.with_suffix('.json').write_text(json.dumps(out))
for n in order:
 if not any(x in n.lower() for x in ['finger','thumb','index','pinky','ring','middle','tongue','lid','jaw','eye','end','__']):print(n,nodes[n]['offset'])
print('frames',frames,'channels',col)
