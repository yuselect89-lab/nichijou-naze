from pathlib import Path
import subprocess,json,hashlib
from PIL import Image,ImageDraw
R=Path(__file__).parent;D=R.parent
info=[];cuts=sorted((D/'video').glob('C*.mp4'));assert len(cuts)==7
for f in cuts:
 c=int(f.name[1:3]);dur=[4,5,5,4.5,4.5,5.5,5.5][c-1]
 a=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-of','json',str(f)]));vs=[s for s in a['streams'] if s['codec_type']=='video'];au=[s for s in a['streams'] if s['codec_type']=='audio'];assert len(vs)==1 and not au;v=vs[0]
 assert [v['width'],v['height'],v['r_frame_rate'],v['codec_name'],v['pix_fmt']]==[1080,1920,'30/1','h264','yuv420p'];assert int(v['nb_read_frames'])==int(dur*30)
 subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(f),'-f','null','-'],check=True)
 info.append({'cut':f'C{c:02d}','path':str(f.relative_to(D)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'frames':int(v['nb_read_frames']),'duration_s':float(v['duration']),'resolution':[1080,1920],'fps':30,'codec':'h264','pixel_format':'yuv420p','audio_streams':0,'decode_all_frames':'PASS'})
 if c not in [3,5,6,7]:continue
 times=[j/2 for j in range(int(dur*2))];tiles=[]
 for j,t in enumerate(times):
  temp=D/'review'/f'C{c:02d}_time_{j:02d}.jpg';subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(f),'-frames:v','1','-vf','scale=360:640','-update','1',str(temp)],check=True);tiles.append(Image.open(temp).copy());temp.unlink()
 out=Image.new('RGB',(360*5,680*((len(tiles)+4)//5)),(20,26,31));dr=ImageDraw.Draw(out)
 for j,im in enumerate(tiles):x=j%5*360;y=j//5*680;out.paste(im,(x,y));dr.text((x+10,y+650),f'C{c:02d} | {times[j]:.1f}s',fill='white')
 out.save(D/'review'/f'C{c:02d}_MOTION_CONTACT_v2.jpg',quality=90)
# Complete visual-only rough, no audio/brand/subtitles.
for folder,name,fs in [('video','ALL_CUTS_SILENT_QC_ROUGH_v2.mp4',cuts),('review','ALL_CUTS_SILENT_QC_ROUGH_v2_360.mp4',sorted((D/'review').glob('C??_360x640.mp4')))]:
 assert len(fs)==7;li=D/'review/concat.tmp';li.write_text(''.join("file '"+str(f.resolve())+"'\n" for f in fs));subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(li),'-c','copy','-movflags','+faststart',str(D/'review'/name)],check=True);li.unlink()
 q=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-of','json',str(D/'review'/name)]));assert abs(float(q['format']['duration'])-34)<.01
# The three unchanged source cuts must be byte-identical to v1.
expected=json.load(open(D/'qc/UNCHANGED_MEDIA_v1_SHA256.json'))
for name,digest in expected.items():assert hashlib.sha256((D/'video'/name).read_bytes()).hexdigest()==digest
geometry=json.load(open(D/'qc/GEOMETRY_EVIDENCE.json'));assert abs(geometry['head_depth_from_threshold_m'])<1e-5 and geometry['top_projects_within_red_band']
manifest={'version':'HEIGHT_MARKER_ALL_CUTS_v2_A','route':'A selected after replacing model, clothing, skin weights, gait, stance-driven root path and matching threshold head plane; B not run','g2':'NOT externally re-reviewed; no PASS claim','script':'G1 V1.1 unchanged; not final LOCK','video':info,'duration_s':34,'production_repository_base_commit':'01730cb8b6be04f6ee9cf2f7e0d1f6134f322ead','presenter':{'asset_id':'NNZ_CHAR_FEMALE_01','version':'v03_expressions','inherited_v02_highres':['point_right','think'],'cuts':['C02','C04','C07']},'red_band_reference':'supplied original 170 red; illustrative same-plane head height 1.735m; not a manufacturer dimensional replica','unchanged_v1_media':['C01','C02','C04'],'updated_media':['C03','C05','C06','C07 (same actor consistency)'],'geometry':geometry,'assets':'qc/CC0_ASSET_PROVENANCE.json','denoise':'qc/OIDN_PROVENANCE.json','external_paid_generation':False,'new_imagegen_calls':0,'audio_and_series_overlays':'not included in cut plates; Work composites once','self_qc':'qc/ALL_CUTS_SELF_QC_v2.md','reproduction':'source/RENDER_README_v2.md','generated_cache':'walk-v2-raw-rgba / walk-v2-final-rgba PNG intermediates excluded from GitHub ZIP; editable baked Blender + generation source retained','remaining_unverified':['external G2/G3','real-time human playback review','perfect photorealism and measured reconstruction of generated source photograph','VO/subtitle synchronization and final CTA']}
(D/'qc/ALL_CUTS_MANIFEST_v2.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print('7 cuts checked; 1020 frames; 34 seconds; 3 unchanged cuts verified',flush=True)
