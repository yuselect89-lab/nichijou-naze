"""A: official CC0 separate garments + official BVH retarget, matched photographic camera.
Blender -b -t 4 --python build_person.py -- 75 | all | bake
"""
import bpy,json,numpy as np,math,sys
from pathlib import Path
from mathutils import Matrix,Vector
R=Path(__file__).parent;old=R;SYSTEM=R/'assets/system'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
data=json.load(open(R/'person-meshes.json'));motion=json.load(open(R/'walk-retarget-150.json'));objects=[];REG=data['regions'];PATH=json.load(open(R/'root-path.json'))['trajectory'];CAL=json.load(open(R/'head-plane-calibration.json'))
def texmat(name,base,normal=None,alpha=False,skin=False):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;links=m.node_tree.links;p=n.get('Principled BSDF');p.inputs['Roughness'].default_value=.66 if not skin else .48
 t=n.new('ShaderNodeTexImage');t.image=bpy.data.images.load(str(SYSTEM/base),check_existing=True);links.new(t.outputs['Color'],p.inputs['Base Color'])
 if alpha:links.new(t.outputs['Alpha'],p.inputs['Alpha'])
 if skin:p.inputs['Subsurface Weight'].default_value=.055;p.inputs['Subsurface Radius'].default_value=(1,.4,.2)
 if normal:
  tn=n.new('ShaderNodeTexImage');tn.image=bpy.data.images.load(str(SYSTEM/normal),check_existing=True);tn.image.colorspace_settings.name='Non-Color';no=n.new('ShaderNodeNormalMap');no.inputs['Strength'].default_value=.45;links.new(tn.outputs['Color'],no.inputs['Color']);links.new(no.outputs['Normal'],p.inputs['Normal'])
 return m
mats={
'body':texmat('skin - CC0 young asian male','skins/young_asian_male/young_lightskinned_male_diffuse3.png',skin=True),
'outfit':texmat('navy shirt and denim - separate garment','clothes/male_casualsuit01/male_casualsuit01_diffuse.png','clothes/male_casualsuit01/male_casualsuit01_normal.png'),
'shoes':texmat('leather shoe - separate geometry','clothes/shoes01/shoes01_diffuse.png','clothes/shoes01/shoes01_normal.png'),
'hair':texmat('short brown hair - separate geometry','hair/short02/short02_diffuse.png','hair/short02/short02_normal.png',alpha=True),
'eyes':texmat('brown eye','eyes/materials/brown_eye.png')}
for d in data['meshes']:
 rest=np.array(d['vertices']);w=np.array(d['weights']);me=bpy.data.meshes.new(d['name']);me.from_pydata(rest.tolist(),[],d['faces']);me.update();ob=bpy.data.objects.new(d['name'],me);bpy.context.collection.objects.link(ob);me.materials.append(mats[d['name']]);uv=me.uv_layers.new(name='original CC0 UV')
 for p,u in zip(me.polygons,d['fuv']):
  p.use_smooth=True
  for j,loop in enumerate(p.loop_indices):uv.data[loop].uv=d['uv'][u[j]]
 if d['name'] in ['outfit','body']:
  sub=ob.modifiers.new('render smoothing','SUBSURF');sub.levels=1;sub.render_levels=1
 objects.append((ob,me,rest,w,d['name']))
def pose(f):
 fr=motion['frames'][f];new=[]
 for ob,me,rest,w,name in objects:
  out=np.zeros_like(rest)
  for j,n in enumerate(REG):
   a=fr[n];q=np.array(a['rotation']);anchor=np.array(a['anchor']);ref=np.array(a['rest_anchor']);out+=w[:,j,None]*((rest-ref)@q.T+anchor)
  new.append(out)
 floor=min(out[:,2].min() for out,x in zip(new,objects) if x[4]=='shoes')
 for out,(ob,me,rest,w,name) in zip(new,objects):
  out[:,2]-=floor;out[:,2]*=CAL['height_scale']
  out[:,:2]-=[.04,-1.1+.44*f/30]
  route=PATH[f];th=-route['theta'];M=np.array([[math.cos(th),-math.sin(th),0],[math.sin(th),math.cos(th),0],[0,0,1]])
  out=out@M.T;out[:,:2]+=[route['x'],route['y']]
  me.vertices.foreach_set('co',out.astype('float32').ravel());me.update()
 if 'shadowfloor' in globals():shadowfloor.location.x=PATH[f]['x'];shadowfloor.location.y=PATH[f]['y']
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=24;s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.07;s.cycles.adaptive_min_samples=4;s.cycles.max_bounces=5;s.cycles.diffuse_bounces=2;s.cycles.glossy_bounces=2;s.cycles.use_denoising=False;s.cycles.transparent_max_bounces=12;s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100;s.render.film_transparent=True;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA';s.render.fps=30;s.frame_start=1;s.frame_end=150
s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.65,.69,.76,1);s.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.35
s.view_settings.view_transform='AgX';s.view_settings.look='AgX - Medium High Contrast'
c=json.load(open(old/'camera.json'));RR=Matrix(c['R_cv']);T=Matrix(((1,0,0),(0,-1,0),(0,0,-1)));bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='same-plane matched camera';cam.matrix_world=Matrix.Translation(Vector(c['camera_center']))@(T@RR).transposed().to_4x4();cam.data.lens=c['focal_pixels']*36/941;cam.data.sensor_width=36;cam.data.sensor_fit='HORIZONTAL';s.camera=cam
for name,loc,power,size,color in [('overhead interior',(-1,-1,3.5),220,3,(1,.91,.76)),('exterior sky fill',(1,3,4),260,5,(.85,.91,1)),('doorway rim',(-2,-2,2.3),75,2,(1,.9,.75))]:
 bpy.ops.object.light_add(type='AREA',location=loc);l=bpy.context.object;l.name=name;l.data.energy=power;l.data.size=size;l.data.color=color;l.rotation_euler=(Vector((0,0,1))-l.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.mesh.primitive_plane_add(size=2.4,location=(0,0,-.004));shadowfloor=bpy.context.object;shadowfloor.name='physical floor shadow catcher';shadowfloor.is_shadow_catcher=True;shadowfloor.scale=(.6,1.5,1)
# Embedded editable source plus optional 150-pose shape-key bake.
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['75'];pose(75)
if 'bake' in args:
 import runpy
 runpy.run_path(str(R/'build_editable_rig.py'),run_name='__main__');sys.exit(0)
else:
 frames=range(150) if 'all' in args else [int(x) for x in args]
 folder=R/'walk-v2-raw-rgba';folder.mkdir(exist_ok=True)
 for f in frames:
  pose(f);s.frame_set(f+1);s.render.filepath=str(folder/f'{f:04d}.png')
  # Render bounds include the complete actor plus 180px for soft physical shadows.
  # Pixels outside are transparent; the delivery frame remains 1080x1920.
  points=np.concatenate([np.array([vert.co[:] for vert in me.vertices]) for ob,me,rest,w,name in objects]);q=points@np.array(c['R_cv']).T+np.array(c['t_cv']);front=q[:,2]>.05;q=q[front]
  pp=(q[:,:2]/q[:,2,None]*c['focal_pixels']+[470.5,836])*[1080/941,1920/1672]
  lo=pp.min(0)-180;hi=pp.max(0)+180
  s.render.use_border=True;s.render.use_crop_to_border=False;s.render.border_min_x=max(0,min(.999,lo[0]/1080));s.render.border_max_x=max(.001,min(1,hi[0]/1080));s.render.border_min_y=max(0,min(.999,1-hi[1]/1920));s.render.border_max_y=max(.001,min(1,1-lo[1]/1920))
  if hi[0]<0 or lo[0]>1080 or hi[1]<0 or lo[1]>1920 or s.render.border_min_x>=s.render.border_max_x or s.render.border_min_y>=s.render.border_max_y:
   im=bpy.data.images.new('actor out of view',width=1080,height=1920,alpha=True);im.generated_color=(0,0,0,0);im.filepath_raw=s.render.filepath;im.file_format='PNG';im.save();bpy.data.images.remove(im)
  else:bpy.ops.render.render(write_still=True)
bpy.data.texts.load(__file__)
for im in bpy.data.images:
 if im.source=='FILE':im.filepath=bpy.path.relpath(im.filepath,start=str(R))
bpy.ops.wm.save_as_mainfile(filepath=str(R/'A-clothed-editable.blend'),compress=True)
