# 編集・再レンダー v2

必要：Blender 4.3、Python 3 + Pillow/numpy（準備データの再生成時のみscipy）、FFmpeg。通常はインストール作業不要。画像/モデル/テクスチャ/歩行データは同梱済みで、外部サービスへの接続不要。

## 編集用Blenderを直接編集する

`A-clothed-editable.blend` を開く。body / outfit / shoes / hair / eyes を独立編集可能。15領域のボーンリグに150フレームの位置・回転キー、床の位置にも150フレームのキー。30fps。材質と原本テクスチャは assets/system にあり、相対参照。衣服を肌への着色で代用していない。

編集した.blendを保存し、このsourceディレクトリで:
```
blender -b A-clothed-editable.blend -t 4 --python export_edited_blend.py
python3 denoise_rgba.py --library /path/to/oidn/lib/libOpenImageDenoise.so.2
python3 render_cuts.py 3 5 6 7
```
PNGの中間素材は walk-v2-raw-rgba/（生レンダー）と walk-v2-final-rgba/（ノイズ除去後）に生成。既存名の出力を更新するため、改訂時は先にフォルダ一式を別名コピーする。

## コードから人物を再構築する

```
blender -b -t 4 --python build_person.py -- all
python3 denoise_rgba.py --library /path/to/oidn/lib/libOpenImageDenoise.so.2
python3 render_cuts.py 3 5 6 7
```
これでモデルの手動編集は初期データへ戻る。人体形状・15領域の正式ウェイト、衣服のmhclo対応表、歩行BVH、接地足に合わせた経路、定数の高さ校正を使用する。用意済みのperson-meshes.json / walk-retarget-150.json / root-path.json が通常の再描画入力。

さらに入力形状から再計算する場合:
```
python3 prepare_rig.py
python3 inspect_bvh.py
python3 retarget_walk.py
python3 prepare_person.py
python3 make_root_path.py
python3 measure_geometry.py
blender -b -t 4 --python build_person.py -- all
```
`measure_geometry.py` は頭頂の敷居同面・赤帯への投影をassertで検証する。モデルや歩行を変更したら head-plane-calibration.json を再測定し、見た目だけで校正しない。

## 空間と比較

Xは画像左向き、Yは奥行き（店外が正）、Zは高さ。敷居Y=0、床Z=0。仕様書の z=Y / y=Z。75番PNG（2.5秒）で頭頂Y=0、Z=1.735m。骨盤中心と頭頂は姿勢で前後差があるため、骨盤だけで比較時刻を決めない。人物全体に一定の高さ係数を適用し、画面上だけで頭や帯を動かしていない。目盛りは支給画像の元位置。C03は比較線なし。C06の回想だけ、同じY=0かつ頭頂と同じZから射影した短い破線を描く。別距離の人物と帯を画面上で水平連結しない。これは架空生成画像に合わせた説明空間であり、実製品の精密寸法再現ではない。

## 回想と残像

C05/C06は同じmemory_sceneの経過0〜10秒を分割。身体の輪郭は保ち、数字と背景細部を先に弱める。C06で頭頂と赤帯が同時に明瞭になる。変更は回想レイヤー内だけで、現実の原画像は不変。C07は同じ新人物の複数時間姿勢から透過残像を作る。

PNG・MP4のみで編集を閉じず、Blender・モデル/服/肌/髪/目・各レイヤー・合成コードを分離している。正式黄色帯・全編バー・VO・字幕・CTAは素材へ焼き込まない。本編側で一度だけ合成する。

## CPUノイズ除去

使用版はOpen Image Denoise 2.3.3（無料・ローカルCPU実行、生成サービス不使用）。公式配布：https://github.com/RenderKit/oidn/releases/tag/v2.3.3 。今回のクラウド環境では `/workspace/scratch/oidn/oidn-2.3.3.x86_64.linux/lib/libOpenImageDenoise.so.2` に取得済み。上の `/path/to/...` をこのパスへ置換するか、`OIDN_LIBRARY` 環境変数を指定する。別環境では公式CPUバイナリを取得する。通常の制作開始で毎回インストールし直さない。

レンダーの形状・アルファを変えず、sRGB/LDR色だけを高品質RTフィルターで処理。既存RGBA中間キャッシュはGitHubサイズ制限のため省略するが、全150フレームの動きを持つBlenderと生素材/処理コードは同梱。精度検証前のA試作を最終素材へ混在させない。

編集リグはレンダーに使った変形と同じ線形スキニングを再現。0/32/75/95/149番の全5メッシュを比較し、最大頂点差は約0.00000066m。ポーズの間引きや座標丸めによる軽量化ではない。根拠はqc/BLEND_RIG_EQUIVALENCE.json。
