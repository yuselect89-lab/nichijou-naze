# v2 素材の出所

- 入口原本：ユーザー提供のOpenAI ImageGen架空店舗。元ファイルSHAはv1から保持。第三者メーカー写真の直接転載ではない。元生成アカウントの契約証跡は未提供のため、独立した契約監査はしていない。
- ドア開放背景：前版で内部ImageGenにより開口部だけ編集したものを再利用。固定右枠と目盛りは支給原本の位置・画像。今回の新たなImageGen呼び出し0、外部有料AI生成/クレジット使用0。
- body：MakeHuman CC0標準メッシュ。
- 衣服male_casualsuit01、shoes01、short02、young_asian_maleの肌、brown eyes：公式makehuman_system_assets_cc0.zip。各mhclo/mhmatヘッダーにCC0移行の明示。必要メンバーだけ公式HTTPS配信からRange取得し、ZIP中央ディレクトリのCRC32とサイズを照合。ファイルSHAはqc/CC0_ASSET_PROVENANCE.json。
- 既存骨格default.mhskel、スキンウェイトdefault_weights.mhw：MakeHuman公式、CC0を実ファイルで確認。
- walk1.bvh：MakeHuman公式。walks.mhanimは作者Jonas Hauquier、ライセンスAGPL3と明記。包括CC0へ読み替えず、BVH、mhanim、処理ソース、AGPL全文を保持。歩行データ・派生アニメーションの再配布時は同条件を維持する。CC0メッシュ/衣服/テクスチャとは別の素材。編集データのライセンスと映像作品の採用・承認を混同しない。
- 女性解説キャラ：承認台帳 NNZ_CHAR_FEMALE_01 / v03_expressions。point_right / thinkはv02_highres継承。原本再生成なし。C02/C04の映像自体は不変。C07は従来のhappyを保持し、人物残像だけ更新。

未承認の人体候補や他社ロゴを持つモデルは不使用。新たなBGM/SE/VOなし。共通ブランド原本と旧EPは変更していない。
