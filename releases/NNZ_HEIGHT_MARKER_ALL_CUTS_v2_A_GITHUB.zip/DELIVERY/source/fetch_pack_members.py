import zipfile,subprocess,struct,zlib,binascii,json,hashlib,concurrent.futures,sys
from pathlib import Path
R=Path(__file__).parent;DEST=R/'assets/system';DEST.mkdir(parents=True,exist_ok=True)
URL='https://files2.makehumancommunity.org/asset_packs/makehuman_system_assets/makehuman_system_assets_cc0.zip';Z=zipfile.ZipFile('/tmp/mh-pack-sparse.zip');TOTAL=280737770
names=sys.argv[1:]
def fetch(name):
 info=Z.getinfo(name);out=DEST/name
 if out.exists() and (binascii.crc32(out.read_bytes())&0xffffffff)==info.CRC:return name,'cached'
 tmp=R/'assets'/('range-'+hashlib.sha256(name.encode()).hexdigest()[:12]+'.bin');end=min(TOTAL-1,info.header_offset+info.compress_size+4096)
 subprocess.run(['curl','-fLsS','--max-time','90','--range',f'{info.header_offset}-{end}',URL,'-o',str(tmp)],check=True)
 raw=tmp.read_bytes();assert raw[:4]==b'PK\x03\x04';nl,el=struct.unpack_from('<HH',raw,26);payload=raw[30+nl+el:30+nl+el+info.compress_size]
 data=zlib.decompress(payload,-15) if info.compress_type==8 else payload
 assert len(data)==info.file_size and (binascii.crc32(data)&0xffffffff)==info.CRC
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);tmp.unlink();return name,'CRC_PASS'
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(fetch,names):print(*result,flush=True)
