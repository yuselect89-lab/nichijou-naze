import json,numpy as np
from pathlib import Path
from scipy.spatial import cKDTree
R=Path(__file__).parent;D=json.load(open(R/'rig-data.json'));v=np.array(D['vertices']);w=np.array(D['weights']);scale=D['scale']
bodyids=np.array(sorted(set(sum(D['faces'],[]))));zeros=np.where(w.sum(1)<.1)[0];dist,ind=cKDTree(v[bodyids]).query(v[zeros],k=3);inv=1/np.maximum(dist,.00001)**2;inv/=inv.sum(1)[:,None];w[zeros]=(w[bodyids[ind]]*inv[:,:,None]).sum(1)
SYSTEM=R/'assets/system';meshes=[];deletions=set()
def obj(path):
 vv=[];uv=[];ff=[];fu=[]
 for line in path.read_text().splitlines():
  a=line.split()
  if not a:continue
  if a[0]=='v':vv.append(list(map(float,a[1:4])))
  elif a[0]=='vt':uv.append(list(map(float,a[1:3])))
  elif a[0]=='f':ff.append([int(s.split('/')[0])-1 for s in a[1:]]);fu.append([int(s.split('/')[1])-1 for s in a[1:]])
 return vv,uv,ff,fu
for name,prefix in [('outfit','clothes/male_casualsuit01/male_casualsuit01'),('shoes','clothes/shoes01/shoes01'),('hair','hair/short02/short02'),('eyes','eyes/low-poly/low-poly')]:
 p=SYSTEM/prefix;ov,uv,faces,fuv=obj(p.with_suffix('.obj'));refs=[];bary=[];offset=[];mode='';scales=np.ones(3)
 for line in p.with_suffix('.mhclo').read_text().splitlines():
  a=line.split()
  if not a or a[0].startswith('#'):continue
  if a[0] in ['x_scale','y_scale','z_scale']:
   # mhclo axes x,height,depth. Dataset axes x,depth,height.
   k={'x_scale':0,'y_scale':2,'z_scale':1}[a[0]];scales[k]=abs(v[int(a[1]),k]-v[int(a[2]),k])/(float(a[3])*scale)
  elif a[0]=='verts':mode='verts'
  elif a[0]=='delete_verts':mode='delete'
  elif mode=='verts' and a[0][0].isdigit():
   if len(a)==1:refs.append([int(a[0])]*3);bary.append([1,0,0]);offset.append([0,0,0])
   elif len(a)>=9:refs.append(list(map(int,a[:3])));bary.append(list(map(float,a[3:6])));off=list(map(float,a[6:9]));offset.append([off[0],off[2],off[1]])
  elif mode=='delete':
   # The format supports integer lists and inclusive ranges.
   i=0
   while i<len(a):
    try:
     if i+2<len(a) and a[i+1]=='-':deletions.update(range(int(a[i]),int(a[i+2])+1));i+=3
     else:deletions.add(int(a[i]));i+=1
    except ValueError:i+=1
 refs=np.array(refs);bary=np.array(bary);assert len(refs)==len(ov),(name,len(refs),len(ov))
 pos=(v[refs]*bary[:,:,None]).sum(1)+np.array(offset)*scale*scales
 ww=(w[refs]*bary[:,:,None]).sum(1);ww=np.maximum(0,ww);ww/=np.maximum(ww.sum(1)[:,None],1e-10)
 meshes.append({'name':name,'vertices':pos.tolist(),'weights':ww.tolist(),'uv':uv,'faces':faces,'fuv':fuv})
 print(name,'verts',len(pos),'scale',scales)
faces=[f for f in D['faces'] if not all(x in deletions for x in f)];uvfaces=[u for f,u in zip(D['faces'],D['fuv']) if not all(x in deletions for x in f)]
# Relax the supplied neutral spread fingers into a lightly curled walking hand.
from scipy.spatial.transform import Rotation
fullweights=json.load(open(R/'assets/default_weights.mhw'))['weights'];allbones=D['bones'];bodyRest=v.copy();fingerSum=np.zeros(len(v));fingerOut=np.zeros_like(v);TM={}
def handtransform(name):
 if name in TM:return TM[name]
 b=allbones[name];par=b['parent'];P=handtransform(par) if par in allbones and (par.startswith('finger') or par.startswith('metacarpal')) else np.eye(4)
 M=np.eye(4)
 if name.startswith('finger'):
  a=np.array(b['head']);end=np.array(b['tail']);axis=np.cross(end-a,[0,1,0]);axis/=max(1e-8,np.linalg.norm(axis));level=int(name.split('-')[1].split('.')[0]);thumb=name.startswith('finger1-');angle=math.radians(10 if thumb else {1:20,2:32,3:18}.get(level,15));Q=Rotation.from_rotvec(axis*angle).as_matrix();M[:3,:3]=Q;M[:3,3]=a-Q@a
 TM[name]=P@M;return TM[name]
import math
for name,vals in fullweights.items():
 if not name.startswith('finger'):continue
 M=handtransform(name)
 for idx,ww in vals:
  fingerSum[idx]+=ww;fingerOut[idx]+=ww*(M[:3,:3]@v[idx]+M[:3,3])
bodyRest=v*(1-fingerSum[:,None])+fingerOut
ids=sorted(set(sum(faces,[])));ix={j:i for i,j in enumerate(ids)}
meshes.insert(0,{'name':'body','vertices':bodyRest[ids].tolist(),'weights':w[ids].tolist(),'uv':D['uv'],'faces':[[ix[j] for j in f] for f in faces],'fuv':uvfaces})
(R/'person-meshes.json').write_text(json.dumps({'regions':D['regions'],'meshes':meshes},separators=(',',':')))
print('Visible body polygons',len(faces),'of',len(D['faces']))
