"""CPU OIDN 2.3.3; preserve alpha, filter sRGB/LDR color only.
Raw Blender output -> separate denoised RGBA cache. No geometry/image generation.
Set OIDN_LIBRARY to .../lib/libOpenImageDenoise.so.2.
"""
import ctypes as C,os,argparse,time,json
from pathlib import Path
import numpy as np
from PIL import Image
R=Path(__file__).parent;pa=argparse.ArgumentParser();pa.add_argument('--src',type=Path,default=R/'walk-v2-raw-rgba');pa.add_argument('--dst',type=Path,default=R/'walk-v2-final-rgba');pa.add_argument('--library',default=os.environ.get('OIDN_LIBRARY'));pa.add_argument('--follow',action='store_true');pa.add_argument('--first',type=int,default=0);pa.add_argument('--last',type=int,default=149);a=pa.parse_args();a.dst.mkdir(exist_ok=True,parents=True)
if not a.library:raise SystemExit('Set OIDN_LIBRARY to the official OIDN 2.3.3 CPU shared library; see RENDER_README_v2.md')
L=C.CDLL(a.library)
def fn(name,args,ret=None):
 f=getattr(L,name);f.argtypes=args;f.restype=ret;return f
newdev=fn('oidnNewDevice',[C.c_int],C.c_void_p);setdi=fn('oidnSetDeviceInt',[C.c_void_p,C.c_char_p,C.c_int]);commitdev=fn('oidnCommitDevice',[C.c_void_p]);newfilter=fn('oidnNewFilter',[C.c_void_p,C.c_char_p],C.c_void_p);setimg=fn('oidnSetSharedFilterImage',[C.c_void_p,C.c_char_p,C.c_void_p,C.c_int,*([C.c_size_t]*5)]);setbool=fn('oidnSetFilterBool',[C.c_void_p,C.c_char_p,C.c_bool]);setint=fn('oidnSetFilterInt',[C.c_void_p,C.c_char_p,C.c_int]);commitfilter=fn('oidnCommitFilter',[C.c_void_p]);execute=fn('oidnExecuteFilter',[C.c_void_p]);geterr=fn('oidnGetDeviceError',[C.c_void_p,C.POINTER(C.c_char_p)],C.c_int)
dev=newdev(1);setdi(dev,b'numThreads',2);commitdev(dev);flt=newfilter(dev,b'RT');setbool(flt,b'hdr',False);setbool(flt,b'srgb',True);setint(flt,b'quality',6)
for i in range(a.first,a.last+1):
 src=a.src/f'{i:04d}.png';dst=a.dst/src.name;start=time.monotonic()
 while True:
  try:
   im=Image.open(src).convert('RGBA');im.load();break
  except (FileNotFoundError,OSError,SyntaxError):
   if not a.follow or time.monotonic()-start>900:raise
   time.sleep(1)
 arr=np.array(im);mask=arr[:,:,3]>4
 if mask.any():
  yy,xx=np.where(mask);x0=max(0,int(xx.min())-24);x1=min(im.width,int(xx.max())+25);y0=max(0,int(yy.min())-24);y1=min(im.height,int(yy.max())+25)
  rgb=np.ascontiguousarray(arr[y0:y1,x0:x1,:3].astype('float32')/255);out=np.empty_like(rgb);h,w=rgb.shape[:2]
  setimg(flt,b'color',rgb.ctypes.data,3,w,h,0,12,w*12);setimg(flt,b'output',out.ctypes.data,3,w,h,0,12,w*12);commitfilter(flt);execute(flt);msg=C.c_char_p();err=geterr(dev,C.byref(msg))
  if err:raise RuntimeError(f'OIDN {err}: {msg.value}')
  arr[y0:y1,x0:x1,:3]=np.uint8(np.clip(out*255+.5,0,255))
 # Alpha must remain bit-identical, including transparent exit frames.
 assert np.array_equal(arr[:,:,3],np.array(im)[:,:,3]);temp=dst.with_suffix('.tmp.png');Image.fromarray(arr).save(temp);temp.replace(dst)
 if i%15==0:print('DENOISED',i,flush=True)
print('DENOISE COMPLETE',a.first,a.last,flush=True)
