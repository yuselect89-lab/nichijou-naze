from pathlib import Path
import json,numpy as np,math
R=Path(__file__).parent;d=json.load(open(R/'person-meshes.json'));motion=json.load(open(R/'walk-retarget-150.json'));route=json.load(open(R/'root-path.json'));regions=d['regions'];points=[]
f=75
for mesh in d['meshes']:
 v=np.array(mesh['vertices']);w=np.array(mesh['weights']);out=np.zeros_like(v)
 for j,n in enumerate(regions):
  a=motion['frames'][f][n];out+=w[:,j,None]*((v-np.array(a['rest_anchor']))@np.array(a['rotation']).T+np.array(a['anchor']))
 points.append((mesh['name'],out))
floor=next(v[:,2].min() for n,v in points if n=='shoes')
for n,v in points:v[:,2]-=floor;v[:,2]*=json.load(open(R/'head-plane-calibration.json'))['height_scale'];v[:,:2]-=[.04,-1.1+.44*f/30];v[:,:2]+=[route['trajectory'][f]['x'],route['trajectory'][f]['y']]
hair=next(v for n,v in points if n=='hair');top=hair[np.argmax(hair[:,2])];c=json.load(open(R/'camera.json'));q=np.array(c['R_cv'])@top+np.array(c['t_cv']);pixel=(q[:2]/q[2]*c['focal_pixels']+[470.5,836])*[1080/941,1920/1672]
report={'threshold_frame':75,'threshold_time_s':2.5,'world_axes':'Y=depth positive outside; Z=height','pelvis_route_Y_m':route['trajectory'][75]['y'],'hair_top_world_m':top.tolist(),'hair_top_pixel_1080':pixel.tolist(),'original_red_band_pixel_y_1080':[694,785],'top_projects_within_red_band':bool(694<=pixel[1]<=785),'head_depth_from_threshold_m':float(top[1]),'comparison_line_rendered_in_C03':False,'recall_relation_in_C06':{'world_plane_Y_m':0,'world_height_Z_m':1.735,'starts_cut_time_s':.5,'method':'projected same-plane short dashed relation; no screen-height guess'},'before_turn_support_root_drift_median_m_s':route['support_drift_before_turn_median_m_s'],'scope':'coordinate and projection verification, not proof of photorealism or viewer comprehension'}
assert abs(top[1])<1e-5 and 1.7<=top[2]<=1.8 and report['top_projects_within_red_band']
(R.parent/'qc/GEOMETRY_EVIDENCE.json').write_text(json.dumps(report,indent=2));print(report)
