from pathlib import Path
import json,numpy as np
R=Path(__file__).parent;src=R
raw=[];faces=[];uv=[];fuv=[];group='';groups={}
for line in open(src/'assets/makehuman-base-CC0.obj'):
 a=line.split()
 if not a:continue
 if a[0]=='v':raw.append(list(map(float,a[1:4])))
 elif a[0]=='vt':uv.append(list(map(float,a[1:3])))
 elif a[0]=='g':group=a[1];groups[group]=[]
 elif a[0]=='f':
  ids=[int(x.split('/')[0])-1 for x in a[1:]];groups[group]+=ids
  if group=='body':faces.append(ids);fuv.append([int(x.split('/')[1])-1 for x in a[1:]])
v=np.array(raw);ids=np.array(sorted(set(sum(faces,[]))));mini=v[ids,1].min();scale=1.735/(v[ids,1].max()-mini);v=np.column_stack((v[:,0],v[:,2],v[:,1]-mini))*scale
rig=json.load(open(R/'assets/default.mhskel'));wr=json.load(open(R/'assets/default_weights.mhw'))['weights']
def point(n):return v[rig['joints'][n]].mean(0)
bones={n:{'head':point(b['head']).tolist(),'tail':point(b['tail']).tolist(),'parent':b['parent']} for n,b in rig['bones'].items()}
joints={}
for side in ['L','R']:
 for name,b in [('hip','upperleg01.'),('knee','lowerleg01.'),('ankle','foot.'),('shoulder','upperarm01.'),('elbow','lowerarm01.'),('wrist','wrist.')]:joints[name+side]=bones[b+side]['head']
# Collapse anatomical twist bones while preserving the supplied skin weights.
def region(n):
 side='L' if n.endswith('.L') else 'R'
 if n.startswith('upperleg'):return 'thigh'+side
 if n.startswith('lowerleg'):return 'calf'+side
 if n.startswith(('foot','toe')):return 'foot'+side
 if n.startswith('upperarm'):return 'upperarm'+side
 if n.startswith('lowerarm'):return 'forearm'+side
 if n.startswith(('wrist','finger','metacarpal')):return 'hand'+side
 if n.startswith(('pelvis','root')):return 'pelvis'
 if n.startswith('spine'):return 'torso'
 if n.startswith(('clavicle','shoulder')):return 'torso'
 return 'head'
regions=['pelvis','torso','head']+[n+s for s in ['L','R'] for n in ['thigh','calf','foot','upperarm','forearm','hand']]
weights=np.zeros((len(v),len(regions)))
for n,vals in wr.items():
 col=regions.index(region(n))
 for i,w in vals:weights[i,col]+=w
weights/=np.maximum(weights.sum(1)[:,None],1e-9)
json.dump({'vertices':v.tolist(),'faces':faces,'uv':uv,'fuv':fuv,'groups':groups,'bones':bones,'joints':joints,'regions':regions,'weights':weights.tolist(),'scale':scale},open(R/'rig-data.json','w'))
print('body vertices',len(ids),'regions',regions)
