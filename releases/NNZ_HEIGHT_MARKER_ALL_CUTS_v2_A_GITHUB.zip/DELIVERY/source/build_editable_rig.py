"""Lossless-to-render editable 15-bone skinning rig; same transforms as NumPy renderer.
blender -b -t 1 --python build_editable_rig.py
No pose reduction or quantization. All 150 frames retain full-precision transforms.
"""
from pathlib import Path
import bpy,numpy as np,json,math
from mathutils import Matrix,Vector
R=Path(__file__).parent;path=R/'build_person.py';code=path.read_text();g={'__file__':str(path),'__name__':'__rig_build__'};exec(code[:code.index('# Embedded editable source')],g)
objects=g['objects'];motion=g['motion'];REG=g['REG'];PATH=g['PATH'];CAL=g['CAL'];s=g['s'];floor=g['shadowfloor']
bpy.ops.object.armature_add();arm=bpy.context.object;arm.name='pedestrian_15_region_rig';bpy.ops.object.mode_set(mode='EDIT');arm.data.edit_bones.remove(arm.data.edit_bones[0])
rd=json.load(open(R/'rig-data.json'));J={n:Vector(v) for n,v in rd['joints'].items()}
for name in REG:
 b=arm.data.edit_bones.new(name);a=Vector(motion['frames'][0][name]['rest_anchor']);b.head=a
 side=name[-1] if name[-1:] in ['L','R'] else None
 if name.startswith('thigh'):end=J['knee'+side]
 elif name.startswith('calf'):end=J['ankle'+side]
 elif name.startswith('upperarm'):end=J['elbow'+side]
 elif name.startswith('forearm'):end=J['wrist'+side]
 elif name.startswith('foot'):end=Vector(rd['bones']['foot.'+side]['tail'])
 elif name.startswith('hand'):end=Vector(rd['bones']['wrist.'+side]['tail'])
 else:end=a+Vector((0,0,.18 if name!='torso' else .4))
 b.tail=end if (end-a).length>.001 else a+Vector((0,0,.1));b.use_deform=True
bpy.ops.object.mode_set(mode='OBJECT');restmat={n:arm.data.bones[n].matrix_local.copy() for n in REG}
root=bpy.data.objects.new('actor_root_height_and_route',None);bpy.context.collection.objects.link(root);root.scale=(1,1,CAL['height_scale']);root.rotation_mode='QUATERNION';arm.parent=root
for ob,me,rest,w,name in objects:
 ob.parent=root
 for j,n in enumerate(REG):
  vg=ob.vertex_groups.new(name=n)
  for i in np.where(w[:,j]>1e-8)[0]:vg.add([int(i)],float(w[i,j]),'REPLACE')
 mod=ob.modifiers.new('official linear skin weights','ARMATURE');mod.object=arm;mod.use_deform_preserve_volume=False
 bpy.context.view_layer.objects.active=ob
 while ob.modifiers.find(mod.name)>0:bpy.ops.object.modifier_move_up(modifier=mod.name)
for pb in arm.pose.bones:pb.rotation_mode='QUATERNION'
for f in range(150):
 s.frame_set(f+1);fr=motion['frames'][f]
 # Same exact grounding as the rendered mesh, before the common object transform.
 ob,me,v,w,name=next(x for x in objects if x[4]=='shoes');out=np.zeros_like(v)
 for j,n in enumerate(REG):
  a=fr[n];out+=w[:,j,None]*((v-np.array(a['rest_anchor']))@np.array(a['rotation']).T+np.array(a['anchor']))
 ground=float(out[:,2].min());route=PATH[f];th=-route['theta'];Q=Matrix.Rotation(th,4,'Z');shift=Q@Vector((.04,-1.1+.44*f/30,0))
 root.location=(route['x']-shift.x,route['y']-shift.y,-ground*CAL['height_scale']);root.rotation_quaternion=Q.to_quaternion()
 for prop in ['location','rotation_quaternion','scale']:root.keyframe_insert(prop,frame=f+1)
 for n in REG:
  a=fr[n];M=Matrix(a['rotation']).to_4x4();M.translation=Vector(a['anchor'])-M.to_3x3()@Vector(a['rest_anchor']);pb=arm.pose.bones[n];pb.matrix=M@restmat[n]
  for prop in ['location','rotation_quaternion','scale']:pb.keyframe_insert(prop,frame=f+1)
 floor.location.x=route['x'];floor.location.y=route['y'];floor.keyframe_insert('location',frame=f+1)
s.frame_set(76);s.render.use_border=False
for im in bpy.data.images:
 if im.source=='FILE':im.filepath=bpy.path.relpath(im.filepath,start=str(R))
bpy.data.texts.load(__file__);bpy.ops.wm.save_as_mainfile(filepath=str(R/'A-clothed-editable.blend'),compress=True)
print('EDITABLE RIG',len(arm.pose.bones),'BONES',s.frame_end,'FRAMES')
