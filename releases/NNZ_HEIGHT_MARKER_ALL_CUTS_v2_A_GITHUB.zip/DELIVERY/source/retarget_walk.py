from pathlib import Path
import json, numpy as np
from scipy.spatial.transform import Rotation
R=Path(__file__).parent;rig=json.load(open(R/'rig-data.json'));b=json.load(open(R/'assets/walk1.json'));J={k:np.array(v) for k,v in rig['joints'].items()};data=np.array(b['frames']);S=np.diag([1,-1,1]);period=1.05
axis={'X':np.array([1.,0,0]),'Y':np.array([0.,1,0]),'Z':np.array([0.,0,1])}
def quat(a,c):return Rotation.align_vectors([c/np.linalg.norm(c)],[a/np.linalg.norm(a)])[0].as_matrix()
def bvh(t):
 f=(t/period%1)*len(data);i=int(f);j=(i+1)%len(data);a=f-i;val=data[i]*(1-a)+data[j]*a;G={};P={}
 for name in b['order']:
  n=b['nodes'][name];M=np.eye(3);off=np.array(n['offset']);st=n['start']
  for k,ch in enumerate(n['channels']):
   if ch.endswith('rotation'):M=M@Rotation.from_rotvec(axis[ch[0]]*np.deg2rad(val[st+k])).as_matrix()
   else:off+=axis[ch[0]]*val[st+k]
  parent=n['parent']
  if parent:G[name]=G[parent]@M;P[name]=P[parent]+G[parent]@off
  else:G[name]=M;P[name]=off
 return {n:S@g@S for n,g in G.items()},{n:S@p for n,p in P.items()}
def endpoints(t):
 g,p=bvh(t);pelvis=(J['hipL']+J['hipR'])/2;root=np.array([.04,-1.1+.44*t,0]);out={};hipg=g['Hips'];torg=g['Spine3'];headg=g['Head']
 out['pelvis']=(pelvis,pelvis+root,hipg);out['torso']=(pelvis,pelvis+root,torg)
 neck=np.array(rig['bones']['head']['head']);newneck=pelvis+root+torg@(neck-pelvis);out['head']=(neck,newneck,headg)
 for side in ['L','R']:
  hip=pelvis+root+hipg@(J['hip'+side]-pelvis);sh=pelvis+root+torg@(J['shoulder'+side]-pelvis)
  for reg,a,c,ba,bc,start in [('thigh','hip','knee','UpLeg_','LoLeg_',hip),('upperarm','shoulder','elbow','UpArm_','LoArm_',sh)]:
   v=J[c+side]-J[a+side];direction=p[bc+side]-p[ba+side];q=quat(v,direction);end=start+q@v;out[reg+side]=(J[a+side],start,q)
   if reg=='thigh':knee=end
   else:el=end
  for reg,a,c,ba,bc,start in [('calf','knee','ankle','LoLeg_','Foot_',knee),('forearm','elbow','wrist','LoArm_','Hand_',el)]:
   v=J[c+side]-J[a+side];direction=p[bc+side]-p[ba+side]
   if reg=='forearm':direction=direction*.40+np.array([0.,0.,-np.linalg.norm(direction)])*.60
   q=quat(v,direction);end=start+q@v;out[reg+side]=(J[a+side],start,q)
   if reg=='calf':ankle=end
   else:wrist=end
  restfoot=np.array(rig['bones']['foot.'+side]['tail'])-J['ankle'+side];q=quat(restfoot,p['Toe_'+side]-p['Foot_'+side]);# Retargeting must not inherit the BVH toe-axis rest offset as a permanent high heel.
  pitch=float(np.clip(Rotation.from_matrix(q).as_euler('XYZ')[0],-.12,.12))
  q=Rotation.from_rotvec(np.array([pitch,0.,0.])).as_matrix()
  out['foot'+side]=(J['ankle'+side],ankle,q)
  resthand=np.array(rig['bones']['wrist.'+side]['tail'])-J['wrist'+side]
  direction=wrist-el
  inward=np.array([-1.,0,0]) if side=='L' else np.array([1.,0,0])
  hq=Rotation.align_vectors([direction/np.linalg.norm(direction),inward],[resthand/np.linalg.norm(resthand),np.array([0.,1,0])])[0].as_matrix()
  out['hand'+side]=(J['wrist'+side],wrist,hq)
 return out
frames=[]
for i in range(150):
 out=endpoints(i/30);frames.append({n:{'rest_anchor':a.tolist(),'anchor':c.tolist(),'rotation':q.tolist()} for n,(a,c,q) in out.items()})
(R/'walk-retarget-150.json').write_text(json.dumps({'fps':30,'cycle_s':period,'frames':frames,'method':'official BVH retargeted to official anatomical skin weights; not prototype inverse-distance IK','license_motion':'AGPL3 per walks.mhanim; source included'},separators=(',',':')))
print('Retargeted',len(frames),'frames',len(frames[0]),'regions')
