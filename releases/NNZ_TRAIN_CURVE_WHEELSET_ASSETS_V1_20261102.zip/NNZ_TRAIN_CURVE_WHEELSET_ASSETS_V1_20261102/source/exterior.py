"""One moving two-car train and one curved-track photographic master.
The pinhole camera stays fixed; C02 changes lens/crop within the same master.
Body, bogies, wheels, rails and pantographs are editable 3D parts.
"""
import bpy,math,json,sys,argparse,shutil
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
R=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--cut');ap.add_argument('--reference',choices=['empty','train','bogie']);ap.add_argument('--prepare',action='store_true');ap.add_argument('--still',type=int);args=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
T=json.loads((R/'source/timing.json').read_text());N={x['cut_id']:x['frames'] for x in T};RR=45.;GAUGE=.72;BG_LENS=20
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);s=bpy.context.scene;s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100;s.render.fps=30;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.compression=12;s.render.threads_mode='FIXED';s.render.threads=4;s.display.render_aa='8';sh=s.display.shading;sh.light='STUDIO';sh.studio_light='outdoor.sl';sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.show_specular_highlight=True;s.world.color=(.69,.80,.91);s.view_settings.view_transform='Standard';s.view_settings.look='None';s.view_settings.exposure=.35
COL={}
for name in ['EXTERIOR_TRAIN_MASTER','TRAIN_BOGIES','EXTERIOR_TRACK','ENVIRONMENT','PHOTO_BACKGROUND']:
 col=bpy.data.collections.new(name);s.collection.children.link(col);COL[name]=col
CUR='EXTERIOR_TRAIN_MASTER'
def put(o):
 for c in list(o.users_collection):c.objects.unlink(o)
 COL[CUR].objects.link(o);o['master_id']=CUR;o['version']='1.0.0';return o
def mat(n,rgb):
 m=bpy.data.materials.new(n);m.diffuse_color=(*rgb,1);m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*rgb,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.28;return m
silver=mat('Satin stainless train',(.61,.67,.70));white=mat('Ivory cab',(.85,.87,.86));navy=mat('Unbranded deep blue stripe',(.035,.12,.24));glass=mat('Smoked train glazing',(.025,.065,.08));steel=mat('Steel wheel and rails',(.29,.34,.38));rubber=mat('Dark rubber',(.035,.045,.05));red=mat('Rear red lamps',(.72,.015,.009));stone=mat('Gray ballast',(.30,.32,.30));grass=mat('Vegetated embankment',(.21,.32,.15));wood=mat('Sleeper concrete',(.49,.49,.44));dark=mat('Bogie dark steel',(.10,.14,.15))
def box(n,loc,dim,m,b=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=put(bpy.context.object);o.name=n;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if b:q=o.modifiers.new('Rounded manufactured edge','BEVEL');q.width=b;q.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return o
def cylinder(n,loc,r,d,m,rot=(0,0,0)):
 bpy.ops.mesh.primitive_cylinder_add(vertices=40,radius=r,depth=d,location=loc,rotation=rot);o=put(bpy.context.object);o.name=n;o.data.materials.append(m)
 for p in o.data.polygons:p.use_smooth=True
 return o
def path(n,pts,r,m):
 cu=bpy.data.curves.new(n,'CURVE');cu.dimensions='3D';cu.bevel_depth=r;cu.bevel_resolution=2;sp=cu.splines.new('POLY');sp.points.add(len(pts)-1)
 for p,xyz in zip(sp.points,pts):p.co=(*xyz,1)
 o=bpy.data.objects.new(n,cu);COL[CUR].objects.link(o);o.data.materials.append(m);return o
def at(x,phi,z):return (RR*(1-math.cos(phi))+x*math.cos(phi),RR*math.sin(phi)-x*math.sin(phi),z)
def parent(o,root):o.parent=root;return o
CARS=[];BOGIES=[];AXLES=[];WHEEL_MESHES=[]
for car in range(2):
 CUR='EXTERIOR_TRAIN_MASTER';root=bpy.data.objects.new('CAR_'+str(car),None);COL[CUR].objects.link(root);CARS.append(root)
 parent(box('CAR_BODY_'+str(car),(0,0,2.22),(2.45,9.8,2.18),silver,.16),root)
 parent(box('CAB_REAR_'+str(car),(0,-4.92,2.15),(2.38,.18,2.12),white,.13),root)
 parent(box('CAB_FRONT_'+str(car),(0,4.92,2.15),(2.38,.18,2.12),white,.13),root)
 for yy in [-5.025,5.025]:
  parent(box('CAB_WINDSCREEN',(0,yy,2.67),(1.98,.028,.86),glass,.07),root)
  parent(box('BLANK_DESTINATION',(0,yy,3.19),(1.20,.028,.18),rubber,.018),root)
  parent(box('CAB_BLUE_BAND',(0,yy,1.87),(2.25,.03,.20),navy,.01),root)
  for xx in [-.85,.85]:parent(box('CAB_RED_TAILLIGHT',(xx,yy,1.58),(.17,.035,.095),red,.025),root)
  parent(box('CAB_COUPLER',(0,yy*1.045,.91),(.36,.45,.18),steel,.04),root)
 for xx in [-1.236,1.236]:
  parent(box('SIDE_STRIPE',(xx,0,1.73),(.025,9.55,.22),navy,.005),root)
  for yy in [-3.75,-2.25,-.75,.75,2.25,3.75]:parent(box('SIDE_WINDOW',(xx,yy,2.68),(.025,1.10,.78),glass,.045),root)
  for yy in [-3.0,0,3.0]:
   parent(box('DOOR_PANEL',(xx*1.005,yy,2.13),(.016,.62,1.66),silver,.025),root);parent(box('DOOR_GLAZING',(xx*1.011,yy,2.70),(.018,.49,.57),glass,.02),root)
 parent(box('ROOF',(0,0,3.40),(2.35,9.55,.26),silver,.13),root)
 for yy in [-2.5,1.9]:parent(box('ROOF_HVAC',(0,yy,3.62),(1.45,1.6,.25),white,.07),root)
 parent(box('UNDERFLOOR',(0,0,1.06),(1.96,8.8,.19),dark,.05),root)
 for xx in [-.42,.42]:
  ob=path('PANTOGRAPH',[(xx,.4,3.58),(xx,.85,3.93),(xx,.4,4.20),(xx,-.05,3.93),(xx,.4,3.58)],.022,steel);parent(ob,root)
 parent(box('PANTOGRAPH_CONTACT',(0,.4,4.2),(1.04,.12,.04),steel,.008),root)
 for bsign in [-1,1]:
  CUR='TRAIN_BOGIES';broot=bpy.data.objects.new('BOGIE_'+str(car)+'_'+str(bsign),None);COL[CUR].objects.link(broot);BOGIES.append((broot,car,bsign*3.2))
  for xx in [-1.00,1.00]:
   parent(box('BOGIE_SIDE_FRAME',(xx,0,.72),(.20,2.12,.25),dark,.055),broot)
   for yy in [-.7,.7]:
    parent(cylinder('AXLEBOX',(xx,yy,.51),.14,.16,steel,(0,math.pi/2,0)),broot)
    parent(cylinder('SUSPENSION_SPRING',(xx,yy,.98),.105,.29,dark),broot)
  parent(box('BOGIE_CROSS_FRAME',(0,0,.82),(1.86,.26,.21),dark,.04),broot)
  for yy in [-.7,.7]:
   axlepose=bpy.data.objects.new('EXT_AXLE_POSE',None);COL[CUR].objects.link(axlepose);rot=bpy.data.objects.new('EXT_COMMON_ANGLE',None);COL[CUR].objects.link(rot);rot.parent=axlepose;AXLES.append((axlepose,rot,car,bsign*3.2+yy))
   parent(cylinder('EXT_AXLE',(0,0,0),.075,2.25,steel,(0,math.pi/2,0)),rot)
   for side,center in [(1,-GAUGE),(-1,GAUGE)]:
    profile=[(-.14,.13),(-.14,.35),(-.13,.50-.06*.13),(.13,.50+.06*.13),(.15,.54),(.185,.54),(.19,.48),(.075,.31),(.075,.13)];vs=[];fs=[];seg=96
    for q,rr in profile:
     for j in range(seg):ang=math.tau*j/seg;vs.append((center+side*q,rr*math.sin(ang),rr*math.cos(ang)))
    for k in range(len(profile)):
     kk=(k+1)%len(profile)
     for j in range(seg):jj=(j+1)%seg;f=(k*seg+j,k*seg+jj,kk*seg+jj,kk*seg+j);fs.append(f if side==1 else tuple(reversed(f)))
    me=bpy.data.meshes.new('Exterior wheel with slight tread taper');me.from_pydata(vs,[],fs);me.update();ob=bpy.data.objects.new('EXT_WHEEL',me);COL[CUR].objects.link(ob);ob.data.materials.append(steel);ob.parent=rot;WHEEL_MESHES.append(ob)
    for f in me.polygons:f.use_smooth=True
CUR='EXTERIOR_TRACK'
for xr in [-GAUGE,GAUGE]:
 pts=[at(xr,-.36+1.22*j/200,-.045) for j in range(201)];path('EXTERIOR_RAIL',pts,.050,steel)
for j in range(103):
 phi=-.35+j*.012;ob=box('EXTERIOR_SLEEPER',at(0,phi,-.17),(2.25,.17,.12),wood,.015);ob.rotation_euler.z=-phi
path('CONTACT_WIRE',[at(0,-.35+1.22*j/100,4.22) for j in range(101)],.014,steel)
for j in range(5):
 phi=-.25+j*.24;px,py,pz=at(2.5,phi,2.6);cylinder('CATENARY_MAST',(px,py,2.6),.075,5.2,steel);o=box('CATENARY_ARM',at(1.0,phi,4.35),(3.1,.06,.07),steel,.005);o.rotation_euler.z=-phi
CUR='ENVIRONMENT';box('BALLAST_BED',(5,13,-.32),(32,95,.25),stone,.04);box('GRASS_GROUND',(0,20,-.55),(150,160,.18),grass,0)
for j in range(7):
 ob=box('BACKGROUND_HOUSE',(-7-j%2*4,10+j*8,1.8),(3.8,4.5,3.7),white,.08)
 for yy in [-1,1]:box('HOUSE_WINDOW',(ob.location.x+1.91,ob.location.y+yy,2.2),(.025,.75,1.0),glass,.01)
cd=bpy.data.cameras.new('EXTERIOR_CAMERA');cam=bpy.data.objects.new('EXTERIOR_CAMERA',cd);s.collection.objects.link(cam);s.camera=cam;cam.location=(-6.2,-13.0,4.0);cam.rotation_euler=(Vector((2.3,-2.0,1.5))-cam.location).to_track_quat('-Z','Y').to_euler();cd.type='PERSP';cd.lens=35;cd.sensor_fit='VERTICAL';cd.sensor_height=36;cd.clip_end=1200
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def pose(phi):
 for j,ob in enumerate(CARS):
  p=phi+j*10.8/RR;mid=Vector(at(0,p,0))+Vector((math.cos(p),-math.sin(p),0))*RR*(1-math.cos(3.2/RR));ob.location=mid;ob.rotation_euler.z=-p
 for ob,j,dist in BOGIES:
  p=phi+j*10.8/RR+dist/RR;ob.location=at(0,p,0);ob.rotation_euler.z=-p
 for ob,rot,j,dist in AXLES:
  p=phi+j*10.8/RR+dist/RR;ob.location=at(0,p,.50013);ob.rotation_euler.z=-p;rot.rotation_euler.x=-(phi*RR+dist)/.50
 bpy.context.view_layer.update()
def project(pt):
 p=world_to_camera_view(s,cam,Vector(pt));return [p.x*1080,(1-p.y)*1920]
def setcamera(c,t,phi):
 cd.lens=BG_LENS;cd.shift_x=cd.shift_y=0
 if c=='C01':cd.lens=35
 else:
  if c=='C02':
   z=ease(t/.85);target=Vector(at(-GAUGE,phi-3.2/RR,.46));lens=35+65*z;wanted=(.64,.45)
  else:
   z=ease(t/.35);target=Vector(at(-GAUGE,phi-3.2/RR,.46)).lerp(CARS[0].matrix_world@Vector((0,-4.9,2.1)),z);lens=100-65*z;wanted=(.64-.04*z,.45+.03*z)
  uv=world_to_camera_view(s,cam,target);fac=BG_LENS/lens;cx=uv.x-(wanted[0]-.5)*fac;cy=uv.y-(wanted[1]-.5)*fac
  if c=='C02':cx=(1-z)*.5+z*cx;cy=(1-z)*.5+z*cy
  cx=max(fac*.5,min(1-fac*.5,cx));cy=max(fac*.5,min(1-fac*.5,cy));cd.lens=lens
  p=cam.matrix_world@Vector(((cx-.5)*36/BG_LENS*9/16,(cy-.5)*36/BG_LENS,-1));u=world_to_camera_view(s,cam,p);cd.shift_x=.001;ux=world_to_camera_view(s,cam,p);cd.shift_x=0;cd.shift_y=.001;uy=world_to_camera_view(s,cam,p);cd.shift_y=0;cd.shift_x=(.5-u.x)/((ux.x-u.x)/.001);cd.shift_y=(.5-u.y)/((uy.y-u.y)/.001)
 return project(at(-GAUGE,phi-3.9/RR,.001))
pose(0);setcamera('C01',0,0);bpy.context.view_layer.update()
# Optional photographic environment: one fixed plate. All camera crops stay inside it.
env=R/'assets/EXTERIOR_ENV_PHOTO.png';skin=R/'assets/TRAIN_PHOTO_SURFACE.png';detail=R/'assets/BOGIE_PHOTO_SURFACE.png'
def photo_material(name,img):
 ma=bpy.data.materials.new(name);ma.use_nodes=True;nt=ma.node_tree;nt.nodes.clear();tx=nt.nodes.new('ShaderNodeTexImage');tx.image=img;tx.extension='EXTEND';em=nt.nodes.new('ShaderNodeEmission');nt.links.new(tx.outputs[0],em.inputs[0]);out=nt.nodes.new('ShaderNodeOutputMaterial');nt.links.new(em.outputs[0],out.inputs[0]);return ma
if env.exists():
 img=bpy.data.images.load(str(env));ma=photo_material('Photographic railway environment',img);CUR='PHOTO_BACKGROUND';bpy.ops.mesh.primitive_plane_add(size=1);plate=put(bpy.context.object);plate.name='EXTERIOR_PHOTO_PLATE';plate.location=cam.matrix_world@Vector((0,0,-500));plate.rotation_euler=cam.rotation_euler;plate.scale=(500*36/BG_LENS*9/16,500*36/BG_LENS,1);plate.data.materials.append(ma)
 for group in ['EXTERIOR_TRACK','ENVIRONMENT']:
  for ob in COL[group].objects:ob.hide_render=True
def register(group,imgpath,reference_cut,reference_t):
 if not imgpath.exists():return
 phi=.06+.025*reference_t if reference_cut=='C02' else 0;pose(phi);setcamera(reference_cut,reference_t,phi);bpy.context.view_layer.update();img=bpy.data.images.load(str(imgpath));ma=photo_material(group+' photographic surface',img)
 for ob in list(COL[group].objects):
  if ob.type=='CURVE':
   bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.convert(target='MESH')
  if ob.type!='MESH':continue
  uv=ob.data.uv_layers.active or ob.data.uv_layers.new()
  for poly in ob.data.polygons:
   for li in poly.loop_indices:
    p=world_to_camera_view(s,cam,ob.matrix_world@ob.data.vertices[ob.data.loops[li].vertex_index].co);uv.data[li].uv=(p.x,p.y)
  ob.data.materials.clear();ob.data.materials.append(ma)
# Reuse registered surface UV from the same local part of the nearest car/bogie.
# Offscreen cars never sample arbitrary black texture pixels.
def share_local_uv(group,template_roots):
 import re,hashlib
 def key(ob):
  if ob.type!='MESH':return None
  base=re.sub(r'\.\d+$','',ob.name)
  co=tuple(round(v,6) for vert in ob.data.vertices for v in vert.co)
  return (base,tuple(round(x,5) for x in ob.location),tuple(round(x,5) for x in ob.rotation_euler),hashlib.sha256(str(co).encode()).hexdigest())
 templates={}
 for ob in COL[group].objects:
  if ob.parent and ob.parent.name in template_roots and ob.type=='MESH':templates[key(ob)]=[tuple(x.uv) for x in ob.data.uv_layers.active.data]
 for ob in COL[group].objects:
  k=key(ob)
  if k in templates:
   for uv,xy in zip(ob.data.uv_layers.active.data,templates[k]):uv.uv=xy
register('EXTERIOR_TRAIN_MASTER',skin,'C01',0)
if skin.exists():share_local_uv('EXTERIOR_TRAIN_MASTER',{'CAR_0'})
if not (args.reference=='bogie' and not detail.exists()):register('TRAIN_BOGIES',detail if detail.exists() else skin,'C02' if detail.exists() else 'C01',1 if detail.exists() else 0)
if (skin.exists() or detail.exists()) and not (args.reference=='bogie' and not detail.exists()):
 nearest_angle=next(rot.name for _,rot,j,dist in AXLES if j==0 and abs(dist+3.9)<1e-5)
 share_local_uv('TRAIN_BOGIES',{'BOGIE_0_-1',nearest_angle})
# Reusable planar surface patches on side parts avoid baked duplicate windows/doors.
if skin.exists():
 for texture,names in [('STEEL',['CAR_BODY','DOOR_PANEL']),('GLASS',['SIDE_WINDOW','DOOR_GLAZING'])]:
  pp=R/'assets'/('TRAIN_'+texture+'_PATCH.png')
  if not pp.exists():continue
  ma=photo_material('Reusable '+texture.lower()+' photographic patch',bpy.data.images.load(str(pp)))
  for ob in COL['EXTERIOR_TRAIN_MASTER'].objects:
   if ob.type!='MESH' or not any(ob.name.startswith(n) for n in names):continue
   uv=ob.data.uv_layers.active or ob.data.uv_layers.new()
   lo=[min(v.co[k] for v in ob.data.vertices) for k in range(3)];hi=[max(v.co[k] for v in ob.data.vertices) for k in range(3)]
   for poly in ob.data.polygons:
    axes=sorted(range(3),key=lambda k:abs(poly.normal[k]))[:2]
    axes=sorted(axes)
    for li in poly.loop_indices:
     co=ob.data.vertices[ob.data.loops[li].vertex_index].co;uv.data[li].uv=tuple((co[k]-lo[k])/(hi[k]-lo[k]) for k in axes)
   ob.data.materials.clear();ob.data.materials.append(ma)
 for ob in COL['EXTERIOR_TRAIN_MASTER'].objects:
  if ob.type=='MESH' and ob.name.startswith('SIDE_STRIPE'):ob.data.materials.clear();ob.data.materials.append(navy)

if env.exists():sh.light='STUDIO';sh.color_type='TEXTURE';sh.show_shadows=False;sh.show_cavity=True;s.view_settings.exposure=.25
def state(c,t):
 phi=.06*t if c=='C01' else .06+.025*t if c=='C02' else .085+.085*t;pose(phi);target=setcamera(c,t,phi);return phi,target
if args.reference:
 if args.reference=='bogie' and not detail.exists():sh.light='STUDIO';sh.show_cavity=True
 c='C02' if args.reference=='bogie' else 'C01';t=1 if c=='C02' else 0;state(c,t)
 if args.reference=='empty':
  cd.lens=BG_LENS;cd.shift_x=cd.shift_y=0
  for gr in ['EXTERIOR_TRAIN_MASTER','TRAIN_BOGIES']:
   for ob in COL[gr].objects:ob.hide_render=True
 dest=R/'assets'/('EXTERIOR_REFERENCE_'+args.reference.upper()+'.png');s.render.filepath=str(dest);bpy.ops.render.render(write_still=True);print('REFERENCE',dest)
else:
 for c in ([args.cut] if args.cut else ['C01','C02','C08']):
  for ob in bpy.data.objects:ob.animation_data_clear()
  cd.animation_data_clear();s.frame_start=1;s.frame_end=N[c];anchors=[]
  for i in range(N[c]):
   s.frame_set(i+1);phi,target=state(c,i/(N[c]-1));anchors.append({'target':target,'exterior_phi':phi,'lens':cd.lens,'shift':[cd.shift_x,cd.shift_y]})
   for ob in CARS+[x[0] for x in BOGIES]+[x[0] for x in AXLES]+[x[1] for x in AXLES]:
    ob.keyframe_insert('location',frame=i+1);ob.keyframe_insert('rotation_euler',frame=i+1)
   for prop in ['lens','shift_x','shift_y']:cd.keyframe_insert(prop,frame=i+1)
  for im in bpy.data.images:
   if im.source=='FILE':im.filepath='//../../assets/'+Path(im.filepath).name
  s.frame_set(1);state(c,0);bpy.ops.wm.save_as_mainfile(filepath=str(R/'source/blender'/f'{c}.blend'),compress=True);(R/'source'/f'{c}_anchors.json').write_text(json.dumps(anchors));dest=R/'source/frames'/c;dest.mkdir(parents=True,exist_ok=True)
  if args.prepare:continue
  for i in ([args.still] if args.still is not None else range(N[c])):
   f=dest/f'{i:04}.png'
   if f.exists() and args.still is None:continue
   s.frame_set(i+1);state(c,i/(N[c]-1));s.render.filepath=str(f);bpy.ops.render.render(write_still=True)
  print('COMPLETE',c,flush=True)
