import bpy,sys,json,math,hashlib
import numpy as np
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'source'))
from physics import *
checks=[];samples=[]
def ck(n,ok,**kw):checks.append(dict(check=n,status='PASS' if ok else 'FAIL',**kw))
poly=[]
for j in range(17):x=-.046+.092*j/16;poly.append((x,-RHO+math.sqrt(RHO*RHO-x*x)))
poly +=[(.046,-.062),(.024,-.080),(.012,-.082),(.012,-.180),(.079,-.203),(.079,-.222),(-.079,-.222),(-.079,-.203),(-.012,-.180),(-.012,-.082),(-.024,-.080),(-.046,-.062)]
def penetration(x,z):
 inside=np.zeros(x.shape,dtype=bool);dist=np.full(x.shape,1e9)
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ax,az=a;bx,bz=b;dx=bx-ax;dz=bz-az;t=np.clip(((x-ax)*dx+(z-az)*dz)/(dx*dx+dz*dz),0,1);dist=np.minimum(dist,np.hypot(x-(ax+t*dx),z-(az+t*dz)));inside^=((az>z)!=(bz>z))&(x<(bx-ax)*(z-az)/(bz-az+1e-30)+ax)
 return np.where(inside,dist,0)
for c in ['C06','C07']:
 bpy.ops.wm.open_mainfile(filepath=str(R/'source/blender'/f'{c}.blend'));s=bpy.context.scene;A=json.loads((R/'source'/f'{c}_anchors.json').read_text());wheelhash=[];max_pen=0;max_res=0;max_contact=0;flange_clear=1
 base={n:np.array([[*v.co,1] for v in bpy.data.objects[n].data.vertices]) for n in ['WHEEL_OUTER','WHEEL_INNER']}
 hashes={n:hashlib.sha256(base[n].tobytes()).hexdigest() for n in base}
 for i in range(0,len(A),3):
  s.frame_set(i+1);bpy.context.view_layer.update();d=A[i]['state'];max_res=max(max_res,d['residual'])
  for n,v in base.items():
   ob=bpy.data.objects[n];ckscale=all(abs(x-1)<1e-7 for x in ob.scale);assert ckscale
   w=v@np.array(ob.matrix_world).T;rad=np.hypot(w[:,0]-CURVE_R,w[:,1]);cross_x=CURVE_R-rad
   for xr in [-G,G]:max_pen=max(max_pen,float(penetration(cross_x-xr,w[:,2]).max()))
  for p in d['contacts']:
   x,_,z=p['point'];max_contact=max(max_contact,abs(math.hypot(x-p['rail_x'],z+RHO)-RHO));flange_clear=min(flange_clear,.155-abs(p['u']))
 ck(c+' wheel vertices clear crowned I rails',max_pen<.00020,max_penetration=max_pen,tolerance=.00020)
 ck(c+' exact analytic tangencies at both contacts',max_res<1e-10 and max_contact<1e-10,max_residual=max_res,max_circle_error=max_contact)
 ck(c+' contact on tread, away from flange',flange_clear>.02,min_axial_margin=flange_clear)
 ck(c+' single rigid ANGLE parent',all(bpy.data.objects[n].parent.name=='ANGLE' for n in ['WHEEL_OUTER','WHEEL_INNER','AXLE','ROTATION_MARKER_OUTER','ROTATION_MARKER_INNER']))
 ck(c+' outer is screen left throughout',all(x['contacts'][0][0]<x['contacts'][1][0] for x in A))
 samples.append({'cut':c,'geometry_hashes':hashes,'start':A[0]['state'],'end':A[-1]['state']})
 if c=='C06':
  ck('C06 entire axle translates outward',A[0]['state']['delta']==0 and abs(A[-1]['state']['delta']-SHIFT)<1e-8)
  ck('C06 outer rolling radius grows, inner shrinks',A[-1]['state']['contacts'][0]['radius']>A[0]['state']['contacts'][0]['radius'] and A[-1]['state']['contacts'][1]['radius']<A[0]['state']['contacts'][1]['radius'])
 else:
  ck('C07 common angular travel exactly 360 degrees',abs(A[-1]['state']['angle']-A[0]['state']['angle']+math.tau)<1e-9)
  ck('C07 both distances equal 2pi times own radius',all(abs(p['distance']-math.tau*p['radius'])<1e-8 for p in A[-1]['state']['contacts']))
  ck('C07 outside travels farther',A[-1]['state']['contacts'][0]['distance']>A[-1]['state']['contacts'][1]['distance'])
ck('C06-C07 same rigid wheel geometry',samples[0]['geometry_hashes']==samples[1]['geometry_hashes'])
ck('C06-C07 same final/start pose',all(abs(samples[0]['end'][k]-samples[1]['start'][k])<1e-9 for k in ['delta','beta','height','angle','phi']))
result={'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'samples':samples,'limitations':'Illustrative matched-radius case; conicity exaggerated. Not all real curves are pure rolling; real creepage/slip, suspension and flange forces remain relevant.'};(R/'qc/core-geometry.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'checks':len(checks),'failed':[x for x in checks if x['status']!='PASS']}));assert result['status']=='PASS'
