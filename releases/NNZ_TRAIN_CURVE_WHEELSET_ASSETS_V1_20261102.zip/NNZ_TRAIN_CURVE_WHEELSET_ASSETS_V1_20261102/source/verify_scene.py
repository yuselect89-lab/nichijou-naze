import bpy,json,hashlib,sys,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'source'))
from physics import *
rows=json.loads((R/'source/timing.json').read_text());checks=[];geo={};edges={};exterior={}
def ck(n,ok,**kw):checks.append(dict(check=n,status='PASS' if ok else 'FAIL',**kw))
def meshhash(ob):return hashlib.sha256(json.dumps([[round(v,6) for v in p.co] for p in ob.data.vertices]).encode()).hexdigest()
for row in rows:
 c=row['cut_id'];bpy.ops.wm.open_mainfile(filepath=str(R/'source/blender'/f'{c}.blend'));s=bpy.context.scene
 ck(c+' native portrait30 and exact source duration',(s.render.resolution_x,s.render.resolution_y,s.render.resolution_percentage,s.render.fps,s.frame_end)==(1080,1920,100,30,row['frames']))
 images=[im for im in bpy.data.images if im.source=='FILE'];ck(c+' portable relative resources',all(im.filepath.startswith('//') and Path(bpy.path.abspath(im.filepath)).is_file() for im in images))
 A=json.loads((R/'source'/f'{c}_anchors.json').read_text());ck(c+' one anchor per actual frame',len(A)==row['frames'])
 if c in ['C03','C04','C05','C06','C07']:
  ck(c+' common named master collections',all(x in bpy.data.collections for x in ['WHEELSET_MASTER','RAIL_CURVE_MASTER','CONTACT_GUIDES']))
  ck(c+' rigid one axle common ANGLE',all(bpy.data.objects[n].parent.name=='ANGLE' for n in ['WHEEL_OUTER','WHEEL_INNER','AXLE']))
  geo[c]={n:meshhash(bpy.data.objects[n]) for n in ['WHEEL_OUTER','WHEEL_INNER','AXLE','RAIL_OUTER','RAIL_INNER']}
  ck(c+' contact roles never reverse',all(x['contacts'][0][0]<x['contacts'][1][0] for x in A))
  for frame,which in [(1,'first'),(row['frames'],'last')]:
   s.frame_set(frame);bpy.context.view_layer.update();edges.setdefault(c,{})[which]={'camera':[float(x) for rr in s.camera.matrix_world for x in rr]+[s.camera.data.ortho_scale],'pose':[float(x) for rr in bpy.data.objects['WHEELSET_POSE'].matrix_world for x in rr],'angle':bpy.data.objects['ANGLE'].rotation_euler.x}
  if c=='C03':ck('C03 spins on inspection supports, not stationary tread on rails',not bpy.data.objects['CRADLE_PEDESTAL'].hide_render and bpy.data.objects['RAIL_OUTER'].hide_render)
 else:
  ck(c+' same two-car moving exterior master',all(n in bpy.data.objects for n in ['CAR_0','CAR_1','EXTERIOR_PHOTO_PLATE']))
  wheels=[o for o in bpy.data.objects if o.type=='MESH' and o.name.startswith('EXT_WHEEL')];angles=[o for o in bpy.data.objects if o.name.startswith('EXT_COMMON_ANGLE')]
  ck(c+' 8 rigid axles and16 steel wheels',len(angles)==8 and len(wheels)==16 and all(o.parent in angles for o in wheels))
  exterior[c]={o.name:meshhash(o) for o in bpy.data.collections['EXTERIOR_TRAIN_MASTER'].objects if o.type=='MESH'}
  cams=[];positions=[];uvmin=1.;uvmax=0.
  for i in range(row['frames']):
   s.frame_set(i+1);bpy.context.view_layer.update();cam=s.camera;plate=bpy.data.objects['EXTERIOR_PHOTO_PLATE'];cams.append(tuple(cam.location)+tuple(cam.rotation_euler));positions.append(tuple(bpy.data.objects['CAR_0'].location))
   for v in cam.data.view_frame(scene=s):
    point=plate.matrix_world.inverted()@(cam.matrix_world@(v*(-500/v.z)));u=point.x+.5;v2=point.y+.5;uvmin=min(uvmin,u,v2);uvmax=max(uvmax,u,v2)
  ck(c+' fixed pinhole with lens/crop only',len(set(cams))==1)
  ck(c+' physical train moves every frame',len(set(positions))==row['frames'] and A[-1]['exterior_phi']>A[0]['exterior_phi'])
  ck(c+' all camera rays remain inside original photographic plate',uvmin>=-1e-5 and uvmax<=1+1e-5,min_uv=uvmin,max_uv=uvmax)
  exterior[c]['camera_pose']=cams[0]
ck('C03-C07 identical rigid wheelset and crowned rail meshes',all(g==geo['C03'] for g in geo.values()))
ck('C01 C02 C08 identical vehicle geometry',exterior['C01']==exterior['C02']==exterior['C08'])
for a,b in [('C04','C05'),('C05','C06'),('C06','C07')]:
 err=max(abs(x-y) for x,y in zip(edges[a]['last']['camera'],edges[b]['first']['camera']));ck(a+' to '+b+' camera continuity',err<1e-5,error=err)
ck('C06 to C07 exact common axle pose',max(abs(x-y) for x,y in zip(edges['C06']['last']['pose'],edges['C07']['first']['pose']))<1e-6 and abs(edges['C06']['last']['angle']-edges['C07']['first']['angle'])<1e-6)
result={'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'edges':edges,'hashes':{f'source/blender/{r["cut_id"]}.blend':hashlib.sha256((R/f'source/blender/{r["cut_id"]}.blend').read_bytes()).hexdigest() for r in rows},'limitations':'Source and analytic verification. Actual encoded visual review and full playback are separate. Exterior rail appearance uses a registered AI photo plate; core contact geometry uses native crowned I rails.'}
(R/'qc/scene.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'checks':len(checks),'failed':[x for x in checks if x['status']=='FAIL']}));assert result['status']=='PASS'
