from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageChops,ImageFilter
import json,math,subprocess,argparse,time,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from physics import *
R=Path(__file__).resolve().parents[1];T=json.loads((R/'source/timing.json').read_text());N={r['cut_id']:r['frames'] for r in T};A={};cache={}
TEXT={'C01':('',''),'C02':('車輪の形',''),'C03':('左右は同じ回転','1本の車軸'),'C04':('外側のほうが長い','外側 ／ 内側'),'C05':('触れる面が斜め','踏面勾配（模式拡大）'),'C06':('触れる位置が変わる','外側：大 ／ 内側：小'),'C07':('同じ1回転でも\n距離が違う','外側：長い ／ 内側：短い'),'C08':('カーブを助ける車輪の形','')}
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def font(n,b):
 k=(n,b)
 if k not in cache:cache[k]=ImageFont.truetype(str(R/('public/series/v1/NotoSansCJKjp-Bold.otf' if b else 'assets/Regular.ttc')),n)
 return cache[k]
def word(d,xy,txt,n=62,b=True):
 f=font(n,b);w=d.textlength(txt,font=f);x,y=xy;d.rounded_rectangle((x-w/2-18,y-n*.65-12,x+w/2+18,y+n*.65+12),radius=12,fill='#fffffff0');d.text(xy,txt,font=f,anchor='mm',fill='#273b44')
SPR={p:Image.open(R/f'assets/CHAR_{p}.png').convert('RGBA').crop((260,0,1280,960)).resize((500,470),Image.Resampling.LANCZOS) for p in ['think','surprise','happy']}
for pic in SPR.values():
 mask=Image.new('L',pic.size,255)
 for y in range(395,470):
  for x in range(500):mask.putpixel((x,y),int(255*(469-y)/74))
 pic.putalpha(ImageChops.multiply(pic.getchannel('A'),mask))

def inset(c,i,side):
 a=A[c][i]['state'];p=a['contacts'][side];w,h=440,290;im=Image.new('RGBA',(w,h),(250,251,252,247));d=ImageDraw.Draw(im);d.rounded_rectangle((1,1,w-2,h-2),radius=14,outline='#9baab1',width=2)
 def pos(u,z):return (w/2+u*650,65+(-z-.33)*650)
 label='外側の接点' if side==0 else '内側の接点';color='#ad7628' if side==0 else '#237c8c';d.text((w/2,29),label,font=font(35,True),anchor='mm',fill='#273b44')
 sign=1 if side==0 else -1;profile=[(-.18,-.37),(-.16,-(R0-K*.16)),(.155,-(R0+K*.155)),(.175,-.605),(.205,-.605),(.217,-.53)]
 pts=[pos(sign*u,z) for u,z in profile]
 if side==1:pts.reverse()
 poly=[(pts[0][0],56)]+pts+[(pts[-1][0],56)];d.polygon(poly,fill='#c3ccd1');d.line(pts,fill='#4c6470',width=4)
 rcx,rcz=p['rail_center_local'];rx,ry=pos(rcx,rcz);rad=RHO*650;# isotropic section scale is corrected for the two display axes
 rz=RHO*650;d.ellipse((rx-rad,ry-rz,rx+rad,ry+rz),fill='#a5b6bf',outline='#576d78',width=3)
 x,y=pos(p['u'],-p['radius']);d.ellipse((x-9,y-9,x+9,y+9),fill=color,outline='white',width=2)
 return im

def overlay(c,i,kind):
 t=i/(N[c]-1);sec=i/30;im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im);a=A[c][i];core=c in ['C03','C04','C05','C06','C07']
 if kind=='labels':
  p,q=TEXT[c]
  for k,line in enumerate(p.split('\n')):
   if line:word(d,(540,205+76*k if '\n' in p else 220),line,62)
  if q:word(d,(540,385 if '\n' in p else 325),q,34,False)
  if core:
   if c in ['C05','C06','C07']:word(d,(540,1470),'模式的誇張 ／ 現実はすべりも生じる',30,False)
   else:word(d,(540,405),'模式図',32,False)
  if c in ['C04','C06','C07']:
   word(d,(200,465),'外側',38);word(d,(860,465),'内側',38)
  if c=='C07':
   word(d,(540,465),str(round(-a['state']['angle']*180/math.pi))+'°',38)
   word(d,(540,1110),'1回転で進む距離',36,False)
   word(d,(200,1190),'外側',32,False);word(d,(200,1320),'内側',32,False)
  return im
 if kind=='marks':
  if c in ['C02','C08'] and 'target' in a:
   alpha=math.sin(math.pi*t);x,y=a['target'];rr=70;d.ellipse((x-rr,y-rr,x+rr,y+rr),outline=(190,145,52,int(220*alpha)),width=4)
  if c in ['C03','C07']:
   for x,y in a.get('rotation_markers',[]):d.ellipse((x-10,y-10,x+10,y+10),fill='#e5b246',outline='#fff8dd',width=2)
  if c=='C06':
   for j,(p,q) in enumerate(zip(a['axes'],a['contacts'])):
    col='#b37b27' if j==0 else '#24869a';d.line([tuple(p),tuple(q)],fill='#ffffff',width=9);d.line([tuple(p),tuple(q)],fill=col,width=4);x,y=q;d.ellipse((x-13,y-13,x+13,y+13),fill=col,outline='white',width=3)
    if a['state']['delta']<-.025:word(d,((p[0]+q[0])/2+(-40 if j==0 else 40),(p[1]+q[1])/2),'大' if j==0 else '小',38)
   im.alpha_composite(inset(c,i,0),(70,1160));im.alpha_composite(inset(c,i,1),(570,1160))
  if c=='C05':
   pic=inset(c,i,0).resize((704,464),Image.Resampling.LANCZOS);im.alpha_composite(pic,(160,1000))
  if c=='C07':
   st=a['state'];maxdist=math.tau*FINAL['contacts'][0]['radius']
   for j,p in enumerate(st['contacts']):
    x=220;y=1240+130*j;length=600*p['distance']/maxdist;d.line((x,y,x+600,y),fill='#ffffffdd',width=13);d.line((x,y,x+length,y),fill='#b67f2d' if j==0 else '#278395',width=8)
    if length>4:d.line((x+length,y-14,x+length,y+14),fill='#394e5a',width=3)
  return im
 if kind=='character':
  pose=None;alpha=0
  if c=='C01':pose='think';alpha=ease((t-.68)/.15)
  if c=='C02':pose='surprise';alpha=1-ease((t-.13)/.13)
  if c=='C08':pose='happy';alpha=ease((t-.5)/.18)
  if pose:
   p=SPR[pose].copy();p.putalpha(p.getchannel('A').point(lambda x:int(x*alpha)));im.alpha_composite(p,(25,1000))
  return im

def layer(c,kind):
 p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgba','-s','1080x1920','-r','30','-i','-','-an','-c:v','libvpx-vp9','-pix_fmt','yuva420p','-b:v','0','-crf','20','-deadline','good','-cpu-used','5','-auto-alt-ref','0','-threads','2',str(R/'cuts'/c/(kind+'.webm'))],stdin=subprocess.PIPE)
 try:
  for i in range(N[c]):p.stdin.write(overlay(c,i,kind).tobytes())
 finally:p.stdin.close()
 assert p.wait()==0
def compose(c,steam_only=False):
 d=R/'cuts'/c;d.mkdir(parents=True,exist_ok=True);A[c]=json.loads((R/'source'/f'{c}_anchors.json').read_text())
 if not steam_only:
  subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-i',str(R/'source/frames'/c/'%04d.png'),'-frames:v',str(N[c]),'-an','-c:v','libx264','-crf','16','-preset','fast','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(d/'scene.mp4')],check=True)
  for k in ['labels','marks','character']:layer(c,k)
 else:layer(c,'marks')
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(d/'scene.mp4'),'-c:v','libvpx-vp9','-i',str(d/'labels.webm'),'-c:v','libvpx-vp9','-i',str(d/'marks.webm'),'-c:v','libvpx-vp9','-i',str(d/'character.webm'),'-filter_complex','[0:v][1:v]overlay=format=auto[a];[a][2:v]overlay=format=auto[b];[b][3:v]overlay=format=auto,format=yuv420p[v]','-map','[v]','-r','30','-frames:v',str(N[c]),'-an','-c:v','libx264','-crf','16','-preset','fast','-threads','2','-movflags','+faststart',str(d/'asset.mp4')],check=True)
 print('COMPLETE',c,flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--cut');ap.add_argument('--wait',action='store_true');ap.add_argument('--start-cut');ap.add_argument('--steam-only',action='store_true');a=ap.parse_args()
 for c in ([a.cut] if a.cut else list(N)[list(N).index(a.start_cut):] if a.start_cut else list(N)):
  if a.wait:
   while True:
    try:
     for i in range(N[c]):
      with Image.open(R/'source/frames'/c/f'{i:04}.png') as im:im.load()
     break
    except (OSError,FileNotFoundError,SyntaxError):time.sleep(2)
  compose(c,a.steam_only)
