import bpy,math,json,sys,argparse,shutil
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'source'))
from physics import *
from bpy_extras.object_utils import world_to_camera_view
ap=argparse.ArgumentParser();ap.add_argument('--cut');ap.add_argument('--still',type=int);ap.add_argument('--prepare',action='store_true');a=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
T=json.loads((R/'source/timing.json').read_text());N={x['cut_id']:x['frames'] for x in T}
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);s=bpy.context.scene;s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100;s.render.fps=30;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.compression=15;s.render.threads_mode='FIXED';s.render.threads=4;s.display.render_aa='8';sh=s.display.shading;sh.light='STUDIO';sh.studio_light='outdoor.sl';sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.curvature_ridge_factor=1.2;sh.curvature_valley_factor=1.1;sh.show_specular_highlight=True;s.world.color=(.95,.96,.97);s.view_settings.view_transform='Standard';s.view_settings.look='None';s.view_settings.exposure=.65
C={}
for n in ['WHEELSET_MASTER','RAIL_CURVE_MASTER','CONTACT_GUIDES','INSPECTION_CRADLE','ENVIRONMENT']:
 c=bpy.data.collections.new(n);s.collection.children.link(c);C[n]=c
CUR='WHEELSET_MASTER'
def put(o):
 for c in list(o.users_collection):c.objects.unlink(o)
 C[CUR].objects.link(o);o['part_id']=CUR;o['version']='1.0.0';return o
def mat(n,color,metal=0):
 m=bpy.data.materials.new(n);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes['Principled BSDF'];p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=.28 if metal else .55;return m
steel=mat('Polished steel tread',(.40,.47,.53),1);web=mat('Cast steel wheel web',(.13,.18,.22),.8);flange=mat('Steel flange',(.30,.36,.41),1);gold=mat('Outer annotation',(.70,.40,.10));cyan=mat('Inner annotation',(.06,.35,.42));white=mat('Studio white',(.89,.91,.92));sleeperM=mat('Neutral sleepers',(.59,.63,.65));black=mat('Bearing inserts',(.08,.11,.13))
def box(n,loc,dim,m,b=.015):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=put(bpy.context.object);o.name=n;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if b:q=o.modifiers.new('Manufactured edge','BEVEL');q.width=b;q.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return o
def cyl(n,loc,rad,dep,m):
 bpy.ops.mesh.primitive_cylinder_add(vertices=64,radius=rad,depth=dep,location=loc,rotation=(0,math.pi/2,0));o=put(bpy.context.object);o.name=n;o.data.materials.append(m);q=o.modifiers.new('Edge radius','BEVEL');q.width=.006;q.segments=2;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 for p in o.data.polygons:p.use_smooth=True
 return o
def sphere(n,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=10,radius=.021);o=put(bpy.context.object);o.name=n;o.data.materials.append(m);return o
def curve(n,count,r,m):
 cu=bpy.data.curves.new(n,'CURVE');cu.dimensions='3D';cu.bevel_depth=r;cu.bevel_resolution=2;sp=cu.splines.new('POLY');sp.points.add(count-1);o=bpy.data.objects.new(n,cu);C[CUR].objects.link(o);o.data.materials.append(m);return o
root=bpy.data.objects.new('WHEELSET_POSE',None);C[CUR].objects.link(root);roll=bpy.data.objects.new('WHEELSET_ROLL',None);C[CUR].objects.link(roll);roll.parent=root;spin=bpy.data.objects.new('ANGLE',None);C[CUR].objects.link(spin);spin.parent=roll
axle=cyl('AXLE',(0,0,0),.080,2.30,steel);axle.parent=spin
PROFILE=[(-.18,.15),(-.18,.37),(-.16,R0-K*.16),(.155,R0+K*.155),(.175,.605),(.205,.605),(.217,.53),(.105,.34),(.105,.15)]
WHEELS=[];MARKERS=[]
for side,center in [(1,-G),(-1,G)]:
 name='OUTER' if side==1 else 'INNER';vs=[];fs=[];mi=[];segments=384
 for q,r in PROFILE:
  for j in range(segments):ang=math.tau*j/segments;vs.append((center+side*q,r*math.sin(ang),r*math.cos(ang)))
 for j in range(len(PROFILE)):
  k=(j+1)%len(PROFILE)
  for p in range(segments):pp=(p+1)%segments;f=(j*segments+p,j*segments+pp,k*segments+pp,k*segments+p);fs.append(f if side==1 else tuple(reversed(f)));mi.append(0 if j==2 else 2 if 3<=j<=5 else 1)
 me=bpy.data.meshes.new('Rigid '+name+' wheel profile');me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new('WHEEL_'+name,me);C[CUR].objects.link(o);o.parent=spin
 for m in [steel,web,flange]:o.data.materials.append(m)
 for p,i in zip(me.polygons,mi):p.material_index=i;p.use_smooth=True
 o['role']=name;o['tread_slope']=side*K;o['conicity_exaggerated']=True;WHEELS.append(o)
 hub=cyl('HUB_'+name,(center,0,0),.15,.39,steel);hub.parent=spin
 # Both markers face the same +X camera side, and share the one ANGLE parent.
 mark=sphere('ROTATION_MARKER_'+name,gold);mark.parent=spin;mark.location=(center+(.112 if side==1 else .183),-.28,.12);mark.scale=(.6,1,1);MARKERS.append(mark)
 for j in range(8):
  ang=j*math.tau/8;o=cyl('BOLT_'+name,(center+(.111 if side==1 else .183),.23*math.sin(ang),.23*math.cos(ang)),.018,.018,steel);o.parent=spin
CUR='RAIL_CURVE_MASTER'
rail_profile=[]
for j in range(17):
 x=-.046+.092*j/16;rail_profile.append((x,-RHO+math.sqrt(RHO*RHO-x*x)))
rail_profile +=[(.046,-.062),(.024,-.080),(.012,-.082),(.012,-.180),(.079,-.203),(.079,-.222),(-.079,-.222),(-.079,-.203),(-.012,-.180),(-.012,-.082),(-.024,-.080),(-.046,-.062)]
for name,xrail in [('OUTER',-G),('INNER',G)]:
 vs=[];fs=[];steps=144
 for j in range(steps+1):
  phi=-.32+1.05*j/steps
  for xx,z in rail_profile:vs.append(world((xrail+xx,0,z),phi))
 w=len(rail_profile)
 for j in range(steps):
  for k in range(w):kk=(k+1)%w;fs.append((j*w+k,j*w+kk,(j+1)*w+kk,(j+1)*w+k))
 fs.extend([tuple(reversed(tuple(range(w)))),tuple(steps*w+k for k in range(w))]);me=bpy.data.meshes.new(name+' crowned I rail');me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new('RAIL_'+name,me);C[CUR].objects.link(o);o.data.materials.append(steel)
 for p in me.polygons:p.use_smooth=True
 for k in range(23):
  phi=-.30+k*.045
  if name=='OUTER':
   loc=world((0,0,-.282),phi);ob=box('SLEEPER',loc,(2.15,.16,.12),sleeperM);ob.rotation_euler.z=-phi
CUR='ENVIRONMENT';ground=box('STUDIO_GROUND',(0,0,-.382),(150,150,.08),white,0)
CUR='INSPECTION_CRADLE'
for xx in [-1.08,1.08]:
 box('CRADLE_PEDESTAL',(xx,0,.038),(.24,.40,.76),white);cyl('CRADLE_BEARING',(xx,0,contact_state(0)['height']),.115,.15,black)
CUR='CONTACT_GUIDES';contacts=[sphere('CONTACT_OUTER',gold),sphere('CONTACT_INNER',cyan)];paths=[curve('DISTANCE_OUTER',101,.014,gold),curve('DISTANCE_INNER',101,.014,cyan)]
cd=bpy.data.cameras.new('CAMERA');cam=bpy.data.objects.new('CAMERA',cd);s.collection.objects.link(cam);s.camera=cam;cd.type='ORTHO'
Q=(2.8,-5.2,2.5,4.8,.10,0,.10);TOP=(2.4,-4.6,5.3,6.8,.10,.60,-.10);CLOSE=(-1.8,-3.8,1.4,2.65,-G,0,.15);PAIR=(2.5,-5.8,2.6,4.8,.10,.10,-.08);DIST=(1.6,-5.4,4.7,5.6,.10,.55,0)
def lerp(a,b,t):return tuple(x+(y-x)*t for x,y in zip(a,b))
def camera(q,phi=0):
 eye=world(q[:3],phi);target=world(q[4:],phi);cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cd.ortho_scale=q[3]
def apply(c,t):
 d=state(c,t);phi=d['phi'];root.location=world((d['delta'],0,d['height']),phi);root.rotation_euler.z=-phi;roll.rotation_euler.y=-d['beta'];spin.rotation_euler.x=d['angle'];root['OUTER_SIDE']='negative local X; left screen';spin['angle_radians']=d['angle']
 if c=='C03':q=Q
 elif c=='C04':q=lerp(Q,TOP,ease(t))
 elif c=='C05':q=lerp(TOP,CLOSE,ease(t))
 elif c=='C06':q=lerp(CLOSE,PAIR,ease(t/.23))
 else:q=lerp(PAIR,DIST,ease(t/.12))
 camera(q,phi)
 for i,(ob,p) in enumerate(zip(contacts,d['contacts'])):ob.location=p['world_point']
 for i,ob in enumerate(paths):
  end=d['phi'] if c=='C07' else .34*ease(t) if c=='C04' else 0
  px=d['contacts'][i]['point'][0]
  for j,p in enumerate(ob.data.splines[0].points):p.co=(*world((px,0,.008),end*j/100),1)
 for ob in C['INSPECTION_CRADLE'].objects:ob.hide_render=c!='C03'
 for ob in C['RAIL_CURVE_MASTER'].objects:ob.hide_render=c=='C03'
 for ob in contacts:ob.hide_render=c not in ['C05','C06','C07']
 for ob in paths:ob.hide_render=c not in ['C04','C07']
 bpy.context.view_layer.update();return d
def project(pt):
 p=world_to_camera_view(s,cam,Vector(pt));return [p.x*1080,(1-p.y)*1920]
for c in ([a.cut] if a.cut else ['C03','C04','C05','C06','C07']):
 if c not in ['C03','C04','C05','C06','C07']:continue
 for ob in bpy.data.objects:ob.animation_data_clear()
 for ob in paths:ob.data.animation_data_clear()
 cd.animation_data_clear();s.frame_start=1;s.frame_end=N[c];anchors=[]
 for i in range(N[c]):
  s.frame_set(i+1);d=apply(c,i/(N[c]-1))
  for ob in [root,roll,spin,cam]+contacts:
   for pr in ['location','rotation_euler','hide_render']:ob.keyframe_insert(pr,frame=i+1)
  cd.keyframe_insert('ortho_scale',frame=i+1)
  for ob in paths:
   ob.keyframe_insert('hide_render',frame=i+1)
   for point in ob.data.splines[0].points:point.keyframe_insert('co',frame=i+1)
  for gr in ['INSPECTION_CRADLE','RAIL_CURVE_MASTER']:
   for ob in C[gr].objects:ob.keyframe_insert('hide_render',frame=i+1)
  for ob in contacts:ob.keyframe_insert('hide_render',frame=i+1)
  anchors.append({'state':d,'contacts':[project(p['world_point']) for p in d['contacts']],'axes':[project(p['world_axis']) for p in d['contacts']],'rotation_markers':[project(x.matrix_world.translation) for x in MARKERS],'role_screen_order':['OUTER','INNER']})
 s.frame_set(1);apply(c,0);dest=R/'source/frames'/c;dest.mkdir(parents=True,exist_ok=True);bpy.ops.wm.save_as_mainfile(filepath=str(R/'source/blender'/f'{c}.blend'),compress=True);(R/'source'/f'{c}_anchors.json').write_text(json.dumps(anchors))
 if a.prepare:continue
 hold_cache={}
 for i in ([a.still] if a.still is not None else range(N[c])):
  p=dest/f'{i:04}.png'
  hold=('END' if c=='C06' and i/(N[c]-1)>=.8 else 'END' if c in ['C07','C03'] and i/(N[c]-1)>=.85 else 'START' if c=='C03' and i/(N[c]-1)<=.25 else None)
  if p.exists() and a.still is None:
   if hold:hold_cache[hold]=p
   continue
  if hold and hold in hold_cache:shutil.copyfile(hold_cache[hold],p);continue
  s.frame_set(i+1);apply(c,i/(N[c]-1));s.render.filepath=str(p);bpy.ops.render.render(write_still=True)
  if hold:hold_cache[hold]=p
 print('COMPLETE',c,flush=True)
