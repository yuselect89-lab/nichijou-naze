"""Illustrative conical wheelset / crowned curved rail contact geometry.
Units are model units, not a reconstruction of a particular Japanese vehicle.
Conicity and lateral travel are exaggerated and labeled in the footage.
"""
import math
G=.72;R0=.50;K=.32;RHO=.07;SHIFT=-.075;D=math.sqrt(1+K*K)
def contact_state(delta):
 beta=0.;H=R0+RHO*D;C=R0+K*G
 def residual(b,h):return ((h+K*G)*math.cos(b)-delta*math.sin(b)-C-RHO*D,K*delta*math.cos(b)+(K*h-G)*math.sin(b))
 for _ in range(12):
  f,g=residual(beta,H);e=1e-6;fb,gb=residual(beta+e,H);fh,gh=residual(beta,H+e);a=(fb-f)/e;b=(fh-f)/e;c=(gb-g)/e;d=(gh-g)/e;det=a*d-b*c;beta-=(d*f-b*g)/det;H-=(-c*f+a*g)/det
 z=H-RHO;contacts=[]
 for side,xrail in [(1,-G),(-1,G)]:
  nx=(side*K*math.cos(beta)-math.sin(beta))/D;nz=(math.cos(beta)+side*K*math.sin(beta))/D;px=xrail+RHO*nx;pz=-RHO+RHO*nz
  axial=(px-delta-(R0+K*G)*math.sin(beta))/(math.cos(beta)+side*K*math.sin(beta));u=axial-(-G if side==1 else G);radius=R0+side*K*u
  axis=(delta+axial*math.cos(beta),0,z+axial*math.sin(beta));contacts.append({'side':'OUTER' if side==1 else 'INNER','rail_x':xrail,'point':(px,0,pz),'axial':axial,'u':u,'radius':radius,'axis':axis,'normal':(nx,0,nz),'rail_center_local':(math.cos(beta)*(xrail-delta)+math.sin(beta)*(-RHO-z)-(-G if side==1 else G),-math.sin(beta)*(xrail-delta)+math.cos(beta)*(-RHO-z))})
 return {'delta':delta,'beta':beta,'height':z,'contacts':contacts,'residual':max(abs(x) for x in residual(beta,H))}
FINAL=contact_state(SHIFT);O,I=FINAL['contacts'];CURVE_R=(O['radius']*I['point'][0]-I['radius']*O['point'][0])/(O['radius']-I['radius']);TURN_PHI=2*math.pi*O['radius']/(CURVE_R-O['point'][0])
def world(local,phi):
 x,y,z=local;return (CURVE_R*(1-math.cos(phi))+x*math.cos(phi)+y*math.sin(phi),CURVE_R*math.sin(phi)-x*math.sin(phi)+y*math.cos(phi),z)
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def state(c,t):
 delta=SHIFT*ease((t-.25)/.55) if c=='C06' else SHIFT if c=='C07' else 0
 progress=ease((t-.12)/.73) if c=='C07' else 0
 phi=TURN_PHI*progress;angle=-math.tau*progress if c=='C07' else -math.pi*ease((t-.25)/.6) if c=='C03' else 0
 d=contact_state(delta);d.update(phi=phi,angle=angle,progress=progress)
 for p in d['contacts']:p['world_point']=world(p['point'],phi);p['world_axis']=world(p['axis'],phi);p['distance']=(CURVE_R-p['point'][0])*phi
 return d
