# 電車のカーブ編・8カット素材 V1

`cuts/C01`〜`C08`の`asset.mp4`が使用用無音素材。全て1080×1920／30fps。各フォルダに元シーンMP4と文字・注釈・キャラの透過WebMを同梱。

再編集は`source/blender/`の8ファイルと共通Pythonソースを使用。組立担当は最初に`WORK_ASSEMBLY.md`を読む。発話との接続は`WORK_ANCHORS.csv`。VOの確定尺は未実測。

QCは`qc/visual-review.json`、`qc/core-geometry.json`、`qc/scene.json`、`qc/media.json`、`qc/playback-qc.json`。動作証拠は各motion画像と連続プレビュー。書面G2 PASSと今回のセルフ実画レビュー、未実施の完成本編G3を区別する。

`SHA256SUMS.txt`／`FILELIST.csv`／`asset-lock.json`で実ファイルを照合できる。画像生成の記録と権利情報は`PROVENANCE.md`。ZIP展開後も相対パスを保つ。
