# EP006 V10 映像素材ソース

B_art.blendが編集用正本。外部リンクなしのメッシュ、皮膚・内部組織・主血管/内腔・爪、固定カメラ・照明と3つの局所形状制御を含む。Armatureや物理ソルバーは使用しない。Ctrl「Controls」の vessel_constriction / pad_relaxation / wrinkle_formation を編集できる。素材側に帯・字幕・進行バー・VO・BGM/SEは無い。

上流の指形状はInnerscene/MakeHuman系CC0手メッシュを適応した新しい美術パス。取得URLとSHA256、CC0原文は同梱資料参照。旧V6/V9の失敗判定を承継してPASSとしたものではない。

制作環境：Blender4.3.2、Python3/Pillow、ffmpeg。
```bash
blender -b -t 5 --python B_source/render_motion.py
python3 B_source/encode_motion.py
```
実行位置はproduction/。360×640/30fps/180f、無音の6秒プレビューを生成する。出力MP4が存在する場合は上書きせず停止するので、再制作時は元納品を保存した新しいフォルダを使う。静的な周囲と完全に保持された同一状態は再利用し、変化する状態は実3Dレンダー。

prepare_art.pyは美術パスをこの独立ファイルへ凍結した際の工程記録であり、再レンダー時に元R1データは不要。507f本尺量産・34.20秒本編編集・公開はこのソースの実行範囲ではない。新G2未取得のまま量産しない。
