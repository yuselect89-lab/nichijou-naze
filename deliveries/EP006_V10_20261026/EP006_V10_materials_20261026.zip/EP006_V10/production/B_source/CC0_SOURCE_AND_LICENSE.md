# 外部ベースメッシュの実体・利用権

Source: https://www.innerscene.com/tools/library/3d-parts/posable-anatomical-right-hand-f6098b4f
Download: https://www.innerscene.com/api/library/posable-anatomical-right-hand-f6098b4f/download
License: CC0-1.0 / https://creativecommons.org/publicdomain/zero/1.0/
SHA256: d1705ec1317516e79deb5c5ce4ef34e69bf6315bba9025e8a7374fbd0c745f47

配布ページ原文："Public domain (CC0). Free to use, modify and redistribute for any purpose, including commercially, with no credit required."

原HTMLは制作環境に保存。V10には source_page.txt / source_terms.txt と配布メタデータを同梱。サイト掲載fileHashとダウンロード506476bytesのSHA256は一致。GLBはBlenderで編集可能なメッシュ/スキン/16骨としてインポート成功。シワや血管のアニメは含まれない。医学的検証済み模型とは主張しない。

原GLBはB_source/vendor/hand-posable.glbに無加工保存。派生物はindex指のみ抽出、UV境界頂点の統合、近位カット境界の閉鎖、Subdivisionで平滑化。原骨格で先端と指腹の方向を合わせ、表示用の回転/均等拡大。肌/窓/内部組織/管壁/内腔/変形制御は別実装。

初回抽出ではUV島を別殻として閉じる不具合があったため、分割シェルを不採用とし、近接頂点統合を先に行うよう修正。これは原GLBの欠陥と断定していない。
