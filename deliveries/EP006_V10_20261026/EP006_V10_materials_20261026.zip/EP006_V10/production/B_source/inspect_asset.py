import bpy,json
from pathlib import Path
from bpy_extras.object_utils import world_to_camera_view
P=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(P/'B_source/B_art.blend'));s=bpy.context.scene;rows=[]
for f in [1,65,105,145,180]:
 s.frame_set(f);dg=bpy.context.evaluated_depsgraph_get();points=[]
 for name in ['outer_skin','FittedNailPlate']:
  o=bpy.data.objects[name].evaluated_get(dg)
  for v in o.data.vertices:
   p=world_to_camera_view(s,s.camera,o.matrix_world@v.co);points.append((p.x*1080,(1-p.y)*1920))
 bb=[min(p[0] for p in points),min(p[1] for p in points),max(p[0] for p in points),max(p[1] for p in points)]
 assert bb[0]>0 and bb[2]<900 and bb[1]>580 and bb[3]<1500,bb
 rows.append({'frame':f,'model_bbox_1080':[round(x,2) for x in bb]})
report={'canvas':[1080,1920],'fps':s.render.fps,'frames':s.frame_end,'armatures':sum(o.type=='ARMATURE' for o in s.objects),'text_objects':sum(o.type=='FONT' for o in s.objects),'source_audio_sounds':len(bpy.data.sounds),'static_camera':s.camera.animation_data is None,'samples':rows,'scope':'Subject stays outside banner/Shorts UI/subtitle zones at the four meaning states and end; not a completed Work composite.'}
(P/'evidence/asset_layout.json').write_text(json.dumps(report,indent=2));print(report)
