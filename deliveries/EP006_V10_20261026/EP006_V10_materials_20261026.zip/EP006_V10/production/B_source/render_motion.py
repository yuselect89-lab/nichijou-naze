"""Issue #2: one fixed-view 180f / six-second silent motion asset.
The figure, tissue, lumen, camera and lights are editable in B_art.blend.
Static surroundings and exactly held poses are reused; all varying states are 3D.
"""
import bpy,json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parents[1];blend=P/'B_source/B_art.blend';sourcehash=hashlib.sha256(blend.read_bytes()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(blend));s=bpy.context.scene;assert s.frame_end==180
s.render.resolution_x=360;s.render.resolution_y=640;s.render.resolution_percentage=100;s.render.threads_mode='FIXED';s.render.threads=5;s.cycles.samples=48
s.render.use_border=True;s.render.use_crop_to_border=False;s.render.border_min_x=.07;s.render.border_max_x=.93;s.render.border_min_y=.20;s.render.border_max_y=.56
out=P/'.cache/roi';out.mkdir(parents=True,exist_ok=True);C=bpy.data.objects['Controls'];rows=[]
for i in range(180):
 s.frame_set(i+1)
 controls=[round(float(C[name]),12) for name in ['vessel_constriction','pad_relaxation','wrinkle_formation']]
 key=hashlib.sha256(json.dumps([sourcehash,controls,48],sort_keys=True).encode()).hexdigest();p=out/(key+'.png')
 if not p.exists():
  s.render.filepath=str(p);bpy.ops.render.render(write_still=True);print('V10_FRAME',i,flush=True)
 rows.append({'frame':i,'controls':controls,'image':str(p.relative_to(P))})
(P/'evidence/frame_map.json').write_text(json.dumps({'source_sha256':sourcehash,'frame_count':180,'fps':30,'duration':6,'roi':[.07,.93,.20,.56],'samples':48,'frames':rows},indent=2))
print('V10_180F_RENDER_COMPLETE',flush=True)
