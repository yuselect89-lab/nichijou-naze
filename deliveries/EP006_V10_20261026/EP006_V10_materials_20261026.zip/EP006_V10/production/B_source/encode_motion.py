from pathlib import Path
from PIL import Image,ImageDraw
import json,subprocess
P=Path(__file__).resolve().parents[1];m=json.loads((P/'evidence/frame_map.json').read_text());assert len(m['frames'])==180
bg=Image.open(P/'B_hero_360.png').convert('RGBA');out=P/'.cache/frames';out.mkdir(parents=True,exist_ok=True)
for row in m['frames']:
 im=Image.open(P/row['image']).convert('RGBA');bbox=im.getchannel('A').getbbox();assert bbox
 frame=bg.copy();frame.paste((0,0,0,0),bbox);frame.alpha_composite(im);assert frame.getchannel('A').getextrema()==(255,255)
 frame.convert('RGB').save(out/f"{row['frame']:04}.png")
target=P/'B_motion_probe_360.mp4'
subprocess.run(['ffmpeg','-v','error','-n','-framerate','30','-i',str(out/'%04d.png'),'-c:v','libx264','-crf','16','-pix_fmt','yuv420p','-an',str(target)],check=True)
subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(target),'-f','null','-'],check=True)
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(target)],text=True));vs=[x for x in meta['streams'] if x['codec_type']=='video'];assert len(vs)==1 and vs[0]['nb_read_frames']=='180' and vs[0]['r_frame_rate']=='30/1';assert not any(x['codec_type']=='audio' for x in meta['streams'])
(P/'evidence/media.json').write_text(json.dumps(meta,indent=2))
decoded=P/'.cache/decoded';decoded.mkdir(exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-n','-i',str(target),'-vsync','0',str(decoded/'%04d.png')],check=True)
files=sorted(decoded.glob('*.png'));assert len(files)==180
indexes=[0,24,44,64,84,104,124,144,164,179];sheet=Image.new('RGB',(270*5,195*2),(245,240,235));d=ImageDraw.Draw(sheet)
for j,i in enumerate(indexes):x=j%5*270;y=j//5*195;sheet.paste(Image.open(files[i]).crop((35,295,305,470)),(x,y+20));d.text((x+5,y+3),f'f{i:03} {i/30:.2f}s',fill='black')
sheet.save(P/'evidence/motion_stages.png')
(P/'evidence/decode.log').write_text('180/180 encoded frames fully decoded, video 360x640,30fps,6.000s,H.264, no audio.\n')
print('V10_MP4_DELIVERABLE_COMPLETE',flush=True)
