"""Freeze an existing new anatomical art pass into an isolated V10 asset.
No anatomical rig or physics solver is built here. Original data is read only.
"""
import bpy,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1]
source=Path(sys.argv[sys.argv.index('--')+1])
bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene;C=bpy.data.objects['Controls'];C.animation_data_clear()
for name,keys in {
 'vessel_constriction':[(1,0),(25,0),(65,1),(180,1)],
 'pad_relaxation':[(1,0),(65,0),(105,1),(180,1)],
 'wrinkle_formation':[(1,0),(105,0),(145,1),(180,1)],
}.items():
 for f,val in keys:C[name]=float(val);C.keyframe_insert(data_path='["'+name+'"]',frame=f)
for fc in C.animation_data.action.fcurves:
 fc.update_autoflags(C)
 for k in fc.keyframe_points:k.interpolation='BEZIER';k.handle_left_type='AUTO_CLAMPED';k.handle_right_type='AUTO_CLAMPED'
s.frame_start=1;s.frame_end=180;s.render.fps=30;s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100;s.frame_set(1)
bpy.data.orphans_purge(do_recursive=True)
bpy.ops.wm.save_as_mainfile(filepath=str(P/'B_source/B_art.blend'),compress=True)
print('V10_ART_FROZEN_180F',flush=True)
