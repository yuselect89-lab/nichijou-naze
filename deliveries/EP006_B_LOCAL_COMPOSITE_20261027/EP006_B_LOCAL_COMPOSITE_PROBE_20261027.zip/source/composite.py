"""Original local compositing of a supplied photograph; no Blender or image generation.
The optical vessel section is schematic, not exposed anatomy. 360p / 180f / 30fps.
"""
from pathlib import Path
import json,subprocess
import numpy as np
from scipy.ndimage import map_coordinates,gaussian_filter,distance_transform_edt
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];cfg=json.loads((R/'source/settings.json').read_text())
W,H=360,640;y,x=np.mgrid[:H,:W].astype(np.float32)
def sm(v):v=np.clip(v,0,1);return v*v*(3-2*v)
def ease(t,a,b):return sm((t-a)/(b-a))
def sample(a,xx,yy):return np.stack([map_coordinates(a[...,k],[yy,xx],order=1,mode='nearest') for k in range(3)],axis=-1)
def shade(z):
 gy,gx=np.gradient(gaussian_filter(z,.6));n=np.sqrt(1+gx*gx+gy*gy)
 return np.clip(.52+.53*(-gx*-.48-gy*-.50+.80)/n,.24,1.32)
def pil(a):return Image.fromarray(np.uint8(np.clip(a,0,1)*255),'RGB')
a=Image.open(R/'inputs/fingertip_reference_original.png').convert('RGB')
original=np.asarray(a,np.float32)/255
# This crop contains the nail edge and intact fingertip surface only: no cut window or exposed vessel.
photo=np.asarray(a.crop(tuple(cfg['crop'])).resize((W,H),Image.Resampling.LANCZOS),np.float32)/255
pil(photo).save(R/'inputs/intact_skin_crop_360.png')
skin=sm((photo[...,0]-photo[...,2]-.035)/.08)
# Signed photographic boundary; deformation and shadow share this attached interface.
sdf=distance_transform_edt(skin>.5)-distance_transform_edt(skin<=.5)
noise=photo-gaussian_filter(photo,(1.8,1.8,0))

def frame(shot,t,fields=False):
 out=photo.copy();maps={}
 if shot==4:
  progress=ease(t,.40,1.48)
  cx,cy=cfg['lens_center'];r=np.sqrt((x-cx)**2+((y-cy)/.96)**2)
  lens=sm((cfg['lens_radius']+.6-r)/1.2)
  # Fine photographed texture under a softly lit schematic optical observation.
  local=gaussian_filter(photo,(2,2,0))
  # Reuse intact photographic tissue texture, without its cut edge or exposed tube end.
  tissue_photo=sample(original,220+(x-cx+96)*1.05,920+(y-cy+96)*.52)
  lum=np.mean(tissue_photo,axis=2)
  tissue=np.array([.80,.54,.43])[None,None,:]*(.52+.65*lum[...,None])+noise*.15
  tissue=tissue*(.90+.12*np.exp(-(r/95)**2))[...,None]
  outer=cfg['outer_radius']-4*progress;inner=cfg['inner_radius']-(cfg['inner_radius']-18)*progress
  p=np.clip((r-inner)/(outer-inner),0,1)
  wall_z=13*np.sin(np.pi*p)
  angle=np.arctan2((y-cy)/.96,x-cx)
  tx=310+105*np.cos(angle)
  ty=np.interp(tx,[180,240,310,420,460],[758,790,823,848,850])+(p-.5)*54
  photographed_wall=sample(original,tx,ty)
  wall=(photographed_wall*.72+np.array([.70,.25,.235])*.28)*shade(wall_z)[...,None]+noise*.16
  # The wall has depth, an attached inner shadow and a broad soft reflection.
  wall+=np.exp(-((r-(inner+.65*(outer-inner)))/5.5)**2)[...,None]*np.array([.10,.065,.055])
  annulus=sm((outer+.6-r)/1.2)*sm((r-inner+.6)/1.2)
  occlusion=gaussian_filter(annulus,4)*.18
  tissue*=1-occlusion[...,None]
  core_z=-5+3*np.maximum(0,1-r/max(inner,1))**2
  fluid=np.array([.285,.035,.065])[None,None,:]*shade(core_z)[...,None]+noise*.14
  fluid+=np.exp(-(((x-cx+inner*.25)/(inner*.75))**2+((y-cy+inner*.30)/(inner*.6))**2))[...,None]*np.array([.09,.022,.025])
  cavity=sm((inner+.5-r)/1)
  tissue=tissue*(1-cavity[...,None])+fluid*cavity[...,None]
  tissue=tissue*(1-annulus[...,None])+wall*annulus[...,None]
  out=out*(1-lens[...,None])+tissue*lens[...,None]
  rim=np.exp(-((r-cfg['lens_radius'])/.6)**2)*.38
  out=out*(1-rim[...,None])+np.array([.93,.86,.75])*rim[...,None]
  maps={'wall_height':wall_z,'inner_radius':np.array(inner),'outer_radius':np.array(outer),'lens_alpha':lens}
 elif shot==5:
  p=ease(t,.30,1.50)
  gate=np.exp(-((x-279)/72)**2-((y-351)/94)**2)
  dx=p*cfg['pad_inward_px']*gate;dy=p*2.1*gate
  qx=x+dx;qy=y+dy
  out=sample(photo,qx,qy)
  attached_sdf=map_coordinates(sdf,[qy,qx],order=1,mode='nearest')
  # A shallow local curvature/contact shadow follows the same warped skin boundary.
  edge_shadow=np.exp(-((attached_sdf-5)/6)**2)*gate
  local_relief=-p*2.6*np.exp(-((x-255)/63)**2-((y-361)/78)**2)*skin
  out*=np.clip(shade(local_relief)/shade(np.zeros_like(local_relief)),.83,1.10)[...,None]
  out*=1-(edge_shadow*.085*p)[...,None]
  maps={'warp_x':qx,'warp_y':qy,'attached_boundary':attached_sdf,'local_height':local_relief}
 else:
  # Preserve CUT05's relaxed contour across the edit; do not visibly reinflate at CUT06.
  relaxed=np.asarray(frame(5,1.85),np.float32)/255
  z=np.zeros((H,W),np.float32)
  for i,(cx,depth,width) in enumerate(cfg['creases']):
   p=ease(t,.30+i*.18,1.15+i*.18)
   line=cx+.11*(y-347)+.0009*(y-347)**2+1.3*np.sin((y-270)/52+i)
   gate=np.exp(-((y-(347+i*6))/83)**6)
   z-=depth*p*np.exp(-((x-line)/width)**2)*gate*skin
  # Actual UV displacements and relighting use one height field, with intact photo texture.
  qx=x+z*.72;qy=y+z*.38
  out=sample(relaxed,qx,qy)
  ratio=shade(z)/shade(np.zeros_like(z))
  out*=np.clip(1+.85*(ratio-1),.74,1.20)[...,None]
  maps={'height':z,'warp_x':qx,'warp_y':qy}
 if fields:return pil(out),maps
 return pil(out)

if __name__=='__main__':
 snapshots=[]
 for shot in [4,5,6]:
  for state,t in [('before',0),('after',1.85)]:
   im,maps=frame(shot,t,True);im.save(R/f'CUT0{shot}_{state}_360.png');np.savez_compressed(R/'source'/f'CUT0{shot}_{state}_fields.npz',**maps);snapshots.append(im)
 out=R/'B_3CUTS_COMPOSITE_PROBE_360.mp4'
 proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','360x640','-r','30','-i','pipe:0','-an','-c:v','libx264','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
 sheet=Image.new('RGB',(360*6,665),'#eeeeee');d=ImageDraw.Draw(sheet)
 for j in range(180):
  shot=4+j//60;t=(j%60)/30;im=frame(shot,t);proc.stdin.write(np.asarray(im).tobytes())
  if j in [0,55,60,115,120,175]:
   k=[0,55,60,115,120,175].index(j);sheet.paste(im,(360*k,25));d.text((360*k+8,7),f'CUT0{shot} | {j/30:.2f}s',fill='black')
 proc.stdin.close();assert proc.wait()==0;sheet.save(R/'evidence/PLAYBACK_CONTACT_360.png')
 print(out,flush=True)
