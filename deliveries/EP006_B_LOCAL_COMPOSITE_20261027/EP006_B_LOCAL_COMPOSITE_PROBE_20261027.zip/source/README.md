EP006 local image composite probe — 2026-10-27 JST

Render 180 frames / 30fps / 360x640 / no audio:
  python3 source/composite.py
Requires Python 3, numpy, scipy, Pillow, and ffmpeg with libx264.
Run from any directory; paths resolve relative to this source file.
settings.json edits crop, lens position/radii, local pad warp and crease depths/widths.
All values are artistic pixel values, not physiological measurements.

Inputs: unchanged user-supplied, generated-look reference PNG. This is NOT real
camera footage or validated anatomical reference. intact_skin_crop_360.png is
the exact intact fingertip crop used for the video background. The source's cut
edge and open vessel end are outside that crop. In the schematic optical inset,
intact tissue and vessel-wall texture patches are sampled from the same original;
no old FAIL images are used. No Blender model or new external image generation.

The optical transverse vessel section uses photographic texture and a radial
height/shadow field; it is an explanatory overlay, not exposed anatomy. The pad
warp moves the photographic edge and attached shadow together. Skin creases use
one height field for UV displacement and relighting. The final pad warp carries
into CUT06 to prevent visible reinflation at the cut. Field NPZ snapshots are
editable floating-point arrays, not independent anatomy layers. The Python code
reconstructs the full motion, rather than only crossfading final stills.

0–2s: vessel narrowing; 2–4s: local pad relaxation; 4–6s: staggered creases.
This compressed probe does not change original cut lengths, narration or captions.
The source photo has pre-existing fine skin ridges. See QC_RESULT.md for limits.

The fal candidate was NOT retrieved or used: the environment proxy rejected
CONNECT to v3b.fal.media (HTTP 403). A network configuration draft adds only that
host while retaining prior custom domains; saving a draft does not apply it.
No API generation call, payment, public posting or GitHub push occurred.

Browser playback evidence uses source/playback_check.mjs (Node, existing project
@remotion/renderer and /usr/bin/chromium). It is automated 1x playback, not an
independent human or Gemini review. The final main edit remains Work's task;
approved banner/progress bar/captions are composited only there, once. Display
captions remove 「、」 and retain 「。」. Presenter role here is focus_only/hidden.
