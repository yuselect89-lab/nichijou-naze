# カップヌードルV4.1｜最初に読む

**現在の工程は Codexによる映像素材制作。ChatGPT Workによる本編編集は素材検収後。**

2026-10-27 Gemini ProのG2差分QCは **MINOR FIX**。指摘3件は `04_G2_REVIEW_DECISION.md` に採用／修正採用を明記し、`01_V4_1_VISUAL_PLAN.md` / `02_CODEX_EXECUTION_ORDER.md` / `03_WORK_ASSEMBLY_ORDER.md` に反映した。Geminiの再判定を受けた事実はないため「G2再審査PASS」とは記載しない。

## 今どこで、誰が、何をするか
- **Codex**：`/workspace/nichijou-naze` を開く。既存 `recovery/cupnoodle-20261025` と旧PROBEを照合。V4.1に従い **2本の1080×1920・30fps無音コア映像と3枚の編集用スチル**を実制作し、360px実画QCと可編集ソースを納品。完成本編は作らない。
- **ChatGPT**：Codexの動画を実画で検収。合格している素材だけをWorkへ引き渡す。
- **ChatGPT Work**：CUT01〜06へ編集展開し、確定VOを現物確認して同期、シリーズ共通帯・字幕・進行バーを親合成で一度だけ入れ、ラフMP4を制作。
- **Gemini Pro＋ChatGPT**：ラフMP4のG3。指摘は検証して必要な差分だけ修正。

## 優先順位
1. 現在の正式シリーズLOCK／台本・作品構造
2. **本パッケージ `01_V4_1_VISUAL_PLAN.md`**（ユーザー許可の省工数方式＋G2 MINOR FIX反映）
3. `02_CODEX_EXECUTION_ORDER.md`（実装／納品）
4. `references/NNZ_CUPNOODLE_V3_VISUAL_STORYBOARD_20261025.md`（元の内容・演出品質を確認する資料）

V3が求める科学的意味・視聴報酬・映像品質は維持するが、**6独立3Dレンダーや液体ソルバ必須という制作手段はV4.1で置換**。古いV3の手段が新しいV4.1と競合した場合はV4.1を優先。LOCKや元ファイルの保全は常に優先。

## 制限
課金・外部API・外部送信・VO再生成・BGM/SEの新規追加・公開・GitHub push・原本上書き禁止。承認済み帯やキャラの改変禁止。成果物を作っていないのにPASSと報告しない。

**添付なし・ZIP読み取り失敗時**：`CODEX_COPY_PASTE.txt` をテキストとして開き、全文をCodexに渡す。自動的にCodex側へ送信されたわけではない。
