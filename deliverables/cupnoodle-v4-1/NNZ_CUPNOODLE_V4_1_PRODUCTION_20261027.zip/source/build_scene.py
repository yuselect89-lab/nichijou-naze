"""Cup Noodles V4.1 — one original editable model, two production camera tracks.
No fluid solver or outside assets. Water is an educational controlled-mesh approximation.
Blender 4.3.2. Frame numbers below are 1-based; manifest uses [start,end) zero-based.
"""
import bpy,math,random,json,sys,time
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1];S=R/'source';random.seed(20261027)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=8;s.cycles.use_denoising=False;s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.08;s.cycles.adaptive_min_samples=4
s.cycles.max_bounces=5;s.cycles.diffuse_bounces=2;s.cycles.glossy_bounces=2;s.cycles.transmission_bounces=4;s.cycles.transparent_max_bounces=8
s.render.threads_mode='FIXED';s.render.threads=4
s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100
s.render.image_settings.file_format='PNG';s.render.fps=30;s.frame_start=1;s.frame_end=480
s.render.film_transparent=False;s.view_settings.view_transform='AgX'
s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.23,.26,.29,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.30
# Every physical component is parented to the same transport rig, never independently jiggled.
root=bpy.data.objects.new('COMMON_MODEL_fixed_support',None);s.collection.objects.link(root)
root['version']='CUPNOODLE_NEW_V4_1_02';root['lower_gap_model_units']=.72;root['upper_gap_model_units']=.80
root['measurement_note']='Schematic proportions, not measured product dimensions'
def parent(o):o.parent=root;return o
def mesh(name,vs,fs,material,group=True):
 m=bpy.data.meshes.new(name);m.from_pydata(vs,[],fs);m.update();o=bpy.data.objects.new(name,m);s.collection.objects.link(o);o.data.materials.append(material)
 for p in m.polygons:p.use_smooth=True
 if group:parent(o)
 return o

def basic(name,col,rough=.45):
 m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Roughness'].default_value=rough;return m
paper=basic('Unbranded warm paper cup',(.83,.78,.67),.55)
n=paper.node_tree.nodes;l=paper.node_tree.links;p=n.get('Principled BSDF')
noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=100;noise.inputs['Detail'].default_value=2
bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.12;bump.inputs['Distance'].default_value=.012;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs[0],p.inputs['Normal'])
# The wall geometry is intact. A fixed elliptical front optical window changes opacity only.
geo=n.new('ShaderNodeNewGeometry');sep=n.new('ShaderNodeSeparateXYZ');l.new(geo.outputs['Position'],sep.inputs[0])
def mathnode(op,a,b=0):
 node=n.new('ShaderNodeMath');node.operation=op
 if hasattr(a,'node'):l.new(a,node.inputs[0])
 else:node.inputs[0].default_value=a
 if hasattr(b,'node'):l.new(b,node.inputs[1])
 else:node.inputs[1].default_value=b
 return node.outputs[0]
xnorm=mathnode('DIVIDE',sep.outputs['X'],1.43);znorm=mathnode('DIVIDE',mathnode('SUBTRACT',sep.outputs['Z'],1.79),1.52)
r2=mathnode('ADD',mathnode('MULTIPLY',xnorm,xnorm),mathnode('MULTIPLY',znorm,znorm))
inside=mathnode('LESS_THAN',r2,1);front=mathnode('LESS_THAN',sep.outputs['Y'],-.13)
mask=mathnode('MULTIPLY',mathnode('MULTIPLY',inside,front),1.0)
transparent=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');l.new(mask,mix.inputs[0]);l.new(p.outputs[0],mix.inputs[1]);l.new(transparent.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],n.get('Material Output').inputs['Surface'])
rim=basic('Rolled cream rim',(.92,.87,.75),.38)
base_mat=basic('Cup inner base',(.75,.69,.57),.48)

def radius(z):return .99+.64*z/3.5
# Full cup shell, inner and outer wall, full circumference. No geometric cutout.
N=128;vs=[]
for z in [.13,3.5]:
 for side in [0,1]:
  rr=radius(z)+.065*side
  for j in range(N):a=2*math.pi*j/N;vs.append((rr*math.cos(a),rr*math.sin(a),z))
fs=[]
for j in range(N):
 k=(j+1)%N;fs += [(j,k,2*N+k,2*N+j),(N+j,3*N+j,3*N+k,N+k),(2*N+j,2*N+k,3*N+k,3*N+j),(j,N+j,N+k,k)]
mesh('Cup_Outer_Inner_intact_optical_window',vs,[tuple(reversed(f)) for f in fs],paper)
bpy.ops.mesh.primitive_cylinder_add(vertices=128,radius=radius(.18),depth=.14,location=(0,0,.15));o=bpy.context.object;o.name='Cup_Base_closed';o.data.materials.append(base_mat);parent(o)
for z,rr,th in [(3.5,radius(3.5)+.025,.055),(.14,radius(.14)+.025,.035)]:
 bpy.ops.mesh.primitive_torus_add(major_radius=rr,minor_radius=th,major_segments=128,minor_segments=12,location=(0,0,z));o=bpy.context.object;o.name='Cup_Rolled_Rim' if z>3 else 'Cup_Base_Rim';o.data.materials.append(rim);parent(o)
# One dry/wet shader shared by every noodle strand. Wet boundary follows rising water.
noodle=basic('Fried noodle porous dry to wetted',(.64,.39,.105),.47);n=noodle.node_tree.nodes;l=noodle.node_tree.links;p=n.get('Principled BSDF');p.inputs['Subsurface Weight'].default_value=.075;p.inputs['Subsurface Radius'].default_value=(1,.45,.16)
geo=n.new('ShaderNodeNewGeometry');sep=n.new('ShaderNodeSeparateXYZ');l.new(geo.outputs['Position'],sep.inputs[0])
noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=38;noise.inputs['Detail'].default_value=3
coarse=n.new('ShaderNodeTexNoise');coarse.inputs['Scale'].default_value=3;coarse.inputs['Detail'].default_value=2
ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.12;ramp.color_ramp.elements[0].color=(.46,.245,.055,1);ramp.color_ramp.elements[1].position=.88;ramp.color_ramp.elements[1].color=(.78,.53,.19,1);l.new(coarse.outputs['Fac'],ramp.inputs[0])
bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.22;bump.inputs['Distance'].default_value=.015;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs[0],p.inputs['Normal'])
wet=n.new('ShaderNodeValue');wet.name='WET_CONTACT_HEIGHT';wet.label='Water-contact wetting, not independent floating front'
for f,val in [(1,-2),(240,-2),(241,-2),(343,.30),(375,.76),(410,1.12),(450,1.40),(480,1.40)]:wet.outputs[0].default_value=val;wet.outputs[0].keyframe_insert('default_value',frame=f)
sub=n.new('ShaderNodeMath');sub.operation='SUBTRACT';l.new(wet.outputs[0],sub.inputs[0]);l.new(sep.outputs['Z'],sub.inputs[1])
mapr=n.new('ShaderNodeMapRange');mapr.inputs['From Min'].default_value=-.045;mapr.inputs['From Max'].default_value=.065;mapr.clamp=True;l.new(sub.outputs[0],mapr.inputs['Value'])
wetcol=n.new('ShaderNodeMixRGB');wetcol.blend_type='MULTIPLY';l.new(mapr.outputs[0],wetcol.inputs[0]);l.new(ramp.outputs[0],wetcol.inputs[1]);wetcol.inputs[2].default_value=(.83,.78,.70,1);l.new(wetcol.outputs[0],p.inputs['Base Color'])
rough=n.new('ShaderNodeMapRange');rough.inputs['From Min'].default_value=0;rough.inputs['From Max'].default_value=1;rough.inputs['To Min'].default_value=.49;rough.inputs['To Max'].default_value=.17;l.new(mapr.outputs[0],rough.inputs[0]);l.new(rough.outputs[0],p.inputs['Roughness'])
# Wetting at the pour contact is separate from the later bottom contact front.
topwet=n.new('ShaderNodeValue');topwet.name='TOP_POUR_CONTACT'
for f,val in [(1,0),(240,0),(241,0),(277,1),(480,1)]:topwet.outputs[0].default_value=val;topwet.outputs[0].keyframe_insert('default_value',frame=f)
tx=mathnode('SUBTRACT',sep.outputs['X'],.18);ty=mathnode('ADD',sep.outputs['Y'],.20)
dist=mathnode('ADD',mathnode('MULTIPLY',tx,tx),mathnode('MULTIPLY',ty,ty))
spot=n.new('ShaderNodeMapRange');spot.clamp=True;spot.inputs['From Min'].default_value=.006;spot.inputs['From Max'].default_value=.15;spot.inputs['To Min'].default_value=1;spot.inputs['To Max'].default_value=0;l.new(dist,spot.inputs[0])
contact=mathnode('MULTIPLY',mathnode('MULTIPLY',spot.outputs[0],mathnode('GREATER_THAN',sep.outputs['Z'],2.43)),topwet.outputs[0])
combined=mathnode('MAXIMUM',mapr.outputs[0],contact);l.new(combined,wetcol.inputs[0]);l.new(combined,rough.inputs[0])
# Bottom-contact-linked porous wetting: two connected patches expand into the lower noodles.
cap=n.new('ShaderNodeValue');cap.name='LOCAL_CAPILLARY_CONTACT_PROGRESS'
for f,val in [(1,0),(240,0),(241,0),(398,0),(414,.40),(432,.90),(442,1),(480,1)]:cap.outputs[0].default_value=val;cap.outputs[0].keyframe_insert('default_value',frame=f)
wetcombined=combined
for idx,cx in enumerate([-.43,.43]):
 prog=n.new('ShaderNodeMapRange');prog.clamp=True;prog.inputs['From Min'].default_value=idx*.16;prog.inputs['From Max'].default_value=1;l.new(cap.outputs[0],prog.inputs[0]);pv=prog.outputs[0]
 xx=mathnode('SUBTRACT',sep.outputs['X'],cx);yy=mathnode('ADD',sep.outputs['Y'],.60)
 dd=mathnode('SQRT',mathnode('ADD',mathnode('MULTIPLY',xx,xx),mathnode('MULTIPLY',yy,yy)))
 rad=mathnode('ADD',.18,mathnode('MULTIPLY',pv,.80))
 edge=n.new('ShaderNodeMapRange');edge.clamp=True;l.new(dd,edge.inputs[0]);l.new(mathnode('SUBTRACT',rad,.12),edge.inputs['From Min']);l.new(mathnode('ADD',rad,.08),edge.inputs['From Max']);edge.inputs['To Min'].default_value=1;edge.inputs['To Max'].default_value=0
 front=mathnode('ADD',.94,mathnode('MULTIPLY',pv,.68))
 zd=mathnode('SUBTRACT',sep.outputs['Z'],front);zm=n.new('ShaderNodeMapRange');zm.clamp=True;l.new(zd,zm.inputs[0]);zm.inputs['From Min'].default_value=-.045;zm.inputs['From Max'].default_value=.045;zm.inputs['To Min'].default_value=1;zm.inputs['To Max'].default_value=0
 patch=mathnode('MULTIPLY',mathnode('MULTIPLY',edge.outputs[0],zm.outputs[0]),pv)
 wetcombined=mathnode('MAXIMUM',wetcombined,patch)
l.new(wetcombined,wetcol.inputs[0]);l.new(wetcombined,rough.inputs[0]);noodle['wet_material_version']='local_contact_02'

# Fine serpentine strands with crinkles and natural variation. Actual reserved interstices for water.
channels=[(.18,-.20),(-.38,.28),(.46,.30)]
def reserve(x,y):
 for cx,cy in channels:
  dx=x-cx;dy=y-cy;d=math.hypot(dx,dy)
  if d<.115:
   if d<.00001:dx=.01;d=.01
   x=cx+dx*.115/d;y=cy+dy*.115/d
 return x,y
cur=bpy.data.curves.new('Editable individual crinkled noodle strands','CURVE');cur.dimensions='3D';cur.resolution_u=1;cur.bevel_depth=.031;cur.bevel_resolution=2;cur.resolution_u=2;cur.use_fill_caps=True
for layer in range(12):
 z0=1.00+layer*.142
 rr=(.88+layer*.038) if layer<5 else min(radius(z0)-.032,1.15+(layer-5)*.048)
 rows=11 if layer<4 else 18
 for row in range(rows):
  yy=(-.92+1.84*row/(rows-1))*rr;span=math.sqrt(max(.01,rr*rr-yy*yy));phase=random.random()*6.28;pts=[]
  for j in range(83):
   t=j/82;x0=(-1+2*t)*span;y0=yy+.034*math.sin(t*math.pi*23+phase)+.013*math.sin(t*math.pi*47+phase*.7)
   x0+=.015*math.sin(t*math.pi*37+phase);x0,y0=reserve(x0,y0)
   rad=math.hypot(x0,y0);limit=radius(z0)-.030
   if rad>limit:x0*=limit/rad;y0*=limit/rad
   z=z0+.023*math.sin(t*math.pi*27+phase)+.011*math.cos(t*math.pi*43+phase)
   # alternate noodle directions to avoid a stack of identical grids
   rot=(layer%3)*.71;pts.append((x0*math.cos(rot)-y0*math.sin(rot),x0*math.sin(rot)+y0*math.cos(rot),z))
  # Reserve flow slots in final world positions after layer rotation.
  pts=[(*reserve(px,py),pz) for px,py,pz in pts]
  sp=cur.splines.new('POLY');sp.points.add(len(pts)-1)
  for p0,co in zip(sp.points,pts):p0.co=(*co,1)
# Contact loops touch the sidewall over a finite band, not invisible structural posts.
for k in range(4):
 z=2.17+k*.067;rr=radius(z)-.029;pts=[]
 for j in range(257):
  a=2*math.pi*j/256;r=rr-.003*(1+math.sin(a*39+k))
  pts.append((r*math.cos(a),r*math.sin(a),z+.012*math.sin(a*35+k)))
 sp=cur.splines.new('POLY');sp.points.add(len(pts)-1)
 for q,co in zip(sp.points,pts):q.co=(*co,1)
obj=bpy.data.objects.new('Noodles_TopDense_LowerSparse_SHARED',cur);s.collection.objects.link(obj);obj.data.materials.append(noodle);parent(obj)
# Water shader: predominantly transparent, neutral with a warm reflected key; no orange gel.
water=basic('Transparent hot water IOR 1.333',(.985,.99,.99),.045);n=water.node_tree.nodes;l=water.node_tree.links;p=n.get('Principled BSDF');p.inputs['IOR'].default_value=1.333;p.inputs['Transmission Weight'].default_value=1
trans=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');mix.inputs[0].default_value=.65;l.new(p.outputs[0],mix.inputs[1]);l.new(trans.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],n.get('Material Output').inputs['Surface'])
# A mesh water basin: closed volume, soft meniscus, within the intact cup.
NR=30;NA=96
vs=[(0,0,.225)]
for ring in range(1,NR+1):
 r0=ring/NR
 for j in range(NA):a=2*math.pi*j/NA;vs.append((radius(.23)*r0*math.cos(a),radius(.23)*r0*math.sin(a),.23+.025*r0**18))
# Top surface only, plus side and bottom, all vertices updated from one water level driver.
fs=[]
for j in range(NA):fs.append((0,1+j,1+(j+1)%NA))
for k in range(NR-1):
 st=1+k*NA;ns=st+NA
 for j in range(NA):jj=(j+1)%NA;fs.append((st+j,ns+j,ns+jj,st+jj))
last=1+(NR-1)*NA;bottom_start=len(vs)
for j in range(NA):a=2*math.pi*j/NA;vs.append((radius(.23)*math.cos(a),radius(.23)*math.sin(a),.223))
for j in range(NA):jj=(j+1)%NA;fs.append((last+j,bottom_start+j,bottom_start+jj,last+jj))
fs.append(tuple(reversed(range(bottom_start,bottom_start+NA))))
body=mesh('Water_Transparent_Body_Meniscus',vs,fs,water)
body.shape_key_add(name='Basis');fill=body.shape_key_add(name='Fill_and_beneath_noodles')
for idx,v in enumerate(vs):
 if idx==0:fill.data[idx].co=(0,0,1.34)
 elif idx<bottom_start:
  k=(idx-1)//NA+1;r0=k/NR;a=2*math.pi*((idx-1)%NA)/NA;zz=1.34+.025*r0**18+.003*math.sin(a*7)*(1-r0)
  fill.data[idx].co=(radius(1.34)*r0*math.cos(a),radius(1.34)*r0*math.sin(a),zz)
for f,val in [(1,0),(240,0),(241,0),(335,0),(365,.20),(404,.65),(450,1),(480,1)]:fill.value=val;fill.keyframe_insert('value',frame=f)
for f,vis in [(1,True),(240,True),(241,True),(329,False),(480,False)]:body.hide_render=vis;body.keyframe_insert('hide_render',frame=f)
# The pouring stream and three descending threads share the real reserved interstices.
def stream(name,cx,cy,zlo,zhi,r,phase):
 N=180 if zhi>5 else 70;M=12;vs=[]
 for k in range(N):
  z=zlo+(zhi-zlo)*k/(N-1);xx=cx+.008*math.sin(z*17+phase);yy=cy+.008*math.cos(z*14+phase)
  for j in range(M):a=2*math.pi*j/M;rr=r*(1+.07*math.sin(z*28+j));vs.append((xx+rr*math.cos(a),yy+rr*math.sin(a),z))
 fs=[(k*M+j,k*M+(j+1)%M,(k+1)*M+(j+1)%M,(k+1)*M+j) for k in range(N-1) for j in range(M)]
 o=mesh(name,vs,fs,water);return o
inlet=stream('Water_Inlet_continuous_column',.18,-.20,2.54,8.0,.065,.4)
inlet.shape_key_add(name='Basis');tail=inlet.shape_key_add(name='Pour_tail_falls_down')
for q,v in zip(tail.data,inlet.data.vertices):q.co=(v.co.x,v.co.y,2.54)
for f,val in [(1,0),(240,0),(241,0),(421,0),(434,1),(480,1)]:tail.value=val;tail.keyframe_insert('value',frame=f)
for f,vis in [(1,True),(240,True),(241,False),(434,False),(435,True),(480,True)]:inlet.hide_render=vis;inlet.keyframe_insert('hide_render',frame=f)
for i,(cx,cy) in enumerate(channels):
 o=stream('Water_interstice_downflow_'+str(i),cx,cy,.25,2.65,.027 if i else .037,i)
 # Growing downflow: actual stream extends from top through its interstice, never an up-jet.
 orig=[v.co.copy() for v in o.data.vertices];o.shape_key_add(name='Basis');key=o.shape_key_add(name='Gravity_downward_front')
 for q,v in zip(key.data,orig):q.co=(v.x,v.y,2.65)
 for f,value in [(1,1),(240,1),(241,1),(275+i*5,1),(331+i*4,0),(435,0),(480,0)]:key.value=value;key.keyframe_insert('value',frame=f)
 fall=o.shape_key_add(name='Downflow_tail_falls_to_basin')
 for q,v in zip(fall.data,orig):q.co=(v.x,v.y,.25)
 for f,value in [(1,0),(240,0),(241,0),(435,0),(443,1),(480,1)]:fall.value=value;fall.keyframe_insert('value',frame=f)
 for f,vis in [(1,True),(240,True),(241,False),(443,False),(444,True),(480,True)]:o.hide_render=vis;o.keyframe_insert('hide_render',frame=f)
# Soft studio backdrop and a stable warm key. No text, brand, arrows or characters.
matfloor=basic('Warm blue-grey studio',(.19,.225,.245),.72)
# Seamless studio cove removes a false horizon through the cup.
profile=[(-30,.02),(4,.02)]
for i in range(1,25):
 a=-math.pi/2+(math.pi/2)*i/24;profile.append((4+3*math.cos(a),3.02+3*math.sin(a)))
profile.append((7,25))
backverts=[(xx,yy,zz) for xx in [-30,30] for yy,zz in profile];K=len(profile)
mesh('Background_seamless_cove',backverts,[(i,i+1,K+i+1,K+i) for i in range(K-1)],matfloor,False)
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
def area(name,loc,energy,size,color):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=energy;o.data.shape='DISK';o.data.size=size;o.data.color=color;aim(o,(0,0,1.6))
area('Key_large_warm',(-3,-4,7),700,5,(1,.88,.73));area('Fill_soft',(4,-1,5),450,4,(.76,.85,1));area('Rim_water_highlights',(0,4,6),800,3,(1,.96,.85))
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='CAMERA_SHARED_true_3D_dolly';s.camera=cam;cam.data.type='PERSP';cam.data.lens=70;cam.data.shift_x=.035;cam.data.shift_y=.055
reveal=((.65,-9.0,4.0),(0,0,1.75),70)
end02=((2.05,-8.9,4.5),(0,0,1.8),70)
contact=((2.35,-5.6,3.6),(1.01,-.05,1.87),64)
watercam=((.80,-6.3,2.9),(0,0,1.30),65)
poses=[(1,reveal),(49,((.85,-8.8,4.05),(0,0,1.75),70)),(61,((.85,-8.8,4.05),(0,0,1.75),70)),(108,end02),(120,end02),(121,end02),(193,contact),(240,contact),(241,reveal),(283,watercam),(434,watercam),(468,reveal),(480,reveal)]
locks={}
for f,(loc,target,lens) in poses:
 cam.location=loc;aim(cam,target);cam.data.lens=lens*.57
 for path in ['location','rotation_euler']:cam.keyframe_insert(path,frame=f)
 cam.data.keyframe_insert('lens',frame=f)
for f,angle in [(1,0),(179,0),(187,.0020),(195,-.0018),(203,.0014),(211,-.0010),(221,0),(240,0),(480,0)]:root.rotation_euler[1]=angle;root.keyframe_insert('rotation_euler',frame=f)
# Keep endpoint holds exact; no independent exposure/noise changes.
for data in [cam,cam.data,root]:
 if data.animation_data and data.animation_data.action:
  for fc in data.animation_data.action.fcurves:
   for kp in fc.keyframe_points:kp.interpolation='BEZIER';kp.handle_left_type='AUTO_CLAMPED';kp.handle_right_type='AUTO_CLAMPED'
sys.path.insert(0,str(S))
from finalize_wetting import apply as finalize_wet_contact
finalize_wet_contact()
for name,f in [('CAM_C01_REVEAL',1),('CAM_C02_END',120),('CAM_C04_CONTACT',240),('CAM_C05_END',480)]:
 s.frame_set(f);locks[name]={'blender_frame':f,'position':list(cam.location),'rotation_euler':list(cam.rotation_euler),'projection':cam.data.type,'lens_mm':cam.data.lens,'shift_x':cam.data.shift_x,'shift_y':cam.data.shift_y,'sensor_width_mm':cam.data.sensor_width,'model_matrix':[list(row) for row in root.matrix_world],'resolution':[1080,1920],'fps':30}
s['NEW_MODEL_AUTHORIZATION']='User explicitly authorized new shared model after old inputs were confirmed missing.'
s['water_method']='Controlled clear mesh flow through reserved noodle interstices, rising meniscus and contact-height shader wetting; no solver; schematic not measured hydrodynamics'
(S/'model_parameters.json').write_text(json.dumps({'version':root['version'],'cup_height':3.5,'inner_base_z':.22,'noodle_lowest_approx_z':.94,'noodle_highest_approx_z':2.64,'contact_band_z':[2.17,2.371],'no_hidden_supports':True,'flow_interstices':channels,'scale':'Schematic model units, not product measurements'},indent=2))
(R/'camera_lock.json').write_text(json.dumps(locks,indent=2))
s.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(S/'CUPNOODLE_V4_1_SHARED.blend'))
if '--build-only' not in sys.argv:
 s.render.filepath=str(R/'evidence/HERO_REVEAL_1080.png');t=time.time();bpy.ops.render.render(write_still=True);print('HERO_SECONDS',time.time()-t,flush=True)
