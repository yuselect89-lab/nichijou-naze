"""Extract the three real decoded stills, create edit-join samples, verify actual pixels.
Run only after both full-resolution cores exist. Does not assemble the main episode.
"""
from pathlib import Path
import subprocess,json,hashlib
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];E=R/'evidence';E.mkdir(exist_ok=True)
W,H=1080,1920;N=W*H*3

def decode_selected(path,indices,w=W,h=H):
 p=subprocess.Popen(['ffmpeg','-v','error','-i',str(path),'-f','rawvideo','-pix_fmt','rgb24','pipe:1'],stdout=subprocess.PIPE)
 ret={};count=0
 while True:
  b=p.stdout.read(w*h*3)
  if not b:break
  assert len(b)==w*h*3
  if count in indices:ret[count]=np.frombuffer(b,np.uint8).reshape(h,w,3).copy()
  count+=1
 assert p.wait()==0
 assert set(indices)<=set(ret),f'Missing frames {set(indices)-set(ret)}'
 return ret,count

def encode360(name,frames):
 p=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','360x640','-r','30','-i','pipe:0','-an','-vf','scale=out_color_matrix=bt709:out_range=tv,format=yuv420p','-c:v','libx264','-crf','16','-x264-params','keyint=300:min-keyint=300:scenecut=0','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-pix_fmt','yuv420p','-movflags','+faststart',str(R/name)],stdin=subprocess.PIPE)
 for a in frames:
  im=Image.fromarray(a).resize((360,640),Image.Resampling.LANCZOS);p.stdin.write(np.asarray(im).tobytes())
 p.stdin.close();assert p.wait()==0

a,na=decode_selected(R/'CORE_A_STRUCTURE.mp4',set([0,299,300,480,599]+list(range(285,345))))
b,nb=decode_selected(R/'CORE_B_WATER.mp4',set([0,60,120,180]+list(range(225,240))))
assert na==600 and nb==240
for name,arr in [('STILL_DRY_C03.png',a[299]),('STILL_DRY_PAYOFF.png',a[0]),('STILL_WET_PAYOFF.png',b[239])]:
 Image.fromarray(arr).save(R/name)
 Image.fromarray(arr).resize((360,640),Image.Resampling.LANCZOS).save(E/name.replace('.png','_360.png'))
# Source states at 02->03->04 and 05->06 use the identical decoded source pictures.
encode360('transition_C02_C03_C04_360.mp4',[a[i] for i in range(285,300)]+[a[299]]*30+[a[i] for i in range(300,345)])
encode360('transition_C05_C06_360.mp4',[b[i] for i in range(225,240)]+[b[239]]*45)

def delta(x,y):
 d=np.abs(x.astype(np.float32)-y.astype(np.float32));return {'mae':float(d.mean()),'max':float(d.max()),'equal_pixels':bool(np.array_equal(x,y))}
checks={'decoded_frame_counts':{'A':na,'B':nb},'STILL_DRY_C03_vs_core_A_299':delta(np.asarray(Image.open(R/'STILL_DRY_C03.png')),a[299]),'STILL_WET_PAYOFF_vs_core_B_239':delta(np.asarray(Image.open(R/'STILL_WET_PAYOFF.png')),b[239]),'C02_end_vs_C04_start':delta(a[299],a[300])}
for name,idx in [('transition_C02_C03_C04_360.mp4',[14,15,44,45]),('transition_C05_C06_360.mp4',[14,15])]:
 f,n=decode_selected(R/name,set(idx),360,640)
 checks[name]={'frames':n,'boundary_1':delta(f[idx[0]],f[idx[1]])}
 if len(idx)>2:checks[name]['boundary_2']=delta(f[idx[2]],f[idx[3]])
# Same rim/background pixels: geometric correspondence is measured separately from wet-state differences.
for label,box in [('background',(100,100,900,550)),('upper_cup_rim',(70,625,875,725))]:
 x0,y0,x1,y1=box;dry=a[0][y0:y1,x0:x1];wet=b[239][y0:y1,x0:x1]
 gx=np.gradient(np.mean(dry.astype(float),axis=2))[1];gy=np.gradient(np.mean(wet.astype(float),axis=2))[1]
 scores=[]
 for dy in range(-3,4):
  for dx in range(-3,4):
   scores.append((float(np.mean((gx[4:-4,4:-4]-gy[4+dy:gy.shape[0]-4+dy,4+dx:gy.shape[1]-4+dx])**2)),dx,dy))
 best=min(scores);checks['dry_wet_'+label]={'box':box,**delta(dry,wet),'best_edge_shift_px':([best[1],best[2]] if label=='upper_cup_rim' else None),'note':'Wet reflections may change color; camera and model transforms are checked in geometry_and_camera_checks.json'}
(E/'pixel_join_checks.json').write_text(json.dumps(checks,indent=2))
# Real video frames, not substitute concept cards. Contact sheets are evidence only.
for label,frames in [('CORE_A',[(0,a[0]),(299,a[299]),(480,a[480]),(599,a[599])]),('CORE_B',[(0,b[0]),(60,b[60]),(120,b[120]),(180,b[180]),(239,b[239])])]:
 sheet=Image.new('RGB',(360*len(frames),665),'#eeeeee');d=ImageDraw.Draw(sheet)
 for k,(f,img) in enumerate(frames):
  im=Image.fromarray(img).resize((360,640),Image.Resampling.LANCZOS);sheet.paste(im,(360*k,25));d.text((360*k+8,7),f'{label} frame {f} / {f/30:.2f}s',fill='black')
 sheet.save(E/(label+'_video_contact_360.png'))
# Add actual output hashes to camera states; numeric transforms were read from Blender itself.
locks=json.loads((R/'camera_lock.json').read_text())
for key,source,media,idx in [('CAM_C01_REVEAL','0001.png','CORE_A_STRUCTURE.mp4',0),('CAM_C02_END','0120.png','CORE_A_STRUCTURE.mp4',299),('CAM_C04_CONTACT','0240.png','CORE_A_STRUCTURE.mp4',599),('CAM_C05_END','0480.png','CORE_B_WATER.mp4',239),('CAM_C04_START','0121.png','CORE_A_STRUCTURE.mp4',300)]:
 locks[key]['core_media']=media;locks[key]['core_frame_zero_based']=idx
 locks[key]['decoded_frame_rgb_sha256']=hashlib.sha256((b[idx] if media=='CORE_B_WATER.mp4' else a[idx]).tobytes()).hexdigest()
 locks[key]['native_render_sha256']=hashlib.sha256((R/'native_keys'/source).read_bytes()).hexdigest()
 locks[key]['denoised_render_sha256']=hashlib.sha256((R/'clean_keys'/source).read_bytes()).hexdigest()
locks['CAM_C04_START']['protected_output_native_source']='0120.png (same camera/model state; identical C02 protected hold)'
(R/'camera_lock.json').write_text(json.dumps(locks,indent=2))
print(json.dumps(checks,indent=2),flush=True)
