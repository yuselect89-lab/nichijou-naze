"""Inspect saved scene values; compare unchanged cached prefix against saved prior scene."""
import bpy,json,hashlib
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=bpy.context.scene
mat=bpy.data.materials['Fried noodle porous dry to wetted'];assert mat.get('wet_material_version')=='local_contact_03'
assert 'LOCAL_CAPILLARY_CONTACT_PROGRESS' in mat.node_tree.nodes
assert 'LOWER_WET_CONTACT_CONTRAST_03' in mat.node_tree.nodes
def ancestors(sock,seen=None):
 seen=set() if seen is None else seen
 for link in sock.links:
  node=link.from_node
  if node.name in seen:continue
  seen.add(node.name)
  for inp in node.inputs:ancestors(inp,seen)
 return seen
for socket in ['Base Color','Roughness']:
 assert 'LOCAL_CAPILLARY_CONTACT_PROGRESS' in ancestors(mat.node_tree.nodes['Principled BSDF'].inputs[socket])
rows=[]
for f in [398,404,414,425,430,431,434,450,480]:
 s.frame_set(f);nodes=mat.node_tree.nodes
 rows.append({'frame':f,'capillary_progress':nodes['LOCAL_CAPILLARY_CONTACT_PROGRESS'].outputs[0].default_value,'contact_height':nodes['WET_CONTACT_HEIGHT'].outputs[0].default_value,'water_fill':bpy.data.objects['Water_Transparent_Body_Meniscus'].data.shape_keys.key_blocks['Fill_and_beneath_noodles'].value,'stream_hidden':[o.hide_render for o in bpy.data.objects if o.name.startswith('Water_') and 'Body' not in o.name],'camera':list(s.camera.location)})
assert rows[4]['water_fill']==1 and rows[4]['capillary_progress']==1
assert all(rows[5]['stream_hidden'])
def prefix():
 m=bpy.data.materials['Fried noodle porous dry to wetted'];b=bpy.data.objects['Water_Transparent_Body_Meniscus'];out=[]
 for f in range(1,399):
  bpy.context.scene.frame_set(f);out.append([m.node_tree.nodes['WET_CONTACT_HEIGHT'].outputs[0].default_value,b.data.shape_keys.key_blocks['Fill_and_beneath_noodles'].value])
 return out
old=r/'evidence/wet02_before_final_timing_fix/SHARED_wet02.blend';err=None;prior_capillary_present=None
if old.exists():
 before=prefix();bpy.ops.wm.open_mainfile(filepath=str(old));prior_capillary_present='LOCAL_CAPILLARY_CONTACT_PROGRESS' in bpy.data.materials['Fried noodle porous dry to wetted'].node_tree.nodes;after=prefix();err=max(abs(a-b) for x,y in zip(before,after) for a,b in zip(x,y));assert err<1e-6,err
# Historical comparison source is optional; it is not an editing dependency.

result={'saved_wet_material_version':'local_contact_03','local_mask_present_and_linked':True,'prior_saved_scene_capillary_present':prior_capillary_present,'prefix_frames_1_to_398_max_parameter_delta':err,'flow_and_wetting_complete_before_camera_return':True,'actual_states':rows,'scope':'Read actual saved .blend; final-pixel art review is separate'}
(r/'evidence/final_wet_scene_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
