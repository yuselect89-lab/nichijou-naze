"""Local Intel Open Image Denoise 1.4.3, no cloud/API. Display PNG -> linear -> RT filter.
Install: python3 -m pip install --target <local path> oidn==0.2.1
Set CUP_OIDN_PATH to that local directory, or install oidn into active Python.
"""
import os,sys
from pathlib import Path
p=os.environ.get('CUP_OIDN_PATH')
if p:sys.path.insert(0,p)
import numpy as np
from PIL import Image
import oidn
class Denoiser:
 def __init__(self):self.d=oidn.NewDevice();oidn.CommitDevice(self.d)
 def process(self,src,dst):
  a=np.asarray(Image.open(src).convert('RGB'),np.float32)/255
  a=np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4).astype(np.float32);a=np.ascontiguousarray(a)
  out=np.empty_like(a);h,w=a.shape[:2];f=oidn.NewFilter(self.d,'RT')
  oidn.SetSharedFilterImage(f,'color',a,oidn.FORMAT_FLOAT3,w,h);oidn.SetSharedFilterImage(f,'output',out,oidn.FORMAT_FLOAT3,w,h)
  oidn.CommitFilter(f);oidn.ExecuteFilter(f);err=oidn.GetDeviceError(self.d);oidn.ReleaseFilter(f)
  if err:raise RuntimeError('OIDN error '+str(err))
  out=np.maximum(out,0);out=np.where(out<=.0031308,12.92*out,1.055*np.power(out,1/2.4)-.055)
  Image.fromarray(np.uint8(np.clip(out,0,1)*255)).save(dst)
if __name__=='__main__':Denoiser().process(sys.argv[1],sys.argv[2])
