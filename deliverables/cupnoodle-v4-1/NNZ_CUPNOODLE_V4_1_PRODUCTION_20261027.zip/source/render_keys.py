"""Native 1080x1920, actual 3D camera frames. Run within Blender.
-- frames (comma-separated) or -- A/B. No resize, no digital camera zoom.
"""
import bpy,sys,time,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];s=bpy.context.scene
args=sys.argv[sys.argv.index('--')+1:];which=args[0]
if which=='A':frames=list(range(1,241,10))+list(range(61,112,5))+list(range(121,237,5))+[240,120,121,193]
elif which=='B':frames=list(range(241,481,10))+list(range(241,284))+list(range(431,471))+[480,400,329,375,450]
else:frames=[int(x) for x in which.split(',')]
frames=sorted(set(frames))
if which=='B':frames=[400,480]+[f for f in frames if f not in [400,480]]
out=R/'native_keys';out.mkdir(exist_ok=True)
s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100;s.cycles.use_denoising=False
records=[]
for f in frames:
 target=out/f'{f:04d}.png'
 if target.exists():print('REUSE_NATIVE',f,flush=True);continue
 
 if which=='B' and (out/'0240.png').exists():s.render.threads=4
 s.frame_set(f);s.render.filepath=str(target);t=time.time();result=bpy.ops.render.render(write_still=True)
 if 'FINISHED' not in result:raise RuntimeError('Render cancelled; do not reuse incomplete frames')
 c=s.camera;records.append({'frame':f,'render_seconds':time.time()-t,'camera_position':list(c.location),'camera_rotation':list(c.rotation_euler),'lens_mm':c.data.lens,'engine':s.render.engine,'samples':s.cycles.samples,'size':[1080,1920]})
 print('NATIVE_DONE',f,time.time()-t,flush=True)
 (R/'evidence'/('native_'+(which if len(which)<100 else hashlib.sha256(which.encode()).hexdigest()[:16])+'.json')).write_text(json.dumps(records,indent=2))
