"""Bounded final local fix: water completes before return; underside wet contrast.
No model/camera/light rebuild. All evaluated integer source states <=398 retained.
"""
import bpy,math
from pathlib import Path

def apply():
 mat=bpy.data.materials['Fried noodle porous dry to wetted']
 if mat.get('wet_material_version')=='local_contact_03':return
 n=mat.node_tree.nodes;l=mat.node_tree.links
 if 'LOCAL_CAPILLARY_CONTACT_PROGRESS' not in n:
  # Verify saved .blend, not only the builder: the previous scene lacked this node.
  principled=n.get('Principled BSDF');wetcol=principled.inputs['Base Color'].links[0].from_node;rough=principled.inputs['Roughness'].links[0].from_node
  combined=rough.inputs[0].links[0].from_socket;sep=next(x for x in n if x.type=='SEPXYZ')
  def mathnode(op,a,b=0):
   q=n.new('ShaderNodeMath');q.operation=op
   for idx,x in enumerate([a,b]):
    if hasattr(x,'node'):l.new(x,q.inputs[idx])
    else:q.inputs[idx].default_value=x
   return q.outputs[0]
  cap=n.new('ShaderNodeValue');cap.name='LOCAL_CAPILLARY_CONTACT_PROGRESS'
  for f,v in [(1,0),(240,0),(241,0),(398,0),(414,.4),(432,.9),(442,1),(480,1)]:cap.outputs[0].default_value=v;cap.outputs[0].keyframe_insert('default_value',frame=f)
  wetcombined=combined
  for idx,cx in enumerate([-.43,.43]):
   prog=n.new('ShaderNodeMapRange');prog.clamp=True;prog.inputs['From Min'].default_value=idx*.16;prog.inputs['From Max'].default_value=1;l.new(cap.outputs[0],prog.inputs[0]);pv=prog.outputs[0]
   xx=mathnode('SUBTRACT',sep.outputs['X'],cx);yy=mathnode('ADD',sep.outputs['Y'],.60)
   dd=mathnode('SQRT',mathnode('ADD',mathnode('MULTIPLY',xx,xx),mathnode('MULTIPLY',yy,yy)))
   rad=mathnode('ADD',.18,mathnode('MULTIPLY',pv,.80))
   edge=n.new('ShaderNodeMapRange');edge.clamp=True;l.new(dd,edge.inputs[0]);l.new(mathnode('SUBTRACT',rad,.12),edge.inputs['From Min']);l.new(mathnode('ADD',rad,.08),edge.inputs['From Max']);edge.inputs['To Min'].default_value=1;edge.inputs['To Max'].default_value=0
   front=mathnode('ADD',.94,mathnode('MULTIPLY',pv,.68));zd=mathnode('SUBTRACT',sep.outputs['Z'],front)
   zm=n.new('ShaderNodeMapRange');zm.clamp=True;l.new(zd,zm.inputs[0]);zm.inputs['From Min'].default_value=-.045;zm.inputs['From Max'].default_value=.045;zm.inputs['To Min'].default_value=1;zm.inputs['To Max'].default_value=0
   patch=mathnode('MULTIPLY',mathnode('MULTIPLY',edge.outputs[0],zm.outputs[0]),pv);wetcombined=mathnode('MAXIMUM',wetcombined,patch)
  l.new(wetcombined,wetcol.inputs[0]);l.new(wetcombined,rough.inputs[0])
 def retime(owner,path,keys,index=0):
  # Bake the unchanged prefix so auto Bezier handles cannot modify prior renders.
  curve=next(c for c in owner.id_data.animation_data.action.fcurves if c.data_path==owner.path_from_id(path) and c.array_index==index)
  prefix=[(f,curve.evaluate(f)) for f in range(1,399)]
  while len(curve.keyframe_points):curve.keyframe_points.remove(curve.keyframe_points[0],fast=True)
  curve.update()
  for f,v in prefix+keys:
   k=curve.keyframe_points.insert(f,v,options={'FAST'});k.interpolation='LINEAR'
  curve.update()
 wet=n['WET_CONTACT_HEIGHT'];retime(wet.outputs[0],'default_value',[(410,1.12),(430,1.4),(480,1.4)])
 cap=n['LOCAL_CAPILLARY_CONTACT_PROGRESS'];retime(cap.outputs[0],'default_value',[(414,.6),(425,.95),(430,1),(480,1)])
 body=bpy.data.objects['Water_Transparent_Body_Meniscus'];key=body.data.shape_keys.key_blocks['Fill_and_beneath_noodles']
 retime(key,'value',[(404,.65),(430,1),(480,1)])
 inlet=bpy.data.objects['Water_Inlet_continuous_column'];retime(inlet.data.shape_keys.key_blocks['Pour_tail_falls_down'],'value',[(421,0),(430,1),(480,1)])
 # Visibility curves are discrete; existing early states remain unchanged.
 for obj,end in [(inlet,431)]+[(o,431) for o in bpy.data.objects if o.name.startswith('Water_interstice_downflow_')]:
  curve=next(c for c in obj.animation_data.action.fcurves if c.data_path=='hide_render')
  for i in range(len(curve.keyframe_points)-1,-1,-1):
   if curve.keyframe_points[i].co.x>398:curve.keyframe_points.remove(curve.keyframe_points[i],fast=True)
  for f in [end,480]:
   k=curve.keyframe_points.insert(f,1);k.interpolation='CONSTANT'
  curve.update()
 for obj in bpy.data.objects:
  if obj.name.startswith('Water_interstice_downflow_'):
   retime(obj.data.shape_keys.key_blocks['Downflow_tail_falls_to_basin'],'value',[(421,0),(430,1),(480,1)])
 # Add a small extra darkening only where the bottom-contact mask has developed.
 principled=n.get('Principled BSDF');previous=principled.inputs['Base Color'].links[0].from_socket
 wetmask=principled.inputs['Roughness'].links[0].from_node.inputs[0].links[0].from_socket
 geo=next(x for x in n if x.type=='NEW_GEOMETRY');sep=n.new('ShaderNodeSeparateXYZ');l.new(geo.outputs['Position'],sep.inputs[0])
 lower=n.new('ShaderNodeMath');lower.operation='LESS_THAN';lower.inputs[1].default_value=1.72;l.new(sep.outputs['Z'],lower.inputs[0])
 mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY';l.new(wetmask,mul.inputs[0]);l.new(cap.outputs[0],mul.inputs[1])
 fac=n.new('ShaderNodeMath');fac.operation='MULTIPLY';l.new(mul.outputs[0],fac.inputs[0]);l.new(lower.outputs[0],fac.inputs[1])
 col=n.new('ShaderNodeMixRGB');col.name='LOWER_WET_CONTACT_CONTRAST_03';col.blend_type='MULTIPLY';col.inputs[2].default_value=(.85,.88,.90,1);l.new(previous,col.inputs[1]);l.new(fac.outputs[0],col.inputs[0]);l.new(col.outputs[0],principled.inputs['Base Color'])
 mat['wet_material_version']='local_contact_03'
 bpy.context.scene['wet_timing']='Flow/tail/meniscus/local wetting complete by 430; stream hidden 431; fixed camera through 434 then return.'
if __name__=='__main__':
 apply();bpy.context.scene.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(Path(__file__).parent/'CUPNOODLE_V4_1_SHARED.blend'))
 print('FINAL_LOCAL_WETTING_03_SAVED',flush=True)
