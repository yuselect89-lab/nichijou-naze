"""Private local ZIP only. No upload or publish operation exists in this script."""
from pathlib import Path
import hashlib,zipfile,json
R=Path(__file__).resolve().parents[1]
# Preserve original trace; aggregate actual final production logs before hashing.
initial=R/'evidence/initial_backend_render.log'
if not initial.exists() and (R/'render.log').exists():initial.write_bytes((R/'render.log').read_bytes())
traces=['render_A.log','render_B.log','render_camera_refinement.log','render_B_camera_native30.log','render_B_wet03_native30.log','render_B_intro_endpoint_native30.log','final_wet_scene_checks.log','prepare_A.log','prepare_B_native30.log']
parts=['LOCAL BLENDER / OIDN / FFMPEG ACTUAL PRODUCTION TRACE\nNative 1080x1920; no API or paid service. A optical-flow/retimed; B moving cameras direct native 30fps.\n']
for name in traces:
 p=R/'evidence'/name
 if p.exists():parts.append('\n===== '+name+' =====\n'+p.read_text())
(R/'render.log').write_text(''.join(parts))
required=['CORE_A_STRUCTURE.mp4','CORE_B_WATER.mp4','STILL_DRY_C03.png','STILL_DRY_PAYOFF.png','STILL_WET_PAYOFF.png','CORE_A_360_review.mp4','CORE_B_360_review.mp4','transition_C02_C03_C04_360.mp4','transition_C05_C06_360.mp4','camera_lock.json','manifest.json','QC_RESULT.md','render.log','verification.log']
files=[R/n for n in required]
for p in files:assert p.is_file(),p
files += [p for p in (R/'source').iterdir() if p.is_file() and p.suffix in ['.py','.mjs','.md','.txt','.json','.blend']]
files += [p for p in (R/'input_orders').rglob('*') if p.is_file()]
# Only final evidence, not superseded native caches, unfinished movies or FAIL history.
for n in ['geometry_and_camera_checks.json','pixel_join_checks.json','media_verification.json','ART_QC.json','CACHE_PROVENANCE.json','preservation_check.json','CORE_A_video_contact_360.png','CORE_B_video_contact_360.png','preflight.log','final-production-lock.log','final_playback.log','B_WET03_STAGE_COMPARE_360.png','B_WET03_FLOW_COMPARE_360.png','npm-test.log','library-preflight.json','temporal_start_check.json','NEW_MODEL_AUTHORIZATION.json','B_NATIVE30_CHECK_0254.png','final_wet_scene_checks.json','final_wetting_patch.log','standalone_source_rebuild_checks.json','standalone_source_rebuild.log']:
 p=R/'evidence'/n
 if p.exists():files.append(p)
for p in (R/'evidence').glob('browser_*/playback.json'):files.append(p)
files=sorted(set(files));sums=R/'SHA256SUMS.txt';sums.write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(R)) for p in files)+'\n')
zipname=R/'NNZ_CUPNOODLE_V4_1_PRODUCTION_20261027.zip'
with zipfile.ZipFile(zipname,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[sums]:z.write(p,p.relative_to(R))
with zipfile.ZipFile(zipname) as z:assert z.testzip() is None
print(zipname,zipname.stat().st_size,hashlib.sha256(zipname.read_bytes()).hexdigest(),flush=True)
