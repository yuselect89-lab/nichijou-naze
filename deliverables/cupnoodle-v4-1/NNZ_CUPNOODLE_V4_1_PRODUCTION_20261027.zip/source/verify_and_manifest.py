"""Verify real deliverables and write hashes/manifest. Never invent absent media.
Internal art decisions are read from evidence/ART_QC.json, not inferred from codec success.
"""
from pathlib import Path
import json,subprocess,hashlib,ast
from PIL import Image
R=Path(__file__).resolve().parents[1];E=R/'evidence'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'CORE_A_STRUCTURE.mp4':(1080,1920,600,20),'CORE_B_WATER.mp4':(1080,1920,240,8),'CORE_A_360_review.mp4':(360,640,600,20),'CORE_B_360_review.mp4':(360,640,240,8),'transition_C02_C03_C04_360.mp4':(360,640,90,3),'transition_C05_C06_360.mp4':(360,640,60,2)}
assets=[];logs=[]
for name,(w,h,count,dur) in expected.items():
 p=R/name;assert p.exists(),name
 info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=codec_name,codec_type,width,height,r_frame_rate,nb_frames,nb_read_frames:format=duration','-of','json',str(p)]))
 assert len(info['streams'])==1 and info['streams'][0]['codec_type']=='video',name
 st=info['streams'][0];assert (st['width'],st['height'],int(st['nb_read_frames']))==(w,h,count),info
 assert st['r_frame_rate']=='30/1' and abs(float(info['format']['duration'])-dur)<.001,info
 subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(p),'-f','null','-'],check=True)
 assets.append({'file':name,'sha256':sha(p),'bytes':p.stat().st_size,'width':w,'height':h,'fps':30,'frames':count,'seconds':dur,'audio_streams':0,'codec':st['codec_name']});logs.append({'file':name,'ffprobe':info,'decode':'PASS'})
for name in ['STILL_DRY_C03.png','STILL_DRY_PAYOFF.png','STILL_WET_PAYOFF.png']:
 p=R/name
 with Image.open(p) as im:assert im.size==(1080,1920);im.verify()
 assets.append({'file':name,'sha256':sha(p),'bytes':p.stat().st_size,'width':1080,'height':1920})
for p in (R/'source').glob('*.py'):ast.parse(p.read_text())
geometry=json.loads((E/'geometry_and_camera_checks.json').read_text());assert geometry['noodle_end_caps'] and geometry['bottom_clearance']>0 and geometry['same_01_05_camera'] and geometry['same_02_04_camera']
art=json.loads((E/'ART_QC.json').read_text()) if (E/'ART_QC.json').exists() else {'CORE_A':'NOT_REVIEWED','CORE_B':'NOT_REVIEWED'}
manifest={'project':'CUPNOODLE_RECOVERY_20261025','specification':'V4.1 G2 MINOR FIX reflected','model_origin':'New common model authorized by user after missing old source; no legacy model is claimed recovered','asset_id':'NNZ_CUPNOODLE_SHARED_MODEL','asset_version':'4.1.03','geometry_version':geometry['model_version'],'wet_material':'local_contact_03','shared_scene':'source/CUPNOODLE_V4_1_SHARED.blend','scene_sha256':sha(R/'source/CUPNOODLE_V4_1_SHARED.blend'),'status':('PARTIAL_PASS_CORE_B_CUT05_FAIL' if str(art.get('CORE_B','')).startswith('FAIL') else 'MATERIALS_RENDERED_PENDING_ACCEPTANCE'),'internal_art_qc':art,'external_g2':'User-supplied MINOR FIX with 3 adopted corrections; no new Gemini re-review claimed','timing_status':'TEMP_FOR_EDIT; original VO not synchronized or regenerated','core_A_sections':{'A01':{'frames':[0,150],'role':'bottom gap / C01','source_blender_range':[1,61]},'A02':{'frames':[150,300],'role':'structure / C02','final_hold':[285,300],'source_end_blender_frame':120},'A04':{'frames':[300,600],'role':'true 3D contact dolly / C04','source_blender_range':[121,240]}},'core_B_sections':{'B00':[0,60],'B25':[60,105],'B50':[105,150],'B75':[150,193],'B95':[193,240],'final_hold':[230,240]},'stills':{'STILL_DRY_C03.png':{'video':'CORE_A_STRUCTURE.mp4','frame':299,'camera':'CAM_C02_END'},'STILL_DRY_PAYOFF.png':{'video':'CORE_A_STRUCTURE.mp4','frame':0,'camera':'CAM_C01_REVEAL'},'STILL_WET_PAYOFF.png':{'video':'CORE_B_WATER.mp4','frame':239,'camera':'CAM_C05_END = CAM_C01_REVEAL'}},'render_method':{'native_size':[1080,1920],'renderer':'Blender Cycles CPU','max_samples':8,'denoiser':'Local Intel OIDN 1.4.3 / wrapper 0.2.1','temporal':'A: native 1080p 3Hz source grid plus 6Hz camera refinements, optical-flow interpolation and editorial retiming. B: direct 30fps native 3D renders for moving cameras (source 241–283,431–470); fixed-camera middle uses 3Hz native keys and optical flow. Exact native protected holds. Local OIDN; no resolution upscale or still-image digital zoom.','source_scene_fps':30,'native_key_file_count':len(list((R/'native_keys').glob('*.png')))},'water_method':'Controlled transparent 3D mesh, gravity-downward threads, meniscus and surface-contact-linked local wetting; educational approximation, not measured fluid dynamics','library_use':{'preflight_report':'evidence/library-preflight.json','decision':'create; new model explicitly authorized by user','shared_library_assets_consumed':[],'registration':'EP-local source, not a shared-library production-approved registration; no library check PASS claimed without references'},'rights':'Original task-created procedural cup/noodles/water; no third-party visual asset or logo. OIDN software dependency Apache-2.0.','originals':'No approved banner, character, script, VO or old EP modified; no main edit, external send, publication, API generation or payment','assets':assets,'camera_lock':'camera_lock.json','camera_states':json.loads((R/'camera_lock.json').read_text()),'pixel_checks':'evidence/pixel_join_checks.json','geometry_checks':'evidence/geometry_and_camera_checks.json'}
(R/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(E/'media_verification.json').write_text(json.dumps(logs,indent=2))
(R/'verification.log').write_text('All six videos decoded; measured sizes/frame counts/30fps/no audio verified.\nThree 1080x1920 stills verified.\nAll Python source parsed.\nGeometry/camera checks passed.\nArt review is separate: '+json.dumps(art,ensure_ascii=False)+'\n')
print('VERIFIED',len(assets),'actual media files',flush=True)
