"""Native full-resolution 3D keys -> local denoise -> temporal retiming/interpolation.
A = 600f/20s (5s reveal, 5s structure incl. .5s hold, 10s contact).
B = 240f/8s. Timing is editorial handles, not VO-locked.
No resolution upscale and no digital zoom of a static image.
"""
from pathlib import Path
import sys,subprocess,shutil,json,hashlib
from fractions import Fraction
from PIL import Image
from denoise import Denoiser
R=Path(__file__).resolve().parents[1];mode=sys.argv[1];d=Denoiser();clean=R/'clean_keys';clean.mkdir(exist_ok=True)
for p in sorted((R/'native_keys').glob('*.png')):
 if mode=='A' and int(p.stem)>240:continue
 dst=clean/p.name
 if not dst.exists():
  try:
   with Image.open(p) as check:check.verify()
  except (OSError,ValueError):continue
  d.process(p,dst);print('DENOISED',p.stem,flush=True)
if mode=='clean':raise SystemExit
assert mode in ['A','B'];work=R/'render_cache'/mode/'v2';dense=work/'dense';dense.mkdir(parents=True,exist_ok=True)
def interpolate(label,frames,rate,count):
 grid=work/label/'grid';tmp=work/label/'dense';grid.mkdir(parents=True,exist_ok=True);tmp.mkdir(exist_ok=True)
 signature=hashlib.sha256(json.dumps({'frames':frames,'rate':str(rate),'count':count,'input_sha':[hashlib.sha256((clean/f'{f:04d}.png').read_bytes()).hexdigest() for f in frames],'method':'mci_aobmc_bidir_vsbmc16_search64_padded_pts_passthrough'}).encode()).hexdigest()
 sigfile=tmp/'signature.txt'
 if sigfile.exists() and sigfile.read_text()==signature and len(list(tmp.glob('*.png')))==count:
  return [tmp/f'{k:04d}.png' for k in range(count)]
 for k,f in enumerate(frames):
  src=clean/f'{f:04d}.png';assert src.exists(),f'Missing native {f}';shutil.copy2(src,grid/f'{k:04d}.png')
 pad=round(60/float(Fraction(str(rate))))
 subprocess.run(['ffmpeg','-y','-v','error','-threads','3','-filter_threads','3','-framerate',str(rate),'-i',str(grid/'%04d.png'),'-vf',f'tpad=start=2:start_mode=clone:stop=3:stop_mode=clone,minterpolate=fps=30:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1:mb_size=16:search_param=64,settb=1/30,trim=start_pts={pad}:end_pts={pad+count},setpts=PTS-STARTPTS','-fps_mode','passthrough','-frames:v',str(count),'-compression_level','1','-start_number','0',str(tmp/'%04d.png')],check=True)
 assert len(list(tmp.glob('*.png')))==count,'Temporal output frame count mismatch'
 sigfile.write_text(signature)
 return [tmp/f'{k:04d}.png' for k in range(count)]
if mode=='A':
 # Native 61 is the same end camera as source 60. Native 111/120 share C02_END.
 seq=interpolate('A01',list(range(1,62,10)),'6/5',150)
 seq+=interpolate('A02_refined',list(range(61,112,5)),'20/9',135)
 seq+=[clean/'0120.png']*15
 seq+=interpolate('A04_refined',list(range(121,237,5))+[240],'12/5',300)
 count=600;seq[0]=clean/'0001.png';seq[300]=clean/'0120.png'
 for k in range(570,600):seq[k]=clean/'0240.png'
else:
 seq=[clean/f'{f:04d}.png' for f in range(241,284)]
 seq+=interpolate('B_middle',list(range(281,432,10)),3,150)[3:]
 seq+=[clean/f'{f:04d}.png' for f in range(431,471)]
 seq+=[clean/'0480.png']*10;count=240
for k,p in enumerate(seq):shutil.copy2(p,dense/f'{k:04d}.png')
assert len(seq)==count
name='CORE_A_STRUCTURE.mp4' if mode=='A' else 'CORE_B_WATER.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-threads','3','-filter_threads','3','-framerate','30','-i',str(dense/'%04d.png'),'-frames:v',str(count),'-an','-vf','scale=out_color_matrix=bt709:out_range=tv,format=yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-c:v','libx264','-preset','medium','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(R/name)],check=True)
subprocess.run(['ffmpeg','-y','-v','error','-threads','3','-i',str(R/name),'-vf','scale=360:640:flags=lanczos:out_color_matrix=bt709','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(R/f'CORE_{mode}_360_review.mp4')],check=True)
print('CORE_READY',name,count,flush=True)
