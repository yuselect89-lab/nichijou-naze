# Cup Noodles V4.1 — one editable scene / two silent production cores

The user explicitly authorized a new shared model after the old source was confirmed missing. No old model is claimed recovered. All cup/noodle geometry, water control meshes, materials, lights and cameras are new procedural work created locally for this task. No logos, stock image, outside model, paid generation or API render service is used.

Blender 4.3.2 / Cycles CPU. The included CUPNOODLE_V4_1_SHARED.blend contains the entire editable 30fps animation. Native resolution is 1080×1920; the scene can render every frame directly if desired. Source frames 1–240 are the CORE_A camera path; 241–480 are CORE_B. The delivered CORE_A retimes that path to 600 frames/20s (A01 5s, A02 5s including a .5s hold, A04 10s). CORE_B is 240 frames/8s with a .33s final hold. These are editing handles, not VO-locked timing. Geometry/material/camera changes are made once and affect both cores.

The builder calls finalize_wetting.py so the saved local-contact shader and final timing are reproduced, not merely described in source comments. check_wet_scene.py inspects actual linked nodes and evaluated states; its optional comparison with archived old source is not a dependency of the delivered scene.

Rebuild the shared scene:
  blender -b -t 4 --python-exit-code 1 --python source/build_scene.py -- --build-only
Inspect camera and geometry:
  blender -b source/CUPNOODLE_V4_1_SHARED.blend --python-exit-code 1 --python source/inspect_scene.py
Render native 1080p key images (or provide explicit comma-separated Blender frame numbers):
  blender -b source/CUPNOODLE_V4_1_SHARED.blend -t 4 --python-exit-code 1 --python source/render_keys.py -- A
  blender -b source/CUPNOODLE_V4_1_SHARED.blend -t 4 --python-exit-code 1 --python source/render_keys.py -- B

Production processing uses actual native 1080×1920 3D renders: CORE_A uses a 3Hz source grid plus 6Hz source-time camera refinements and editorial retiming to 20s. CORE_B uses direct 30fps source frames for both camera-moving intervals (241–283 and 431–470); its fixed-camera middle uses 3Hz keys plus full-resolution optical-flow interpolation. All renders receive local Intel OIDN 1.4.3 denoising before encoding to 30fps. It does not upscale lower-resolution renders or zoom a single still. Exact held frames replace interpolated endpoints for the edit joins. This temporal interpolation is part of the delivered workflow; inspect moving noodle edges, contact and water before approval. Native key caches and intermediate dense PNGs are not required as external dependencies: they are recreated by these scripts.

Install free Python dependencies in your local environment: numpy, Pillow and oidn==0.2.1. OIDN's wrapper and library use Apache-2.0 (license included). Set CUP_OIDN_PATH to a local --target installation path only if oidn is not installed in active Python.
  CUP_OIDN_PATH=/path/to/local/oidn python3 source/prepare_video.py A
  CUP_OIDN_PATH=/path/to/local/oidn python3 source/prepare_video.py B
ffmpeg with libx264 and minterpolate is required. Source values and effects are editable; rendering every 30fps source frame instead of temporal interpolation is also possible by passing explicit frame lists and directly encoding that dense sequence.

The model uses solid capped noodle strands; the cup shell has outward solid normals.

The front optical window alters the cup material opacity; the full-thickness cup mesh and base remain geometrically intact. Noodles are capped, bevelled, crinkled individual curves with a finite side-contact band; no support posts. Cup and noodles share a parent for transport micro-motion. Proportions are schematic, not measured product dimensions.

Water is a transparent controlled mesh with IOR 1.333, descending interstitial threads, a rising meniscus and contact-height wetting plus two expanding local porous-wetting patches on the lower noodles (verified saved shader local_contact_03). The final local patch completes flow, liquid level and wetting at source430; stream visibility ends431, before the camera returns after434. Top pour-contact wetting is separate. This is an educational approximation, not a measured fluid/thermal simulation. It adds no upward jet, pump loop, colored tracer or particle shortcut.

No VO, captions, approved banner, progress bar, character, music or sound is burned into the materials. Work assembles the final six cuts after material acceptance. The final parent edit uses the approved banner and single progress bar once; display captions remove 「、」 and retain 「。」. Presenter roles: focus_only during the core mechanism, existing think/reaction assets belong to Work's C03/C06 assembly. No main edit was made here.

The optional playback_check.mjs QC utility additionally needs Node >=22, @remotion/renderer and local Chromium at /usr/bin/chromium. It serves MP4s only on 127.0.0.1, plays them at 1.0x and records decoding/drop counters; this is not independent art approval. Blender scene editing and rendering do not depend on Node or the repository application.

After preparing both cores, run python3 source/finish_delivery.py to regenerate actual extracted stills, join-test MP4s and frame hashes. Inspect the changed media and update evidence/ART_QC.json with the actual art decision; previous approval does not apply to an edited render. Then python3 source/verify_and_manifest.py validates measured media and python3 source/package_delivery.py produces the local ZIP. Source-native caches, old failed variants and node_modules are excluded from the ZIP.
