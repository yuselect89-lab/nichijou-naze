# ウインカー編 V3 VIDEO_03

media/C01_1080.mp4〜C06_1080.mp4：6カットの無音動画素材。C01を受領動画と表示点滅の局所合成で追加。C02〜06は前版を保全。

previews/C01_360.mp4：今回のC01等速確認用。代表フレームとQCはpreviews/、evidence/、QC_RESULT.md。過去不合格候補はREJECTED_REVIEW表記の確認用であり本編素材ではない。

source/compose_c01.py：C01の編集可能ソース。input/C01_REPLACEMENT_ORIGINAL.mp4：入力原本。layers/C01_DISPLAY_CORRECTION_ALPHA.mov：分離した表示補正。C05の背景と前景もlayers/に分離。C03/C04/C06はrender.pyの共通モデル。Python3+Pillow+numpy+FFmpegで再制作。

6カットが存在することと本番合格は別。C02外観照合、VO意味同期、全体G3は未了。正式帯・本字幕・全編進行バーはWorkが各1回合成。字幕は表示時に「、」除去し「。」保持。音声はinput/VOICE_MASTER.mp3を分割/加工せず使用。発話に合わせたラフ本編の組立はWork担当。
