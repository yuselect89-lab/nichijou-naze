"""Native 1080x1920 layered 2.5D relay animation. No generated mechanical stills.
All three cuts use mechanism() and state() below. python render.py [--stills]
"""
from pathlib import Path
import math, json, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT=Path(__file__).resolve().parents[1]
W,H=1080,1920
FONT='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
FPS=30
# NE555 astable example: 10k + 47k + 10uF, transistor relay driver.
TH=.693*(10000+47000)*10e-6
TL=.693*47000*10e-6
PERIOD=TH+TL
def ease(x):
    x=max(0,min(1,x)); return x*x*(3-2*x)
def state(t):
    p=t%PERIOD; cmd=p<TH
    # Relay travel occurs before electrical contact. Contact and lamp share exactly one bool.
    last=p if cmd else p-TH
    travel=ease(last/.028)
    pull=travel if cmd else 1-travel
    contact=bool(pull>=1-1e-9)
    switch_age=last-.028 if cmd else last
    if switch_age<0:switch_age=p+TL
    return dict(command=cmd,pull=pull,contact=contact,lamp=contact,edge_age=last,switch_age=switch_age)

def layer(): return Image.new('RGBA',(W,H))
def txt(im,xy,s,size=31,fill='#b6c8cd'):
    ImageDraw.Draw(im).text(xy,s,font=ImageFont.truetype(FONT,size),fill=fill)
def rounded(im,box,fill,r=16,outline=None,width=1):
    ImageDraw.Draw(im).rounded_rectangle(box,r,fill=fill,outline=outline,width=width)
def shaded(im,box,colors,r=12):
    x0,y0,x1,y1=map(int,box); ww,hh=x1-x0,y1-y0
    a=np.linspace(0,len(colors)-1,hh); k=np.minimum(a.astype(int),len(colors)-2); f=(a-k)[:,None]
    cs=np.array(colors); v=(cs[k]*(1-f)+cs[k+1]*f).astype('uint8')
    pic=Image.fromarray(np.broadcast_to(v[:,None,:],(hh,ww,3)).copy()).convert('RGBA')
    mask=Image.new('L',(ww,hh)); ImageDraw.Draw(mask).rounded_rectangle((0,0,ww-1,hh-1),r,fill=255)
    im.paste(pic,(x0,y0),mask)
def metal(im,box): shaded(im,box,[(53,67,73),(198,210,208),(96,115,121),(39,52,58)],7)
def shadow(im,box,r=18):
    sh=layer(); rounded(sh,box,(0,0,0,155),r); im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(13)))
def wire(im,pts,color='#9c7860',width=7):
    d=ImageDraw.Draw(im); d.line([(x,y+4) for x,y in pts],fill='#081719',width=width+5,joint='curve')
    d.line(pts,fill=color,width=width,joint='curve')
    for x,y in (pts[0],pts[-1]): d.ellipse((x-7,y-7,x+7,y+7),fill='#bdc0a2',outline='#4e655a',width=2)
def bolt(im,x,y):
    d=ImageDraw.Draw(im); d.ellipse((x-12,y-12,x+12,y+12),fill='#738386',outline='#bac6c2',width=2)
    d.line((x-6,y-4,x+6,y+4),fill='#26373d',width=3)

def background():
    yy,xx=np.mgrid[:H,:W]; f=np.exp(-(((xx-510)/800)**2+((yy-900)/1000)**2))
    a=np.zeros((H,W,3),dtype=np.uint8)
    for i,(base,amp) in enumerate([(11,13),(19,20),(25,23)]):a[:,:,i]=base+f*amp
    return Image.fromarray(a).convert('RGBA')
BG=background()

def board_static(electronic=False):
    im=layer(); shadow(im,(125,610,920,1400));
    shaded(im,(130,590,920,1385),[(38,69,65),(27,55,52),(18,38,39)],28)
    d=ImageDraw.Draw(im)
    d.rounded_rectangle((134,594,915,1380),26,outline='#607d73',width=2)
    for x,y in [(160,620),(890,620),(160,1352),(890,1352)]:bolt(im,x,y)
    # Functional nets (not animated fictitious current paths).
    for pts in [[(215,680),(215,645),(835,645),(835,730)],[(215,795),(215,1310),(835,1310),(835,875)],[(325,740),(405,740),(405,825)],[(440,880),(440,1240),(215,1240)]]:
        wire(im,pts,'#7c9587',5)
    # IC package and actual pins, six timing passives.
    for i in range(4):
        metal(im,(190,695+i*25,220,706+i*25));metal(im,(320,695+i*25,350,706+i*25))
    shadow(im,(215,685,331,815),9)
    shaded(im,(216,679,326,808),[(58,67,69),(27,32,36),(13,19,22)],9)
    d=ImageDraw.Draw(im); d.ellipse((229,690,239,700),fill='#b8b8a5');txt(im,(235,724),'555',25,'#a8b3b0')
    for x,y in [(260,875),(335,875),(280,945)]:
        wire(im,[(x-25,y),(x+25,y)],'#c1ba9a',4)
        shaded(im,(x-15,y-8,x+15,y+8),[(222,202,151),(157,128,83)],4)
        d.line((x-5,y-7,x-5,y+6),fill='#986333',width=3)
    shaded(im,(340,900,379,956),[(112,149,147),(40,79,83)],8)
    d.ellipse((340,893,378,908),fill='#a3b8b2',outline='#425c59',width=2)
    # Driver package; flyback diode is physically across the coil net in netlist.
    for x in (416,440,464):metal(im,(x,851,x+5,890))
    shaded(im,(404,806,478,858),[(56,64,67),(13,22,28)],9);txt(im,(416,817),'Q1',21)
    if not electronic:
        # Winding spool, iron core and return yoke. Static depth and copper highlights.
        shadow(im,(320,1058,592,1245))
        metal(im,(333,1090,576,1230));metal(im,(523,963,568,1208))
        shaded(im,(332,1080,548,1200),[(91,47,27),(219,137,76),(111,58,35)],17)
        for x in range(345,541,7):
            d=ImageDraw.Draw(im);d.arc((x-8,1083,x+14,1197),-88,91,fill='#f0bc7c',width=3)
            d.arc((x-7,1086,x+13,1194),93,267,fill='#61331f',width=3)
        metal(im,(311,1071,340,1212));metal(im,(544,1071,569,1212))
        # NO fixed terminal, and pivot/COM block.
        metal(im,(740,1080,833,1126));metal(im,(766,1038,813,1090))
        metal(im,(512,961,565,1020));bolt(im,536,980)
        wire(im,[(835,875),(855,875),(855,1105),(824,1105)],'#b5a37b',8)
        wire(im,[(528,1010),(485,1010),(485,1310),(215,1310)],'#b5a37b',8)
        wire(im,[(348,1179),(295,1179),(295,653)],'#a58059',6)
        wire(im,[(550,1179),(609,1179),(609,862),(476,862)],'#a58059',6)
        wire(im,[(348,1148),(294,1148),(294,1024),(593,1024),(593,1148),(550,1148)],'#a58059',4)
        shaded(im,(402,1016,458,1032),[(57,63,64),(14,22,24)],3)
        d=ImageDraw.Draw(im);d.line((410,1017,410,1031),fill='#d9d5bf',width=5)
    else:
        # Same switching locus; low-side MOSFET replaces coil/contact assembly.
        for x in (717,757,797):metal(im,(x,1092,x+12,1195))
        shadow(im,(682,960,835,1100));metal(im,(687,943,836,1001))
        shaded(im,(687,984,836,1111),[(52,67,70),(18,30,36)],10);bolt(im,761,965)
        txt(im,(727,1024),'Q2',26)
        wire(im,[(405,855),(405,1047),(687,1047)],'#7c9587',6)
        wire(im,[(835,875),(855,875),(855,1140),(770,1140)],'#b5a37b',8)
        wire(im,[(810,1180),(810,1310)],'#7c9587',7)
    return im

STATIC={False:board_static(False),True:board_static(True)}
def lamp(im,on):
    d=ImageDraw.Draw(im)
    metal(im,(768,846,867,888))
    if on:
        glow=layer();ImageDraw.Draw(glow).ellipse((700,657,934,866),fill=(255,173,32,120));im.alpha_composite(glow.filter(ImageFilter.GaussianBlur(24)))
    shaded(im,(735,696,900,854),[(186,194,187),(52,66,68),(18,30,35)],65)
    d=ImageDraw.Draw(im)
    for r in range(70,0,-1):
        f=1-r/70
        col=(int(173+82*f),int(93+113*f),int(25+90*f)) if on else (int(77+25*f),int(67+14*f),int(41+4*f))
        d.ellipse((817-r,775-r,817+r,775+r),fill=col)
    for y in range(721,838,12):d.line((768,y,865,y),fill='#e8ad52' if on else '#817854',width=2)
    d.arc((752,709,881,841),165,258,fill='#fff2bd' if on else '#b7ae90',width=4)

def mechanism(t,electronic=False):
    im=STATIC[electronic].copy();s=state(t)
    lamp(im,s['lamp'])
    d=ImageDraw.Draw(im)
    # Tiny driver output status pad; no invented capacitor discharge or particle current.
    d.ellipse((388,777,401,790),fill='#72d7bd' if s['command'] else '#35544f')
    if not electronic:
        pull=s['pull'];y=1000+31*pull
        # Rigid metallic armature rotates about pivot, endpoint carries actual contact pad.
        arm=[(535,965),(793,y-19),(795,y-3),(536,985)]
        d.polygon([(x+4,yy+9) for x,yy in arm],fill=(0,0,0,120))
        d.polygon(arm,fill='#b3bfc0');d.line([arm[0],arm[1]],fill='#f0f0dd',width=4);d.line([arm[3],arm[2]],fill='#51636c',width=5)
        # Ferromagnetic armature above coil pole, rigidly follows blade.
        d.polygon([(551,987),(593,990+pull*20),(591,1049+pull*15),(552,1047+pull*15)],fill='#7e9399')
        metal(im,(770,y-4,807,y+7));bolt(im,536,978)
        # Contact alignment: fixed top 1038, moving bottom 1038 when closed.
        # Electrical make event happens after completed 28ms travel, matching lamp.
        if s['switch_age']<.102:
            a=int(170*(1-s['switch_age']/.102))
            for r in (29,43):d.arc((788-r,1040-r,788+r,1040+r),-65,65,fill=(174,204,209,a),width=2)
    else:
        d.rounded_rectangle((706,1002,818,1012),4,fill='#70c8ae' if s['contact'] else '#374e4e')
    return im

def labels(cut):
    im=layer()
    if cut in ('C03','C04'):
        for xy,text in [((174,522),'周期制御'),((740,522),'ランプ')]:txt(im,xy,text,38)
        txt(im,(300,1420),'電磁石' if cut=='C03' else '可動接点なし',36)
        if cut=='C03':txt(im,(695,1420),'金属接点',36)
    elif cut=='C06':
        txt(im,(147,330),'昔',41);txt(im,(147,960),'今（一部の車）',41)
    return im

def speaker(t,emphasis):
    im=layer();d=ImageDraw.Draw(im)
    # Electronic audio generator -> speaker (signal depiction, not a power current route).
    shaded(im,(195,1110,388,1280),[(51,76,80),(20,40,47)],18)
    for x in range(214,381,23):metal(im,(x,1098,x+9,1115));metal(im,(x,1278,x+9,1297))
    shaded(im,(235,1157,346,1220),[(64,77,83),(20,30,35)],7)
    txt(im,(256,1174),'IC',23)
    d.line([(388,1192),(466,1192)],fill='#80b3be',width=5)
    age=state(t)['switch_age']
    # Cone motion is physical-looking changing ellipse/rim/central dome; sample 30fps.
    # This visual slow-down of sub-frame acoustic motion is explicitly documented.
    v=math.sin(age*math.pi*2*10)*math.exp(-age*12) if age<.25 else 0
    x,y=674,1192; rx=132+v*13; ry=122+v*9
    shadow(im,(x-152,y-131,x+158,y+156))
    for i in range(12):
        r=151-i*2;d.ellipse((x-r,y-r*.90,x+r,y+r*.90),outline=(43+i*5,53+i*5,57+i*5),width=3)
    d.ellipse((x-rx,y-ry,x+rx,y+ry),fill='#303d44',outline='#7b8a8e',width=6)
    d.ellipse((x-rx+22,y-ry+20,x+rx-22,y+ry-20),fill='#202d34',outline='#495b63',width=5)
    r=49+v*13
    d.ellipse((x-r,y-r*.85-v*17,x+r,y+r*.85-v*17),fill='#657780',outline='#adbdc1',width=3)
    d.arc((x-r+8,y-r*.85+4-v*17,x+r-8,y+r*.85-8-v*17),185,300,fill='#c2cccb',width=3)
    if age<.21:
        for rr in (174,193):d.arc((x-rr,y-rr*.8,x+rr,y+rr*.8),-36,36,fill=(135,192,203,int(160*(1-age/.21))),width=3)
    if emphasis>0:
        d.line((155,1407,895,1407),fill=(109,179,188,int(140*emphasis)),width=3)
    return im

def frame(cut,f,with_labels=False):
    out=BG.copy()
    # Global oscillation phase is carried continuously across C03 and C04.
    t=f/FPS
    if cut=='C03':out.alpha_composite(mechanism(t))
    elif cut=='C04':
        t+=292/FPS
        # C03 mechanical assembly crossfades into transistor at fixed model/camera coordinates.
        a=ease(f/17)
        out.alpha_composite(Image.blend(mechanism(t),mechanism(t,True),a))
    elif cut=='C06':
        small=mechanism(t).crop((130,660,920,1320)).resize((640,535),Image.Resampling.LANCZOS)
        out.alpha_composite(small,(200,400))
        # Staged reveal: lower unit comes after the relay, provisional cue until VO available.
        a=ease((t-.62)/.35); sp=speaker(t,ease((t-1.2)/.4))
        sp.putalpha(sp.getchannel('A').point(lambda x:int(x*a)))
        out.alpha_composite(sp)
    if with_labels:out.alpha_composite(labels(cut))
    return out

COUNTS={'C03':292,'C04':119,'C06':141}
def run(stills=False):
    for cut,n in COUNTS.items():
        labels(cut).save(ROOT/'layers'/f'{cut}_labels.png')
        im=frame(cut,min(60,n-1),True);im.save(ROOT/'previews'/f'{cut}_1080.png');im.resize((360,640),Image.Resampling.LANCZOS).save(ROOT/'previews'/f'{cut}_360.png')
        if stills:continue
        p=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','30','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(ROOT/'media'/f'{cut}_1080.mp4')],stdin=subprocess.PIPE)
        for f in range(n):
            p.stdin.write(frame(cut,f).convert('RGB').tobytes())
            if f%60==0:print(cut,f,n,flush=True)
        p.stdin.close()
        if p.wait():raise RuntimeError('Encoder failed')
        # Preview includes separate optional explanation labels, final media does not.
        preview_filter='[0:v][1:v]overlay,scale=360:640'
        if cut=='C06':
            preview_filter="[1:v]split[a][b];[a]crop=1080:900:0:0[top];[b]crop=1080:1020:0:900[bottom];[0:v][top]overlay[tmp];[tmp][bottom]overlay=0:900:enable='gte(t,0.62)',scale=360:640"
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(ROOT/'media'/f'{cut}_1080.mp4'),'-i',str(ROOT/'layers'/f'{cut}_labels.png'),'-filter_complex',preview_filter,'-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p',str(ROOT/'previews'/f'{cut}_360.mp4')],check=True)
    rows=[]
    for f in range(292+119):rows.append({'frame_C03_C04':f,**state(f/FPS)})
    (ROOT/'evidence'/'motion_state.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':run('--stills' in sys.argv)
