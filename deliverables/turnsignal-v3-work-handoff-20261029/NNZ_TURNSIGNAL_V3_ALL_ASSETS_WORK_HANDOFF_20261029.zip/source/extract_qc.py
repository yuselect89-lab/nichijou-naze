from pathlib import Path
import subprocess,json
import numpy as np
from PIL import Image,ImageDraw
import render,intro
R=Path(__file__).resolve().parents[1]
for cut,frames in [('C03',[0,2,11,13,22,24]),('C04',[0,17,30,50]),('C06',[0,20,40,65,90,130])]:
    ims=[]
    for f in frames:
        p=R/'evidence'/f'{cut}_decoded_{f:03d}.png'
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(R/'previews'/f'{cut}_360.mp4'),'-vf',f'select=eq(n\\,{f})','-frames:v','1',str(p)],check=True)
        im=Image.open(p).convert('RGB');ImageDraw.Draw(im).text((10,10),f'{cut} frame {f}',fill='white');ims.append(im)
    sheet=Image.new('RGB',(360*len(ims),640))
    for i,im in enumerate(ims):sheet.paste(im,(360*i,0))
    sheet.save(R/'evidence'/f'{cut}_decoded_sequence.png')
for cut,f in [('C03',2),('C04',30),('C06',44)]:
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'media'/f'{cut}_1080.mp4'),'-vf',f'select=eq(n\\,{f})','-frames:v','1',str(R/'evidence'/f'{cut}_actual_1080.png')],check=True)
ims=[Image.open(R/'previews'/f'C02_{f:03d}_360.png') for f in (0,35,75,121)]
a=Image.new('RGB',(1440,640))
for i,im in enumerate(ims):a.paste(im,(i*360,0))
a.save(R/'evidence'/'C02_sequence.png')
assert np.array_equal(np.array(intro.c02(121)[0]),np.array(render.frame('C03',0)))
(R/'evidence'/'join_source_check.json').write_text(json.dumps({'C02_last_to_C03_first_source_pixel_equal':True,'C03_C04_shared_clock':True,'C06_same_mechanism_function':True},indent=2))
