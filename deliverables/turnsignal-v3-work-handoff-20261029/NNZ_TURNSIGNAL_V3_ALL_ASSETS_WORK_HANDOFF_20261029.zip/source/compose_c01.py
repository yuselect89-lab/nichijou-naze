"""C01 photographic footage with separately timed dashboard display.
No narration processing. Original24fps ->30fps repeats, Lanczos720->1080.
"""
from pathlib import Path
import subprocess,json
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
R=Path(__file__).resolve().parents[1]
N=160;TRIGGER=57;PERIOD=22;ON=12
def run():
    dec=subprocess.Popen(['ffmpeg','-v','error','-i',str(R/'input/C01_REPLACEMENT_ORIGINAL.mp4'),'-vf','fps=30,scale=1080:1920:flags=lanczos','-frames:v',str(N),'-f','rawvideo','-pix_fmt','rgb24','pipe:1'],stdout=subprocess.PIPE)
    enc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(R/'media/C01_1080.mp4')],stdin=subprocess.PIPE)
    overlay=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgba','-s','1080x1920','-r','30','-i','pipe:0','-an','-c:v','qtrle',str(R/'layers/C01_DISPLAY_CORRECTION_ALPHA.mov')],stdin=subprocess.PIPE)
    mask=Image.new('L',(1080,1920));ImageDraw.Draw(mask).ellipse((147,350,305,556),fill=255);mask=mask.filter(ImageFilter.GaussianBlur(9))
    records=[]
    for f in range(N):
        buf=dec.stdout.read(1080*1920*3)
        if len(buf)!=1080*1920*3:raise RuntimeError('Short source')
        im=Image.frombytes('RGB',(1080,1920),buf).convert('RGBA')
        if f==0:clean=im.copy()
        # Patch stays within the dark dashboard display field; no hand/stalk edits.
        correction=clean.copy();correction.putalpha(mask)
        on=f>=TRIGGER and (f-TRIGGER)%PERIOD<ON
        if on:
            glow=Image.new('RGBA',im.size);ImageDraw.Draw(glow).ellipse((194,476,257,540),fill=(35,230,78,110));correction.alpha_composite(glow.filter(ImageFilter.GaussianBlur(12)))
            x,y=225,510;d=ImageDraw.Draw(correction)
            d.polygon([(x-21,y-6),(x+2,y-6),(x+2,y-17),(x+23,y),(x+2,y+17),(x+2,y+6),(x-21,y+6)],fill=(56,242,104,255))
        overlay.stdin.write(correction.tobytes());im.alpha_composite(correction);enc.stdin.write(im.convert('RGB').tobytes())
        records.append({'frame':f,'seconds':f/30,'indicator_on':on})
    enc.stdin.close();overlay.stdin.close();dec.stdout.close()
    assert enc.wait()==0 and overlay.wait()==0 and dec.wait()==0
    (R/'evidence/C01_DISPLAY_TIMING.json').write_text(json.dumps({'trigger_frame':TRIGGER,'trigger_seconds':TRIGGER/30,'period_frames':PERIOD,'on_frames':ON,'rows':records},indent=2))
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'media/C01_1080.mp4'),'-vf','scale=360:640','-an','-c:v','libx264','-crf','18',str(R/'previews/C01_360.mp4')],check=True)
if __name__=='__main__':run()
