from pathlib import Path
import subprocess,json,hashlib,zipfile
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1]
BASE=R.parent/'V3_20261029'
manifest=json.loads((BASE/'manifest.json').read_text())
manifest['version']='V3_20261029_VIDEO_02'
manifest['status']='PARTIAL_C05_COMPOSITED_C01_REJECTED_VO_ALIGNMENT_PENDING'
manifest['master_audio'].update({'local_status':'RECEIVED_HASH_VERIFIED_USER_CONFIRMED','file':'input/VOICE_MASTER.mp3'})
for c in manifest['cuts']:
    c['voice_sync']='NOT_SEMANTICALLY_VERIFIED'
    if c['id']=='C01':
        c['status']='FAIL_ACTION_CAUSALITY_AND_HAND_CONTINUITY';c['file']=None;c['review_only']='previews/C01_REJECTED_REVIEW_1080.mp4'
    if c['id']=='C05':
        c.update({'status':'RENDERED_INTERNAL_REVIEW_PENDING_USER_ACCEPTANCE','file':'media/C05_1080.mp4','native_background':[720,1280,24],'output_conversion':'Lanczos1080x1920,24to30fps repeated-frame conversion. No speed change.','dependencies':['input/C05_BACKGROUND_ORIGINAL.mp4','assets/NNZ_CHAR_FEMALE_01_v02_think.png','source/integrate_user_video.py'],'separated_background':'layers/C05_background_1080.mp4','separated_foreground':'layers/C05_FOREGROUND_ALPHA.mov','indicator':'Sharper green arrow composited in existing display region; follows measured background blink.'})
manifest['C05_alpha']='layers/C05_FOREGROUND_ALPHA.mov'
(R/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
checks=[]
for relative,n,w,h in [('media/C05_1080.mp4',144,1080,1920),('previews/C05_360.mp4',144,360,640),('previews/C01_REJECTED_REVIEW_1080.mp4',160,1080,1920),('previews/C01_REJECTED_REVIEW_360.mp4',160,360,640),('layers/C05_background_1080.mp4',144,1080,1920)]:
    p=R/relative
    d=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-of','json',str(p)]))
    assert len(d['streams'])==1
    v=d['streams'][0];assert v['codec_type']=='video' and (v['width'],v['height'])==(w,h) and int(v['nb_read_frames'])==n and v['r_frame_rate']=='30/1'
    subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],check=True)
    checks.append({'file':relative,'frames':n,'resolution':[w,h],'fps':30,'audio':False,'decode':'PASS','production_acceptance':'NOT_IMPLIED'})
for f in (0,15,39,85,128):
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'previews/C05_360.mp4'),'-vf',f'select=eq(n\\,{f})','-frames:v','1',str(R/'evidence'/f'C05_actual_{f:03d}_360.png')],check=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'media/C05_1080.mp4'),'-vf',r'select=eq(n\,85)','-frames:v','1',str(R/'evidence/C05_actual_1080.png')],check=True)
canvas=Image.new('RGB',(1800,640))
for i,f in enumerate((0,15,39,85,128)):canvas.paste(Image.open(R/'evidence'/f'C05_actual_{f:03d}_360.png'),(i*360,0))
canvas.save(R/'evidence/C05_actual_sequence.png')
vo=R/'input/VOICE_MASTER.mp3';assert hashlib.sha256(vo.read_bytes()).hexdigest()=='59100d30d7aca0e0809f88479cad4a9a0aada35420ebb2353f9c32af37b8f1cd'
(R/'evidence/VIDEO_UPDATE_TECHNICAL_QC.json').write_text(json.dumps(checks,indent=2))
(R/'QC_RESULT.md').write_text('''# ウインカー編V3：受領動画の実画検査とC05合成

全体は未完成。6カットPASSとはしない。前版と承認済み原本は保全。

## C05

391ed1b6を背景に既存NNZ_CHAR_FEMALE_01 v02_highres thinkを大きく合成。新規ポーズ/口パクなし。耳に手を当てるポーズとして偽装しない。顔と背景のメーター表示を分離して配置。下端alphaフェードと背景の明度調整で上半身の切断境界を和らげた。控えめな音波は点滅切替を基準に描画。

背景の緑表示は360pxで丸いボケとなり方向指示と判別しづらいため、元の発光位置に右向き表示を合成補強。入力の緑成分を毎フレーム測定し、その実際の点滅に同期。別時計でずれた点滅を足していない。C05_indicator_tracking.jsonに数値と切替フレームを保存。

1080×1920/30fps/144フレーム/4.8秒/無音。入力背景のネイティブは720×1280/24fpsであり、1080納品はLanczos拡大、24→30はフレーム複製。ネイティブ1080や新規30fps動作とは呼ばない。原本の生成音声は除去し、ナレーションには触れない。

実MP4から1080および360フレームを抽出して顔・表示・合成端を確認。通常再生結果はuser_video_playback.log。内部実画確認であり、ユーザー/Geminiの合格ではない。背景は上左の表示を使用し、前景に隠れない配置を優先した。

## C01：不合格

ac43f6ddは開始時点で手がレバー先端をつまみ、方向表示も既に点灯。約0.125〜0.25秒で手が急に消え、0.625秒頃に再び入る。支点を中心にした一回の明確なレバー操作が読み取れず、先端のライト切替リングを操作するように見える。操作後に点滅開始という原因→結果を満たさない。

手のない後半だけを採ると操作自体がなくなるため、局所トリミングで本要求を満たすとは判定しない。review_onlyとして無音確認動画を添付し、media/C01として登録しない。C01再生成が必要。確認シートはinput/USER_VIDEOまたは前の実画検査に記録。

## 保留

C02の実在外装照合、C06の「わざわざ」に合わせた強調、VO全体の発話位置とカット境界の意味照合、全6カットG3は未了。正式音声a.mp3はユーザー確認済み、32.600813秒/SHA一致の原本を無加工で同梱。音声が未取得という前版の状態は解消したが、意味同期済みとはしない。

正式黄色帯・字幕・進行バーは焼込まずWorkが各1回合成。字幕は表示時のみ「、」除去、「。」保持。既存台本・キャラ原本は変更なし。公開/投稿/GitHub push、有料API利用はなし。

生成動画はユーザー提供。ファイル名から提供サービスや商用利用権を断定せず、プロバイダ/モデル/利用条件の独立確認は保留。
''')
(R/'README.md').write_text('''# ウインカー編V3 VIDEO_02（部分納品）

C05を今回の受領背景と既存キャラで実合成。media/C05_1080.mp4が新しい無音素材。背景と透過前景はlayers/に分離。C02/C03/C04/C06は前版を変更せず同梱。正式音声はinput/VOICE_MASTER.mp3（無加工・SHA確認済み）。

C01候補は実画不合格のためpreviews/C01_REJECTED_REVIEWのみ。完成6カットとして使用しない。理由と未検収範囲はQC_RESULT.mdとmanifest.json。

再合成はPython3+Pillow+numpy+FFmpegを用い source/integrate_user_video.py を実行。入力原本はinput/、承認キャラの原本コピーはassets/、編集可能ソースはsource/。media本体には正式帯・本字幕・全編進行バーを含めない。C05を本編へ貼る際にキャラを二重に重ねない。

背景原本720p24fps→1080p30fpsの変換であり、元動画以上のディテール/時間解像度を主張しない。本編の組立はChatGPT Work。発話同期とG3は未了。
''')
# Remove obsolete foreground-only copies only in this new derivative folder.
for relative in ['layers/C05_PRESENTER_ONLY_ALPHA.mov','previews/C05_ALPHA_ONLY_STAGE_360.mp4']:(R/relative).unlink(missing_ok=True)
entries=[]
for p in sorted(R.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.zip' or p.name=='SHA256SUMS.txt':continue
    entries.append((p,hashlib.sha256(p.read_bytes()).hexdigest()))
(R/'SHA256SUMS.txt').write_text(''.join(f'{h}  {p.relative_to(R).as_posix()}\n' for p,h in entries))
z=R/'NNZ_TURNSIGNAL_V3_VIDEO_UPDATE_20261029.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
    for p,h in entries:out.write(p,p.relative_to(R))
    out.write(R/'SHA256SUMS.txt','SHA256SUMS.txt')
with zipfile.ZipFile(z) as inp:
    assert inp.testzip() is None
    for p,h in entries:assert hashlib.sha256(inp.read(p.relative_to(R).as_posix())).hexdigest()==h
print(json.dumps({'zip':str(z),'bytes':z.stat().st_size,'sha256':hashlib.sha256(z.read_bytes()).hexdigest()},indent=2))
