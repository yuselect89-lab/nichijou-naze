from pathlib import Path
import json,subprocess,hashlib,zipfile
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];PREV=R.parent/'V3_20261029_VIDEO_02'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
for rel,w,h in [('media/C01_1080.mp4',1080,1920),('previews/C01_360.mp4',360,640)]:
    p=R/rel;d=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-of','json',str(p)]))
    assert len(d['streams'])==1
    v=d['streams'][0];assert (v['width'],v['height'])==(w,h) and v['r_frame_rate']=='30/1' and int(v['nb_read_frames'])==160
    subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],check=True)
    checks.append({'file':rel,'dimensions':[w,h],'fps':30,'frames':160,'audio':False,'decode':'PASS'})
for c in ('C02','C03','C04','C05','C06'):
    assert sha(R/'media'/f'{c}_1080.mp4')==sha(PREV/'media'/f'{c}_1080.mp4')
canvas=Image.new('RGB',(1800,640))
for i,f in enumerate([0,45,57,70,110]):
    p=R/'evidence'/f'C01_actual_{f:03d}_360.png'
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'previews/C01_360.mp4'),'-vf',f'select=eq(n\\,{f})','-frames:v','1',str(p)],check=True)
    im=Image.open(p).convert('RGB');ImageDraw.Draw(im).text((5,5),f'{f/30:.2f}s',fill='yellow');canvas.paste(im,(i*360,0))
canvas.save(R/'evidence/C01_actual_sequence.png')
subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'media/C01_1080.mp4'),'-vf',r'select=eq(n\,57)','-frames:v','1',str(R/'previews/C01_representative_1080.png')],check=True)
timing=json.loads((R/'evidence/C01_DISPLAY_TIMING.json').read_text());assert all(not x['indicator_on'] for x in timing['rows'][:57]);assert timing['rows'][57]['indicator_on']
checks.append({'C02_C06_media_unchanged':True,'display_dark_until_seconds':1.9,'whole_voice_sha256':sha(R/'input/VOICE_MASTER.mp3')})
assert checks[-1]['whole_voice_sha256']=='59100d30d7aca0e0809f88479cad4a9a0aada35420ebb2353f9c32af37b8f1cd'
(R/'evidence/C01_TECHNICAL_QC.json').write_text(json.dumps(checks,indent=2))
m=json.loads((PREV/'manifest.json').read_text());m['version']='V3_20261029_VIDEO_03';m['status']='SIX_CUT_MEDIA_PRESENT_FINAL_ACCEPTANCE_AND_SEMANTIC_SYNC_PENDING'
c=m['cuts'][0];c.update({'file':'media/C01_1080.mp4','status':'RENDERED_INTERNAL_REVIEW_PENDING_USER_ACCEPTANCE','review_only':None,'dependencies':['input/C01_REPLACEMENT_ORIGINAL.mp4','source/compose_c01.py'],'native_source':[720,1280,24],'display_trigger_frame':57,'display_trigger_seconds':1.9,'display_period_frames':22,'separated_display':'layers/C01_DISPLAY_CORRECTION_ALPHA.mov','conversion':'720p24 source ->1080p30 output. Native resolution not1080. No speed change.','limitations':'Lever rises then settles; do not claim sustained raised-detent latch or exact vehicle-specific mechanics.'})
(R/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
old=(PREV/'QC_RESULT.md').read_text()
(R/'QC_PREVIOUS_VIDEO_02.md').write_text(old)
(R/'QC_RESULT.md').write_text('''# ウインカー編V3 VIDEO_03 実画QC

## 今回のC01

新規受領d670a464を使用。原本を無加工でinputに保全。手が画面外から入り、指先がレバーに接触し、レバー全体が持ち上がる動きがある。前候補のような手の突然の消失は選択区間で認めず。先端リングだけの回転とは異なる全体の角度変化を1080/360抽出フレームで確認。

生成映像には早い時刻に左矢印点滅が残ったため、暗い表示領域のみ消灯フレームのぼかした局所パッチで修正。手・レバーの形状や動作には加工なし。操作の持上げが視認できる1.90秒（57f）から右矢印を30fps上の22f周期/12f点灯で合成。上方向操作と右方向表示を対応させた。正確な実車の電装測定値ではなく編集用の模式点滅。

360px実MP4から前/操作/点灯/消灯/退場後のフレームを抽出し、表示と手の視認性、局所修正境界を確認。Chromium等速再生はevidence/C01_playback.log。コーデック検査のみを美術合格の根拠にしない。ユーザー/Geminiの最終合格を代行しない。

レバーは持上げ後に少し戻る。プロンプトで指定した「完全に上がったままのラッチ保持」まで再現したとは判定しない。車種固有の機構やラッチ動作の実証素材として使用しない。現行カット要求の操作→表示点滅を見せる用途の候補。小さな画面変動もあり、実撮影の完全固定カメラを保証しない。

1080×1920/30fps/160f/5.333333秒/無音。入力の実体は720×1280/24fps。Lanczos拡大と24→30の複製変換であり、ネイティブ1080/30fpsのディテールを主張しない。元動画の音声は焼き込まず、正式VOはSHA一致の原本のまま。

## 全体

C01〜C06の無音MP4が揃った。C02〜C06はVIDEO_02からバイト一致で保全。本編の編集、正式帯、字幕、全編進行バーの合成は行っていない。正式帯・承認キャラ原本は未変更。preflight/31テスト成功。未確認をPASSにしない。

C02外装の実在品照合、音声の意味に基づく各カット境界とC06「わざわざ」の同期、6カットを通した最終G3/ユーザー承認は未了。音声解析で無音区間は測定したが、語句時刻を確認済みとはしていない。前版C01不合格の記録はQC_PREVIOUS_VIDEO_02.mdに履歴として保全し、新C01の判定と混同しない。

素材の権利/出典：ユーザー提供の生成動画。プロバイダ/モデル/利用条件の独立確認は未了。キャラは既存登録済みv02_highres。外部送信・新規有料生成・投稿・公開・GitHub pushはなし。
''')
(R/'README.md').write_text('''# ウインカー編 V3 VIDEO_03

media/C01_1080.mp4〜C06_1080.mp4：6カットの無音動画素材。C01を受領動画と表示点滅の局所合成で追加。C02〜06は前版を保全。

previews/C01_360.mp4：今回のC01等速確認用。代表フレームとQCはpreviews/、evidence/、QC_RESULT.md。過去不合格候補はREJECTED_REVIEW表記の確認用であり本編素材ではない。

source/compose_c01.py：C01の編集可能ソース。input/C01_REPLACEMENT_ORIGINAL.mp4：入力原本。layers/C01_DISPLAY_CORRECTION_ALPHA.mov：分離した表示補正。C05の背景と前景もlayers/に分離。C03/C04/C06はrender.pyの共通モデル。Python3+Pillow+numpy+FFmpegで再制作。

6カットが存在することと本番合格は別。C02外観照合、VO意味同期、全体G3は未了。正式帯・本字幕・全編進行バーはWorkが各1回合成。字幕は表示時に「、」除去し「。」保持。音声はinput/VOICE_MASTER.mp3を分割/加工せず使用。発話に合わせたラフ本編の組立はWork担当。
''')
state=R.parents[1]/'work-state.json';d=json.loads(state.read_text());d.update({'rendered_delivery':'output/V3_20261029_VIDEO_03','rendered_cuts':['C01','C02','C03','C04','C05','C06'],'unfinished':['C01 raised-detent hold is not fully reproduced; final acceptance pending','C02 exterior reference verification','VO semantic cue alignment and C06 wazawaza timing','six-cut final QC and Work handoff']});state.write_text(json.dumps(d,ensure_ascii=False,indent=2))
entries=[]
for p in sorted(R.rglob('*')):
    if not p.is_file() or p.suffix=='.zip' or '__pycache__' in p.parts or p.name=='SHA256SUMS.txt':continue
    entries.append((p,sha(p)))
(R/'SHA256SUMS.txt').write_text(''.join(f'{h}  {p.relative_to(R).as_posix()}\n' for p,h in entries))
z=R/'NNZ_TURNSIGNAL_V3_SIX_CUT_MATERIALS_20261029.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
    for p,h in entries:out.write(p,p.relative_to(R))
    out.write(R/'SHA256SUMS.txt','SHA256SUMS.txt')
with zipfile.ZipFile(z) as inp:
    assert inp.testzip() is None
    for p,h in entries:assert hashlib.sha256(inp.read(p.relative_to(R).as_posix())).hexdigest()==h
print(json.dumps({'zip':str(z),'bytes':z.stat().st_size,'sha256':sha(z)},indent=2))
