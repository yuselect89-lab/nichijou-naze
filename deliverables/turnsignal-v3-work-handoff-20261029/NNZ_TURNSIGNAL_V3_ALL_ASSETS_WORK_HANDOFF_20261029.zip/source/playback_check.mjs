import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {openBrowser} from '@remotion/renderer';
import http from 'node:http';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const files=process.argv.slice(2);if(!files.length)throw new Error('Supply generated preview filenames');
let currentVideo=Buffer.alloc(0);
const server=http.createServer((req,res)=>{
 res.setHeader('Cache-Control','no-store');
 if(req.url==='/favicon.ico'){res.writeHead(204);res.end();return;}
 if(req.url==='/preview.mp4'){
  const match=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range??'');
  const start=match?Number(match[1]):0,end=match&&match[2]?Math.min(Number(match[2]),currentVideo.length-1):currentVideo.length-1;
  if(start>end||start>=currentVideo.length){res.writeHead(416);res.end();return;}
  const headers={'Content-Type':'video/mp4','Accept-Ranges':'bytes','Content-Length':end-start+1};
  if(match)headers['Content-Range']=`bytes ${start}-${end}/${currentVideo.length}`;
  res.writeHead(match?206:200,headers);res.end(currentVideo.subarray(start,end+1));return;
 }
 if(req.url==='/'){res.setHeader('Content-Type','text/html');res.end('<html><body style="margin:0"><video id="v" width="360" height="640" muted playsinline preload="auto" src="/preview.mp4"></video></body></html>');return;}
 res.writeHead(404);res.end();
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'}});
const results=[];
try{
 for(const filename of files){
  if(path.basename(filename)!==filename)throw new Error('Basename only');
  const p=path.join(root,'previews',filename);currentVideo=fs.readFileSync(p);
  const page=await browser.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
  await page.setViewport({width:360,height:640,deviceScaleFactor:1});
  await page.goto({url:'http://127.0.0.1:'+server.address().port+'/',timeout:20000,options:{waitUntil:'load'}});
  const result=await page.evaluate(async()=>{
   const v=document.getElementById('v');v.muted=true;v.playbackRate=1;
   if(v.readyState<3)await new Promise(resolve=>v.addEventListener('canplay',resolve,{once:true}));
   v.currentTime=0;await new Promise(resolve=>setTimeout(resolve,200));
   return await new Promise(resolve=>{
    const samples=[],shots=[];const captureFrames=false;let started=0;let finished=false;let next=.0;
    const finish=error=>{if(finished)return;finished=true;const q=v.getVideoPlaybackQuality();resolve({error,ended:v.ended,currentTime:v.currentTime,duration:v.duration,playbackRate:v.playbackRate,muted:v.muted,wall_ms:performance.now()-started,totalVideoFrames:q.totalVideoFrames,droppedVideoFrames:q.droppedVideoFrames,samples,shots});};
    const tick=(now,m)=>{samples.push({wall_ms:now-started,mediaTime:m.mediaTime,presentedFrames:m.presentedFrames});if(captureFrames && m.mediaTime>=next&&shots.length<7){const c=document.createElement('canvas');c.width=360;c.height=640;c.getContext('2d').drawImage(v,0,0);shots.push({mediaTime:m.mediaTime,png:c.toDataURL('image/png')});next+=1;}if(!finished)v.requestVideoFrameCallback(tick);};
    v.onerror=()=>finish('media error '+v.error?.code);v.onended=()=>finish(null);
    started=performance.now();v.requestVideoFrameCallback(tick);v.play().catch(e=>finish(String(e)));setTimeout(()=>finish('timeout'),45000);
   });
  });
  const dir=path.join(root,'evidence','browser_'+filename.replace('.mp4',''));fs.mkdirSync(dir,{recursive:true});
  for(let i=0;i<result.shots.length;i++)fs.writeFileSync(path.join(dir,`frame_${i}.png`),Buffer.from(result.shots[i].png.split(',')[1],'base64'));
  result.frame_shots=result.shots.map((s,i)=>({mediaTime:s.mediaTime,file:path.relative(root,path.join(dir,`frame_${i}.png`))}));delete result.shots;
  result.filename=filename;result.scope='Automated Chromium 1.0x playback and separate decoded-frame visual inspection; not an independent human or Gemini review';
  fs.writeFileSync(path.join(dir,'playback.json'),JSON.stringify(result,null,2));results.push(result);
  if(result.error||!result.ended||result.playbackRate!==1||!Number.isFinite(result.duration))throw new Error(JSON.stringify(result));
 }
}finally{await browser.close({silent:true});server.close();}
console.log(JSON.stringify(results.map(r=>({filename:r.filename,ended:r.ended,playbackRate:r.playbackRate,wall_ms:r.wall_ms,totalVideoFrames:r.totalVideoFrames,droppedVideoFrames:r.droppedVideoFrames,captured:r.frame_shots.length}))));
