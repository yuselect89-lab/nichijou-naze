"""C02 exterior-to-interior and isolated C05 presenter overlay. No invented ear pose."""
import render as r
from PIL import Image,ImageDraw,ImageFilter
import subprocess

def presenter(pose):
    p=Image.open(r.ROOT/'assets'/f'NNZ_CHAR_FEMALE_01_v02_{pose}.png').convert('RGBA')
    # Preserve head and upper body, no limb deformation.
    return p.crop((110,55,1410,1390)).resize((650,668),Image.Resampling.LANCZOS)
POINT=presenter('point_right');THINK=presenter('think')
def case():
    im=r.layer();r.shadow(im,(315,990,830,1275))
    r.shaded(im,(300,935,813,1240),[(79,88,91),(37,47,53),(19,29,35)],24)
    d=ImageDraw.Draw(im);d.polygon([(813,952),(851,922),(851,1209),(813,1240)],fill='#14232a')
    d.polygon([(300,935),(339,905),(851,922),(813,952)],fill='#657174')
    d.line((325,958,785,958),fill='#a0aaa7',width=3)
    for x in (405,550,697):r.metal(im,(x,1238,x+22,1303))
    return im
CASE=case()
def c02(f,character=True):
    t=f/30; a=r.ease((t-1.15)/2.5)
    # Reveal is a cover lift, not replacement by unrelated mechanical images.
    inside=r.mechanism(0)
    inside.putalpha(inside.getchannel('A').point(lambda v:int(v*r.ease((t-.9)/.5))))
    exterior=CASE.copy();exterior.putalpha(exterior.getchannel('A').point(lambda v:int(v*(1-r.ease((t-1.3)/.8)))))
    inside.alpha_composite(exterior,(0,-round(95*r.ease((t-1.0)/1))))
    s=.46+.54*a;new=inside.resize((round(1080*s),round(1920*s)),Image.Resampling.LANCZOS)
    out=r.BG.copy();out.alpha_composite(new,(round(482*(1-a)),round(545*(1-a))))
    char=r.layer()
    if character:
        p=POINT.copy();op=1-r.ease((t-1.55)/.55);p.putalpha(p.getchannel('A').point(lambda v:int(v*op)))
        char.alpha_composite(p,(90,735));out.alpha_composite(char)
    return out,char

def c05_overlay(f):
    im=r.layer();im.alpha_composite(THINK,(190,710))
    # Existing natural think pose; sound-wave gesture is a separate overlay.
    d=ImageDraw.Draw(im);a=r.state(f/30)['edge_age']
    if a<.20:
        for radius in (44,66):d.arc((782-radius,967-radius,782+radius,967+radius),-60,60,fill=(163,201,207,int(180*(1-a/.20))),width=3)
    return im

def encode():
    n=122;p=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','pipe:0','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(r.ROOT/'media'/'C02_1080.mp4')],stdin=subprocess.PIPE)
    for f in range(n):p.stdin.write(c02(f)[0].convert('RGB').tobytes())
    p.stdin.close();assert p.wait()==0
    for f in (0,35,75,121):
        im,ch=c02(f);im.save(r.ROOT/'previews'/f'C02_{f:03d}_1080.png');im.resize((360,640)).save(r.ROOT/'previews'/f'C02_{f:03d}_360.png')
    # Deliver real animated alpha video for later C05 background composition.
    p=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgba','-s','1080x1920','-r','30','-i','pipe:0','-an','-c:v','prores_ks','-profile:v','4','-pix_fmt','yuva444p10le','-vendor','apl0',str(r.ROOT/'layers'/'C05_PRESENTER_ONLY_ALPHA.mov')],stdin=subprocess.PIPE)
    for f in range(144):p.stdin.write(c05_overlay(f).tobytes())
    p.stdin.close();assert p.wait()==0
    c05_overlay(2).save(r.ROOT/'layers'/'C05_presenter_sample.png')
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(r.ROOT/'media'/'C02_1080.mp4'),'-vf','scale=360:640','-an','-c:v','libx264','-crf','18',str(r.ROOT/'previews'/'C02_360.mp4')],check=True)
if __name__=='__main__':encode()
