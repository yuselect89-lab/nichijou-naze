"""User footage derivatives; preserve all originals and narration bytes.
python source/integrate_user_video.py
Native source is 720x1280/24fps. 1080 outputs are Lanczos resamples, not native1080.
"""
from pathlib import Path
import subprocess,json,math
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import render as r
import intro
R=Path(__file__).resolve().parents[1]
def ff(*args):subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*map(str,args)],check=True)
def encoder(path):
    return subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(path)],stdin=subprocess.PIPE)
def run():
    # C01 is explicitly a review candidate, not production-approved footage.
    ff('-i',R/'input/C01_CANDIDATE_ORIGINAL.mp4','-vf','fps=30,scale=1080:1920:flags=lanczos','-frames:v','160','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',R/'previews/C01_REJECTED_REVIEW_1080.mp4')
    ff('-i',R/'previews/C01_REJECTED_REVIEW_1080.mp4','-vf','scale=360:640','-an','-c:v','libx264','-crf','18',R/'previews/C01_REJECTED_REVIEW_360.mp4')
    ff('-i',R/'input/C05_BACKGROUND_ORIGINAL.mp4','-vf','fps=30,scale=1080:1920:flags=lanczos','-frames:v','144','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p',R/'layers/C05_background_1080.mp4')
    dec=subprocess.Popen(['ffmpeg','-v','error','-i',str(R/'layers/C05_background_1080.mp4'),'-f','rawvideo','-pix_fmt','rgb24','pipe:1'],stdout=subprocess.PIPE)
    enc=encoder(R/'media/C05_1080.mp4')
    rgba_enc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgba','-s','1080x1920','-r','30','-i','pipe:0','-an','-c:v','qtrle',str(R/'layers/C05_FOREGROUND_ALPHA.mov')],stdin=subprocess.PIPE)
    # Existing high-resolution pose, no new limb/mouth/face or skin-color changes.
    sprite=intro.THINK.copy()
    alpha=np.array(sprite.getchannel('A')).astype(float)
    alpha*=np.clip((668-np.arange(668))/88,0,1)[:,None]
    sprite.putalpha(Image.fromarray(alpha.astype('uint8')))
    grade=(.84-.42*np.clip((np.arange(1920)-1000)/650,0,1)).astype('float32')[:,None,None]
    flags=[];last_on=False;last_edge=-999
    for f in range(144):
        buf=dec.stdout.read(1080*1920*3)
        if len(buf)!=1080*1920*3:raise RuntimeError('Short source decode')
        a=np.frombuffer(buf,dtype='uint8').reshape(1920,1080,3)
        roi=a[465:563,180:270,:].astype(float)
        green=roi[:,:,1]-(roi[:,:,0]+roi[:,:,2])*.5
        score=float(np.percentile(green,95));on=score>27
        if on!=last_on:last_edge=f
        last_on=on;flags.append({'frame':f,'source_green_score':score,'indicator_on':on})
        out=Image.fromarray((a.astype(float)*grade).clip(0,255).astype('uint8')).convert('RGBA')
        fore=Image.new('RGBA',(1080,1920));fore.alpha_composite(sprite,(190,710))
        # Sharper dashboard symbol follows the supplied background's actual blink,
        # not a separately invented clock. Original glow is retained behind it.
        if on:
            d=ImageDraw.Draw(fore);x,y=225,516
            d.polygon([(x-24,y-7),(x+1,y-7),(x+1,y-18),(x+23,y),(x+1,y+18),(x+1,y+7),(x-24,y+7)],fill=(68,237,118,210))
        age=(f-last_edge)/30
        if 0<=age<.20:
            d=ImageDraw.Draw(fore)
            for rad in (44,66):d.arc((782-rad,967-rad,782+rad,967+rad),-60,60,fill=(176,214,214,int(160*(1-age/.20))),width=3)
        rgba_enc.stdin.write(fore.tobytes())
        out.alpha_composite(fore);enc.stdin.write(out.convert('RGB').tobytes())
        if f in (0,30,60,90,143):
            out.convert('RGB').save(R/'previews'/f'C05_{f:03d}_1080.png')
            out.convert('RGB').resize((360,640),Image.Resampling.LANCZOS).save(R/'previews'/f'C05_{f:03d}_360.png')
        if f%30==0:print('C05',f,score,on,flush=True)
    enc.stdin.close();rgba_enc.stdin.close();dec.stdout.close()
    assert enc.wait()==0 and rgba_enc.wait()==0 and dec.wait()==0
    (R/'evidence/C05_indicator_tracking.json').write_text(json.dumps(flags,indent=2))
    ff('-i',R/'media/C05_1080.mp4','-vf','scale=360:640','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p',R/'previews/C05_360.mp4')
if __name__=='__main__':run()
