"""Local CORE_B repair applied to the delivered wet03 scene. No model/camera rebuild.
Existing stream meshes gain advected surface/radius detail; existing local wet mask
controls stronger lower-noodle darkening, gloss and pore smoothing. No solver.
"""
import bpy,math,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];s=bpy.context.scene
assert bpy.data.materials['Fried noodle porous dry to wetted'].get('wet_material_version')=='local_contact_03'
def keys(owner,path,values):
 owner.keyframe_delete(path,frame=1) if False else None
 for f,v in values:
  setattr(owner,path,v);owner.keyframe_insert(path,frame=f)
 if owner.id_data.animation_data:
  for c in owner.id_data.animation_data.action.fcurves:
   if c.data_path==owner.path_from_id(path):
    for k in c.keyframe_points:k.interpolation='LINEAR'
def socket_keys(socket,values):
 path=socket.path_from_id('default_value');act=socket.id_data.animation_data
 if act and act.action:
  for c in list(act.action.fcurves):
   if c.data_path==path:act.action.fcurves.remove(c)
 for f,v in values:socket.default_value=v;socket.keyframe_insert('default_value',frame=f)
 for c in socket.id_data.animation_data.action.fcurves:
  if c.data_path==path:
   for k in c.keyframe_points:k.interpolation='LINEAR'
def op(n,l,kind,a,b=0):
 q=n.new('ShaderNodeMath');q.operation=kind
 for i,x in enumerate([a,b]):
  if hasattr(x,'node'):l.new(x,q.inputs[i])
  else:q.inputs[i].default_value=x
 return q.outputs[0]
root=bpy.data.objects['COMMON_MODEL_fixed_support']
adv=bpy.data.objects.new('B_REPAIR_WATER_ADVECT_DOWN',None);s.collection.objects.link(adv);adv.parent=root
for f in [1,240,241,283,295,301,345,391,430,431,480]:
 adv.location.z=-(max(241,f)-241)*.035;adv.keyframe_insert('location',index=2,frame=f)
for c in adv.animation_data.action.fcurves:
 for k in c.keyframe_points:k.interpolation='LINEAR'
base=bpy.data.materials['Transparent hot water IOR 1.333'];flow=base.copy();flow.name='B_REPAIR_ADVECTED_CLEAR_FLOW_v01';n=flow.node_tree.nodes;l=flow.node_tree.links
output=n.get('Material Output');original=output.inputs['Surface'].links[0].from_socket
p=n.new('ShaderNodeBsdfPrincipled');p.name='CLEAR_LIQUID_MOVING_SPECULAR';p.inputs['Base Color'].default_value=(.99,.995,1,1);p.inputs['Roughness'].default_value=.03;p.inputs['IOR'].default_value=1.333;p.inputs['Transmission Weight'].default_value=1;p.inputs['Coat Weight'].default_value=.4;p.inputs['Coat Roughness'].default_value=.025;p.inputs['Coat IOR'].default_value=1.333
coord=n.new('ShaderNodeTexCoord');coord.object=adv
noise=n.new('ShaderNodeTexNoise');noise.name='ADVECTED_FLOW_SURFACE';noise.inputs['Scale'].default_value=3;noise.inputs['Detail'].default_value=2;l.new(coord.outputs['Object'],noise.inputs['Vector'])
bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.28;bump.inputs['Distance'].default_value=.014;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs[0],p.inputs['Normal'])
clear=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');mix.inputs[0].default_value=.60;l.new(p.outputs[0],mix.inputs[1]);l.new(clear.outputs[0],mix.inputs[2])
fres=n.new('ShaderNodeFresnel');fres.inputs['IOR'].default_value=1.333;l.new(bump.outputs[0],fres.inputs['Normal'])
em=n.new('ShaderNodeEmission');em.inputs['Color'].default_value=(1,.98,.94,1);l.new(op(n,l,'MULTIPLY',op(n,l,'MULTIPLY',fres.outputs[0],noise.outputs['Fac']),.32),em.inputs['Strength'])
add=n.new('ShaderNodeAddShader');l.new(mix.outputs[0],add.inputs[0]);l.new(em.outputs[0],add.inputs[1])
path=n.new('ShaderNodeLightPath');sh=n.new('ShaderNodeMixShader');l.new(path.outputs['Is Shadow Ray'],sh.inputs[0]);l.new(add.outputs[0],sh.inputs[1]);l.new(clear.outputs[0],sh.inputs[2])
gate=n.new('ShaderNodeValue');gate.name='B_REPAIR_FLOW_VISIBILITY';socket_keys(gate.outputs[0],[(1,0),(240,0),(241,0),(283,0),(295,1),(430,1),(431,0),(480,0)])
final=n.new('ShaderNodeMixShader');l.new(gate.outputs[0],final.inputs[0]);l.new(original,final.inputs[1]);l.new(sh.outputs[0],final.inputs[2]);l.new(final.outputs[0],output.inputs['Surface'])
tex=bpy.data.textures.new('B_REPAIR_LIQUID_RADIUS_RIPPLES','CLOUDS');tex.noise_scale=.40;tex.noise_depth=1
streams=[o for o in bpy.data.objects if o.name.startswith('Water_Inlet') or o.name.startswith('Water_interstice')]
for obj in streams:
 obj.data.materials.clear();obj.data.materials.append(flow)
 m=obj.modifiers.new('B_REPAIR_downstream_radius_variation','DISPLACE');m.texture=tex;m.texture_coords='OBJECT';m.texture_coords_object=adv;m.direction='NORMAL';m.mid_level=.5
 keys(m,'strength',[(1,0),(240,0),(241,0),(283,0),(295,.026),(430,.026),(431,0),(480,0)])
mat=bpy.data.materials['Fried noodle porous dry to wetted'];n=mat.node_tree.nodes;l=mat.node_tree.links;pr=n.get('Principled BSDF');col=n['LOWER_WET_CONTACT_CONTRAST_03'];col.inputs[2].default_value=(.66,.72,.80,1)
fac=col.inputs[0].links[0].from_socket;lower=fac.node.inputs[1].links[0].from_node;assert lower.operation=='LESS_THAN';lower.inputs[1].default_value=1.95
changed=0
for q in n:
 if q.type=='MATH' and q.operation=='MULTIPLY':
  for inp in q.inputs:
   if not inp.is_linked and abs(inp.default_value-.68)<1e-5:inp.default_value=.90;changed+=1
assert changed==2,changed
cap=n['LOCAL_CAPILLARY_CONTACT_PROGRESS'];socket_keys(cap.outputs[0],[(1,0),(240,0),(241,0),(391,0),(400,.08),(408,.30),(418,.72),(430,1),(480,1)])
oldrough=pr.inputs['Roughness'].links[0].from_socket
l.new(op(n,l,'ADD',op(n,l,'MULTIPLY',oldrough,op(n,l,'SUBTRACT',1,fac)),op(n,l,'MULTIPLY',fac,.055)),pr.inputs['Roughness'])
l.new(op(n,l,'MULTIPLY',fac,.85),pr.inputs['Coat Weight']);pr.inputs['Coat IOR'].default_value=1.333;pr.inputs['Coat Roughness'].default_value=.04
b=next(q for q in n if q.type=='BUMP');l.new(op(n,l,'ADD',.22,op(n,l,'MULTIPLY',fac,-.15)),b.inputs['Strength'])
mat['wet_material_version']='CORE_B_REPAIR_WET04';flow['version']='CORE_B_REPAIR_FLOW01'
s['repair_scope']='CORE_B liquid appearance 2.00–3.47s and underside wet spread5.00–6.40s; existing model/camera/timing reused. Original CORE_A file and source preserved.'
import sys
sys.path.insert(0,str(R/'source'))
from add_flow_visibility import apply as add_visibility
add_visibility()
from add_flow_waves import apply as add_waves
add_waves()
s.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(R/'source/CORE_B_REPAIRED.blend'))
(R/'evidence/FROZEN_SCENE_SHA256.txt').write_text(hashlib.sha256((R/'source/CORE_B_REPAIRED.blend').read_bytes()).hexdigest()+'  source/CORE_B_REPAIRED.blend\n')
(R/'evidence/patch_parameters.json').write_text(json.dumps({'streams':[o.name for o in streams],'water_advects_down_units_per_second':1.05,'radius_ripple_amplitude':[.011,.014],'wave_length':.42,'wave_method':s.get('flow_wave_method'),'visibility_method':mat.get('flow_visibility_method'),'transparent_max_bounces':s.cycles.transparent_max_bounces,'water_flow_gate':[283,295,430,431],'wet_front_end_z':1.84,'wet_coverage_end_z_clip':1.95,'lower_extra_darkening':[.66,.72,.80],'lower_wet_roughness':.055,'lower_wet_coat_weight':.85,'camera_or_model_rebuilt':False,'solver_added':False},indent=2))
print('REPAIR_SAVED_AND_PATCHED',flush=True)
