"""Extract updated wet still from real video and regenerate CUT05->06 proof."""
from pathlib import Path
import subprocess,json,hashlib,shutil
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];E=R/'evidence';W,H=1080,1920

def decode(path,indices,w=W,h=H):
 p=subprocess.Popen(['ffmpeg','-v','error','-i',str(path),'-f','rawvideo','-pix_fmt','rgb24','pipe:1'],stdout=subprocess.PIPE);out={};f=0
 while True:
  b=p.stdout.read(w*h*3)
  if not b:break
  assert len(b)==w*h*3
  if f in indices:out[f]=np.frombuffer(b,np.uint8).reshape(h,w,3).copy()
  f+=1
 assert p.wait()==0 and set(indices)<=set(out)
 return out,f

idx=set([0,42,43,60,75,90,104,150,162,174,192,212]+list(range(225,240)))
frames,count=decode(R/'CORE_B_WATER.mp4',idx);assert count==240
Image.fromarray(frames[239]).save(R/'STILL_WET_PAYOFF.png');shutil.copy2(R/'STILL_WET_PAYOFF.png',R/'STILL_WET.png')
Image.fromarray(frames[239]).resize((360,640),Image.Resampling.LANCZOS).save(R/'STILL_WET_360.png')
seq=[frames[f] for f in range(225,240)]+[frames[239]]*45
p=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','360x640','-r','30','-i','pipe:0','-an','-vf','scale=out_color_matrix=bt709:out_range=tv,format=yuv420p','-c:v','libx264','-crf','16','-x264-params','keyint=300:min-keyint=300:scenecut=0','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-pix_fmt','yuv420p','-movflags','+faststart',str(R/'transition_C05_C06_360.mp4')],stdin=subprocess.PIPE)
for a in seq:p.stdin.write(np.asarray(Image.fromarray(a).resize((360,640),Image.Resampling.LANCZOS)).tobytes())
p.stdin.close();assert p.wait()==0

def delta(a,b):
 d=abs(a.astype(float)-b.astype(float));return {'mae':float(d.mean()),'max':float(d.max()),'pixel_equal':bool(np.array_equal(a,b))}
proof,n=decode(R/'transition_C05_C06_360.mp4',{14,15},360,640);assert n==60
checks={'decoded_B_frames':count,'STILL_WET_vs_B239':delta(np.asarray(Image.open(R/'STILL_WET_PAYOFF.png')),frames[239]),'alias_same_file_bytes':(R/'STILL_WET.png').read_bytes()==(R/'STILL_WET_PAYOFF.png').read_bytes(),'transition_boundary14_15':delta(proof[14],proof[15]),'intro_boundary42_43':delta(frames[42],frames[43])}
dry=np.asarray(Image.open(R/'input/BASE_DRY_PAYOFF.png'));wet=frames[239];box=[70,625,875,725];x0,y0,x1,y1=box
x=np.gradient(dry[y0:y1,x0:x1].astype(float).mean(2))[1];y=np.gradient(wet[y0:y1,x0:x1].astype(float).mean(2))[1];scores=[]
for dy in range(-3,4):
 for dx in range(-3,4):scores.append((float(np.mean((x[4:-4,4:-4]-y[4+dy:y.shape[0]-4+dy,4+dx:y.shape[1]-4+dx])**2)),dx,dy))
best=min(scores);checks['dry_wet_rim_best_edge_shift_px']=[best[1],best[2]];checks['dry_wet_rim_box']=box
(E/'PIXEL_JOIN_CHECKS.json').write_text(json.dumps(checks,indent=2))
for label,ids in [('FLOW_REPAIR_VIDEO_360',[60,75,90,104]),('WET_REPAIR_VIDEO_360',[150,162,174,192])]:
 sheet=Image.new('RGB',(360*len(ids),665),'#eeeeee');d=ImageDraw.Draw(sheet)
 for k,f in enumerate(ids):sheet.paste(Image.fromarray(frames[f]).resize((360,640),Image.Resampling.LANCZOS),(360*k,25));d.text((360*k+8,7),f'actual video f{f} / {f/30:.2f}s',fill='black')
 sheet.save(E/(label+'.png'))
for f in [75,174,212]:Image.fromarray(frames[f]).save(E/f'FINAL_B_{f}_1080.png')
for name,start,end in [('CORE_B_FLOW_360.mp4',60,105),('CORE_B_WETTING_360.mp4',150,193)]:
 # Raw frame handoff gives every selected frame an explicit 1/30 duration.
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(R/'CORE_B_WATER.mp4'),'-vf',f"select='between(n,{start},{end-1})',scale=360:640:flags=lanczos",'-fps_mode','passthrough','-f','rawvideo','-pix_fmt','rgb24','pipe:1'])
 assert len(raw)==(end-start)*360*640*3
 subprocess.run(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','360x640','-r','30','-i','pipe:0','-frames:v',str(end-start),'-an','-vf','scale=out_color_matrix=bt709:out_range=tv,format=yuv420p','-c:v','libx264','-crf','18','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-pix_fmt','yuv420p','-movflags','+faststart',str(R/name)],input=raw,check=True)
locks=json.loads((R/'input/BASE_CAMERA_LOCK.json').read_text());out={}
for key in ['CAM_C01_REVEAL','CAM_C05_END']:
 d={k:v for k,v in locks[key].items() if not (k.endswith('sha256') or k.startswith('core_'))};out[key]=d
out['CAM_C01_REVEAL']['dry_reference']='input/BASE_DRY_PAYOFF.png'
out['CAM_C05_END'].update({'video':'CORE_B_WATER.mp4','video_frame_zero_based':239,'wet_material':'CORE_B_REPAIR_WET04','native_render_sha256':hashlib.sha256((R/'native/0480.png').read_bytes()).hexdigest(),'clean_render_sha256':hashlib.sha256((R/'clean/0480.png').read_bytes()).hexdigest(),'decoded_rgb_sha256':hashlib.sha256(frames[239].tobytes()).hexdigest()})
assert all(out['CAM_C01_REVEAL'][k]==out['CAM_C05_END'][k] for k in ['location','rotation_euler','lens_mm','model_transform'])
(R/'camera_lock.json').write_text(json.dumps(out,indent=2));print(json.dumps(checks,indent=2),flush=True)
