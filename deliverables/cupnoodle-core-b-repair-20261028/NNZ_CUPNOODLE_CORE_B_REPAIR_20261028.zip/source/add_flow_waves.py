"""Small downstream travelling waves on existing stream meshes, no fluid solver.
Geometry Nodes evaluates current post-shape-key Z, so wave direction stays downward.
"""
import bpy,math
from pathlib import Path

def apply():
 if 'B_REPAIR_DOWNSTREAM_WAVE' in bpy.data.node_groups:return
 g=bpy.data.node_groups.new('B_REPAIR_DOWNSTREAM_WAVE','GeometryNodeTree')
 g.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry')
 g.interface.new_socket(name='Geometry',in_out='INPUT',socket_type='NodeSocketGeometry')
 axis=g.interface.new_socket(name='Channel axis',in_out='INPUT',socket_type='NodeSocketVector')
 amp=g.interface.new_socket(name='Radius ripple',in_out='INPUT',socket_type='NodeSocketFloat');amp.default_value=.012
 gate=g.interface.new_socket(name='B flow gate',in_out='INPUT',socket_type='NodeSocketFloat');gate.default_value=0
 n=g.nodes;l=g.links;inp=n.new('NodeGroupInput');out=n.new('NodeGroupOutput');pos=n.new('GeometryNodeInputPosition');sep=n.new('ShaderNodeSeparateXYZ');l.new(pos.outputs[0],sep.inputs[0]);time=n.new('GeometryNodeInputSceneTime')
 def op(kind,a,b=0):
  q=n.new('ShaderNodeMath');q.operation=kind
  for i,x in enumerate([a,b]):
   if hasattr(x,'node'):l.new(x,q.inputs[i])
   else:q.inputs[i].default_value=x
  return q.outputs[0]
 def vec(kind,a,b=None,scale=None):
  q=n.new('ShaderNodeVectorMath');q.operation=kind
  l.new(a,q.inputs[0])
  if b is not None:
   if hasattr(b,'node'):l.new(b,q.inputs[1])
   else:q.inputs[1].default_value=b
  if scale is not None:l.new(scale,q.inputs['Scale'])
  return q.outputs['Vector']
 radial=vec('NORMALIZE',vec('MULTIPLY',vec('SUBTRACT',pos.outputs[0],inp.outputs['Channel axis']),(1,1,0)))
 k=2*math.pi/.42;omega=k*1.05
 phase=op('ADD',op('MULTIPLY',sep.outputs['Z'],k),op('MULTIPLY',op('SUBTRACT',time.outputs['Seconds'],241/30),omega))
 wave=op('SINE',phase);strength=op('MULTIPLY',op('MULTIPLY',wave,inp.outputs['Radius ripple']),inp.outputs['B flow gate'])
 radius_offset=vec('SCALE',radial,scale=strength)
 sway=n.new('ShaderNodeCombineXYZ');l.new(op('MULTIPLY',op('MULTIPLY',op('COSINE',op('MULTIPLY',phase,.63)),.007),inp.outputs['B flow gate']),sway.inputs['X']);l.new(op('MULTIPLY',op('MULTIPLY',op('SINE',op('MULTIPLY',phase,.63)),.004),inp.outputs['B flow gate']),sway.inputs['Y'])
 offset=vec('ADD',radius_offset,sway.outputs[0]);setpos=n.new('GeometryNodeSetPosition');l.new(inp.outputs['Geometry'],setpos.inputs['Geometry']);l.new(offset,setpos.inputs['Offset']);l.new(setpos.outputs[0],out.inputs['Geometry'])
 for o in bpy.data.objects:
  if not (o.name.startswith('Water_Inlet') or o.name.startswith('Water_interstice')):continue
  for mod in list(o.modifiers):
   if mod.name=='B_REPAIR_downstream_radius_variation':
    prefix=mod.path_from_id()
    if o.animation_data and o.animation_data.action:
     for c in list(o.animation_data.action.fcurves):
      if c.data_path.startswith(prefix):o.animation_data.action.fcurves.remove(c)
    o.modifiers.remove(mod)
  if o.name.startswith('Water_Inlet') or o.name.endswith('_0'):center=(.18,-.20,0)
  elif o.name.endswith('_1'):center=(-.38,.28,0)
  else:center=(.46,.30,0)
  m=o.modifiers.new('B_REPAIR_downward_liquid_waves','NODES');m.node_group=g;m[axis.identifier]=center;m[amp.identifier]=.014 if o.name.startswith('Water_Inlet') or o.name.endswith('_0') else .011
  for f,v in [(1,0),(240,0),(241,0),(283,0),(295,1),(430,1),(431,0),(480,0)]:
   m[gate.identifier]=v;m.keyframe_insert(data_path='["'+gate.identifier+'"]',frame=f)
  for c in o.animation_data.action.fcurves:
   if 'B_REPAIR_downward_liquid_waves' in c.data_path:
    for p in c.keyframe_points:p.interpolation='LINEAR'
 bpy.context.scene['flow_wave_method']='Existing meshes only: downstream1.05 modelunits/s, wavelength.42, radius ripple.011–.014, centre sway.007/.004; no solver.'
 m=bpy.data.materials['Fried noodle porous dry to wetted'];m['flow_visibility_method']='Soft illuminated optical observation strip over existing channel. B301–345, faded by365. Geometry unchanged; not a physical gap.'
if __name__=='__main__':
 apply();r=Path(__file__).resolve().parents[1];bpy.context.scene.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(r/'source/CORE_B_REPAIRED.blend'));print('DOWNSTREAM_GEOMETRY_WAVES_SAVED',flush=True)
