"""Package actual repaired B only; no upload/publish operation in this script."""
from pathlib import Path
import zipfile,hashlib,json
R=Path(__file__).resolve().parents[1];E=R/'evidence'
required=['CORE_B_WATER.mp4','CORE_B_360_review.mp4','CORE_B_FLOW_360.mp4','CORE_B_WETTING_360.mp4','STILL_WET.png','STILL_WET_PAYOFF.png','STILL_WET_360.png','transition_C05_C06_360.mp4','camera_lock.json','manifest.json','QC_RESULT.md','verification.log']
files=[R/p for p in required]
for p in files:assert p.is_file(),p
files+=[p for p in (R/'source').iterdir() if p.is_file() and (p.suffix in ['.py','.mjs','.md','.txt'] or p.name=='CORE_B_REPAIRED.blend')]
files+=[p for p in (R/'input').iterdir() if p.is_file()]
for name in ['FINAL_SCENE_CHECKS.json','PIXEL_JOIN_CHECKS.json','ART_QC_FINAL.json','PRESERVATION_CHECKS.json','preservation_baseline.json','FROZEN_SCENE_SHA256.txt','MEDIA_VERIFICATION.json','SOURCE_REBUILD_CHECKS.json','FLOW_REPAIR_VIDEO_360.png','WET_REPAIR_VIDEO_360.png','WET_FIXED_LEVEL_COMPARISON_360.png','WET_CONTROL_SAME_LEVEL.json','production_render.log','production_prepare.log','finish_repair.log','scene_inspection.log','source_rebuild.log','preflight.log','npm-test.log','final_playback.log']:
 p=E/name
 if p.exists():files.append(p)
for pattern in ['browser_CORE_B_*/playback.json','browser_transition_*/playback.json']:files+=list(E.glob(pattern))
files=sorted(set(files));sums=R/'SHA256SUMS.txt';sums.write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(R)) for p in files)+'\n')
p=R/'NNZ_CUPNOODLE_CORE_B_REPAIR_20261028.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files+[sums]:z.write(f,f.relative_to(R))
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS.txt').decode().splitlines():
  want,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==want,name
print('REPAIR_ZIP_READY',p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest(),flush=True)
