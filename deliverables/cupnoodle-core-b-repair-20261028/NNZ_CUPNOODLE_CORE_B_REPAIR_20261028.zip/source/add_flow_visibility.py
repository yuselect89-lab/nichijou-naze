"""A local optical observation strip in the existing cup window, B flow only.
No noodle geometry removed. Optical transparency also admits studio illumination into the observed channel.
"""
import bpy,json
from pathlib import Path

def apply():
 bpy.context.scene.cycles.transparent_max_bounces=32
 m=bpy.data.materials['Fried noodle porous dry to wetted'];n=m.node_tree.nodes;l=m.node_tree.links
 if 'B_FLOW_LOCAL_OBSERVATION_GATE' in n:return
 def op(kind,a,b=0):
  q=n.new('ShaderNodeMath');q.operation=kind
  for i,x in enumerate([a,b]):
   if hasattr(x,'node'):l.new(x,q.inputs[i])
   else:q.inputs[i].default_value=x
  return q.outputs[0]
 geo=n.new('ShaderNodeNewGeometry');sep=n.new('ShaderNodeSeparateXYZ');l.new(geo.outputs['Position'],sep.inputs[0])
 # World-space optical strip follows the view ray to existing channel(.18,-.20).
 projected=op('ADD',op('SUBTRACT',sep.outputs['X'],.18),op('MULTIPLY',op('ADD',sep.outputs['Y'],.20),.1016393443))
 edge=n.new('ShaderNodeMapRange');edge.clamp=True;edge.inputs['From Min'].default_value=.09;edge.inputs['From Max'].default_value=.23;edge.inputs['To Min'].default_value=1;edge.inputs['To Max'].default_value=0;l.new(op('ABSOLUTE',projected),edge.inputs[0])
 front=op('LESS_THAN',sep.outputs['Y'],-.25)
 zm=op('MULTIPLY',op('GREATER_THAN',sep.outputs['Z'],.84),op('LESS_THAN',sep.outputs['Z'],2.73))
 gate=n.new('ShaderNodeValue');gate.name='B_FLOW_LOCAL_OBSERVATION_GATE'
 for f,v in [(1,0),(240,0),(241,0),(283,0),(290,0),(301,.96),(345,.96),(365,0),(480,0)]:gate.outputs[0].default_value=v;gate.outputs[0].keyframe_insert('default_value',frame=f)
 for c in gate.id_data.animation_data.action.fcurves:
  if c.data_path==gate.outputs[0].path_from_id('default_value'):
   for k in c.keyframe_points:k.interpolation='LINEAR'
 fac=op('MULTIPLY',op('MULTIPLY',op('MULTIPLY',edge.outputs[0],front),zm),gate.outputs[0])
 out=n.get('Material Output');prior=out.inputs['Surface'].links[0].from_socket;tr=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');l.new(fac,mix.inputs[0]);l.new(prior,mix.inputs[1]);l.new(tr.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],out.inputs['Surface'])
 m['flow_visibility_method']='Soft illuminated optical observation strip over existing channel; B301–345 full, faded by365. Geometry unchanged; observation material admits light, not a physical gap.'
if __name__=='__main__':
 apply();r=Path(__file__).resolve().parents[1];bpy.context.scene.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(r/'source/CORE_B_REPAIRED.blend'));print('FLOW_OBSERVATION_SAVED',flush=True)
