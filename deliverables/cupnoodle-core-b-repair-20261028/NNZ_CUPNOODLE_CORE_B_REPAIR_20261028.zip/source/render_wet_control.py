"""QC control only: same filled-water level/camera, local capillary film disabled.
Does not save or alter the production scene.
"""
import bpy,json
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=bpy.context.scene;s.frame_set(433)
m=bpy.data.materials['Fried noodle porous dry to wetted'];v=m.node_tree.nodes['LOCAL_CAPILLARY_CONTACT_PROGRESS'].outputs[0];path=v.path_from_id('default_value')
for c in m.node_tree.animation_data.action.fcurves:
 if c.data_path==path:c.mute=True
v.default_value=0;s.render.resolution_x=360;s.render.resolution_y=640;s.render.resolution_percentage=100;s.render.filepath=str(r/'evidence/WET_CONTROL_SAME_LEVEL_360_RAW.png');bpy.ops.render.render(write_still=True)
(r/'evidence/WET_CONTROL_SAME_LEVEL.json').write_text(json.dumps({'source_frame':433,'wet_progress_override':0,'water_fill':bpy.data.objects['Water_Transparent_Body_Meniscus'].data.shape_keys.key_blocks['Fill_and_beneath_noodles'].value,'camera':[list(row) for row in s.camera.matrix_world],'purpose':'Same water level and camera as production wet433; local film disabled in memory only. No scene file saved.'},indent=2))
