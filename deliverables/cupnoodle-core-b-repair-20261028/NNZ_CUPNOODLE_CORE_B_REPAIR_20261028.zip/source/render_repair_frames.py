"""Render the existing repaired scene; do not rebuild cup/noodles or CORE_A."""
import bpy,sys,time,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];mode=sys.argv[sys.argv.index('--')+1];s=bpy.context.scene
if mode=='probe':
 frames=sorted(set(list(range(301,347,3))+list(range(391,434,3))+[480]));w,h=360,640;folder='probe_native'
elif mode=='production':
 frames=sorted(set(list(range(284,432,3))+list(range(431,471))+[480]));w,h=1080,1920;folder='native'
else:
 frames=[int(x) for x in mode.split(',')];w,h=1080,1920;folder='native'
s.render.resolution_x=w;s.render.resolution_y=h;s.render.resolution_percentage=100;s.cycles.use_denoising=False
out=R/folder;out.mkdir(exist_ok=True);records=[]
for f in frames:
 p=out/f'{f:04d}.png'
 if p.exists():continue
 s.frame_set(f);s.render.filepath=str(p);t=time.time();result=bpy.ops.render.render(write_still=True)
 assert 'FINISHED' in result
 records.append({'source_frame':f,'seconds':time.time()-t,'size':[w,h],'camera':list(s.camera.location),'lens':s.camera.data.lens,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 print('REPAIR_NATIVE_DONE',f,time.time()-t,flush=True)
 (R/'evidence'/('render_'+('frames' if ',' in mode else mode)+'.json')).write_text(json.dumps(records,indent=2))
print('REPAIR_RENDER_COMPLETE',mode,flush=True)
