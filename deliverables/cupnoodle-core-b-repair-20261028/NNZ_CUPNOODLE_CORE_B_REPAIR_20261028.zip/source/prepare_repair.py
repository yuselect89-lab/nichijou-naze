"""Existing source -> actual native renders -> local denoise -> silent CORE_B.
CORE_A is never rendered, copied over or encoded. Original B intro0..42 is reused.
"""
from pathlib import Path
import subprocess,sys,shutil,json,hashlib
from denoise import Denoiser
R=Path(__file__).resolve().parents[1];mode=sys.argv[1];probe=mode=='probe';assert mode in ['probe','production'];source=R/('probe_native' if probe else 'native');clean=R/('probe_clean' if probe else 'clean');clean.mkdir(exist_ok=True);d=Denoiser()
for p in sorted(source.glob('*.png')):
 dst=clean/p.name
 if not dst.exists():d.process(p,dst);print('REPAIR_CLEAN',p.stem,flush=True)
work=R/'render_cache'/mode;work.mkdir(parents=True,exist_ok=True)
def interp(label,frames,rate,count):
 grid=work/label/'grid';out=work/label/'dense';grid.mkdir(parents=True,exist_ok=True);out.mkdir(exist_ok=True)
 for p in out.glob('*.png'):p.unlink()
 for p in grid.glob('*.png'):p.unlink()
 for k,f in enumerate(frames):shutil.copy2(clean/f'{f:04d}.png',grid/f'{k:04d}.png')
 pad=round(60/rate)
 subprocess.run(['ffmpeg','-y','-v','error','-threads','3','-filter_threads','3','-framerate',str(rate),'-i',str(grid/'%04d.png'),'-vf',f'tpad=start=2:start_mode=clone:stop=3:stop_mode=clone,minterpolate=fps=30:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1:mb_size=16:search_param=64,settb=1/30,trim=start_pts={pad}:end_pts={pad+count},setpts=PTS-STARTPTS','-fps_mode','passthrough','-frames:v',str(count),'-compression_level','1','-start_number','0',str(out/'%04d.png')],check=True)
 assert len(list(out.glob('*.png')))==count
 return [out/f'{f:04d}.png' for f in range(count)]
def encode(name,seq,w,h):
 out=work/name;out.mkdir(exist_ok=True)
 for p in out.glob('*.png'):p.unlink()
 for k,p in enumerate(seq):shutil.copy2(p,out/f'{k:04d}.png')
 subprocess.run(['ffmpeg','-y','-v','error','-threads','3','-filter_threads','3','-framerate','30','-i',str(out/'%04d.png'),'-frames:v',str(len(seq)),'-an','-vf','scale=out_color_matrix=bt709:out_range=tv,format=yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-c:v','libx264','-preset','medium','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(R/(name+'.mp4'))],check=True)
 print('REPAIR_VIDEO_READY',name,len(seq),[w,h],flush=True)
if probe:
 a=interp('flow',list(range(301,347,3)),10,45);b=interp('wet',list(range(391,434,3)),10,43)
 encode('REPAIR_FLOW_PROBE_360',a,360,640);encode('REPAIR_WET_PROBE_360',b,360,640)
else:
 prefix=work/'original_intro';prefix.mkdir(exist_ok=True)
 old=R/'input/BASE_CORE_B_WATER.mp4'
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(old),'-frames:v','43','-compression_level','1','-start_number','0',str(prefix/'%04d.png')],check=True)
 seq=[prefix/f'{f:04d}.png' for f in range(43)]+interp('fixed_camera',list(range(284,432,3)),10,147)+[clean/f'{f:04d}.png' for f in range(431,471)]+[clean/'0480.png']*10
 assert len(seq)==240
 encode('CORE_B_WATER',seq,1080,1920)
 subprocess.run(['ffmpeg','-y','-v','error','-threads','3','-i',str(R/'CORE_B_WATER.mp4'),'-vf','scale=360:640:flags=lanczos','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(R/'CORE_B_360_review.mp4')],check=True)
print('REPAIR_PREPARE_COMPLETE',mode,flush=True)
