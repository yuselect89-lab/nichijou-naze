"""Read saved scene and baseline; verify geometry/camera preservation and real motion."""
import bpy,json,hashlib
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];s=bpy.context.scene

def snapshot():
 shapes={}
 for o in bpy.data.objects:
  if not o.name.startswith(('Cup_','Noodles_')):continue
  if o.type=='MESH':d={'v':[list(v.co) for v in o.data.vertices],'f':[list(p.vertices) for p in o.data.polygons]}
  elif o.type=='CURVE':d={'bevel':o.data.bevel_depth,'caps':o.data.use_fill_caps,'s':[[list(p.co) for p in sp.points] for sp in o.data.splines]}
  else:continue
  shapes[o.name]=hashlib.sha256(json.dumps(d,sort_keys=True).encode()).hexdigest()
 cams=[]
 for f in [241,283,434,468,480]:
  s.frame_set(f);cams.append({'f':f,'matrix':[list(v) for v in s.camera.matrix_world],'lens':s.camera.data.lens,'shift':[s.camera.data.shift_x,s.camera.data.shift_y]})
 return {'geometry':shapes,'cameras':cams,'look':s.view_settings.look,'exposure':s.view_settings.exposure,'lights':[(o.name,o.data.energy,list(o.data.color),list(o.location)) for o in bpy.data.objects if o.type=='LIGHT']}
a=snapshot();mat=bpy.data.materials['Fried noodle porous dry to wetted'];assert mat['wet_material_version']=='CORE_B_REPAIR_WET04'
rows=[]
for f in [1,240,283,301,345,365,391,408,418,430,431,434,480]:
 s.frame_set(f);rows.append({'f':f,'observation':mat.node_tree.nodes['B_FLOW_LOCAL_OBSERVATION_GATE'].outputs[0].default_value,'wet':mat.node_tree.nodes['LOCAL_CAPILLARY_CONTACT_PROGRESS'].outputs[0].default_value,'fill':bpy.data.objects['Water_Transparent_Body_Meniscus'].data.shape_keys.key_blocks['Fill_and_beneath_noodles'].value,'streams_hidden':all(o.hide_render for o in s.objects if o.name.startswith(('Water_Inlet','Water_interstice')))})
assert rows[0]['observation']==rows[1]['observation']==rows[2]['observation']==0
assert rows[9]['wet']==1 and rows[9]['fill']==1 and rows[10]['streams_hidden']
water=bpy.data.objects['Water_interstice_downflow_0'];points=[]
for f in [350,353]:
 s.frame_set(f);dep=bpy.context.evaluated_depsgraph_get();ev=water.evaluated_get(dep);me=ev.to_mesh();points.append(np.asarray([list(v.co) for v in me.vertices]));ev.to_mesh_clear()
delta=points[1]-points[0];assert np.max(abs(delta[:,:2]))>.003 and np.max(abs(delta[:,2]))<1e-6
assert not any(m.type=='FLUID' for o in s.objects for m in o.modifiers)
params={'wave':s['flow_wave_method'],'visibility':mat['flow_visibility_method'],'transparent_bounces':s.cycles.transparent_max_bounces,'actual_steady_flow_xy_change_max':float(np.max(abs(delta[:,:2]))),'actual_steady_flow_z_change_max':float(np.max(abs(delta[:,2]))),'states':rows}
bpy.ops.wm.open_mainfile(filepath=str(R/'input/BASE_SHARED_V4_1_WET03.blend'));s=bpy.context.scene;b=snapshot();assert a==b,'Cup/noodle geometry, cameras, light or exposure changed'
result={'cup_noodle_geometry_and_camera_lights_unchanged':True,'geometry_fingerprints':a['geometry'],'cameras':a['cameras'],'actual_parameters':params,'no_solver':True,'scope':'Actual saved scene readback. Art quality is judged separately on real video.'}
(R/'evidence/FINAL_SCENE_CHECKS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
